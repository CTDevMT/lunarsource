﻿// Decompiled with JetBrains decompiler
// Type: 724FA278
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System.Net;

internal class \u003724FA278
{
  private System.Threading.Timer HelloSkid;
  private string HelloSkid;

  public \u003724FA278()
  {
    // ISSUE: unable to decompile the method.
  }

  public void HelloSkid()
  {
    // ISSUE: unable to decompile the method.
  }

  private void HelloSkid()
  {
    // ISSUE: unable to decompile the method.
  }

  public static IPAddress HelloSkid()
  {
    // ISSUE: unable to decompile the method.
  }

  private string HelloSkid()
  {
    // ISSUE: unable to decompile the method.
  }

  private string HelloSkid()
  {
    // ISSUE: unable to decompile the method.
  }
}
