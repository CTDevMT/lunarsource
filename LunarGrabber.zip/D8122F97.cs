﻿// Decompiled with JetBrains decompiler
// Type: D8122F97
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

[CompilerGenerated]
[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.8.1.0")]
internal sealed class D8122F97 : ApplicationSettingsBase
{
  private static D8122F97 HelloSkid;

  public static D8122F97 Default
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public D8122F97()
  {
    // ISSUE: unable to decompile the method.
  }

  static D8122F97()
  {
    // ISSUE: unable to decompile the method.
  }
}
