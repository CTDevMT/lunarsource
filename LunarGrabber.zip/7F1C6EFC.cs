﻿// Decompiled with JetBrains decompiler
// Type: 7F1C6EFC
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System.Collections.Generic;

internal class \u0037F1C6EFC
{
  public static string HelloSkid;
  public static Dictionary<string, string> HelloSkid;

  public static string HelloSkid(string HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  public \u0037F1C6EFC()
  {
    // ISSUE: unable to decompile the method.
  }

  static \u0037F1C6EFC()
  {
    // ISSUE: unable to decompile the method.
  }
}
