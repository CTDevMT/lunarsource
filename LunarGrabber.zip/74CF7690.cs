﻿// Decompiled with JetBrains decompiler
// Type: 74CF7690
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

internal struct \u00374CF7690
{
  private readonly \u0037C067239[] \u0037E367F71;
  private readonly int \u00367DC7EF4;

  public \u00374CF7690(int _param1)
  {
    this.\u00367DC7EF4 = _param1;
    this.\u0037E367F71 = new \u0037C067239[1 << _param1];
  }

  public void \u003683C691D()
  {
    for (uint index = 1; (long) index < (long) (1 << this.\u00367DC7EF4); ++index)
      this.\u0037E367F71[(int) index].\u003205F225E();
  }

  public uint \u00374BF3736(\u0032FDD6398 _param1)
  {
    uint num = 1;
    for (int index = this.\u00367DC7EF4; index > 0; --index)
      num = (num << 1) + this.\u0037E367F71[(int) num].\u0037AFF0970(_param1);
    return num - (uint) (1 << this.\u00367DC7EF4);
  }

  public uint \u0034F2A7AF3(\u0032FDD6398 _param1)
  {
    uint num1 = 1;
    uint num2 = 0;
    for (int index = 0; index < this.\u00367DC7EF4; ++index)
    {
      uint num3 = this.\u0037E367F71[(int) num1].\u0037AFF0970(_param1);
      num1 = (num1 << 1) + num3;
      num2 |= num3 << index;
    }
    return num2;
  }

  public static uint \u003279730E3(
    \u0037C067239[] _param0,
    uint _param1,
    \u0032FDD6398 _param2,
    int _param3)
  {
    uint num1 = 1;
    uint num2 = 0;
    for (int index = 0; index < _param3; ++index)
    {
      uint num3 = _param0[(int) _param1 + (int) num1].\u0037AFF0970(_param2);
      num1 = (num1 << 1) + num3;
      num2 |= num3 << index;
    }
    return num2;
  }
}
