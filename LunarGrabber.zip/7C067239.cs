﻿// Decompiled with JetBrains decompiler
// Type: 7C067239
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

internal struct \u0037C067239
{
  private const int \u003331D2CB2 = 11;
  private const uint \u0033A333FA2 = 2048;
  private const int \u0030F7001E5 = 5;
  private uint \u0033E58613A;

  public void \u003205F225E() => this.\u0033E58613A = 1024U;

  public uint \u0037AFF0970(\u0032FDD6398 _param1)
  {
    uint num = (_param1.\u003469E2533 >> 11) * this.\u0033E58613A;
    if (_param1.\u003354927BA < num)
    {
      _param1.\u003469E2533 = num;
      this.\u0033E58613A += 2048U - this.\u0033E58613A >> 5;
      if (_param1.\u003469E2533 < 16777216U)
      {
        _param1.\u003354927BA = _param1.\u003354927BA << 8 | (uint) (byte) _param1.\u00335B93375.ReadByte();
        _param1.\u003469E2533 <<= 8;
      }
      return 0;
    }
    _param1.\u003469E2533 -= num;
    _param1.\u003354927BA -= num;
    this.\u0033E58613A -= this.\u0033E58613A >> 5;
    if (_param1.\u003469E2533 < 16777216U)
    {
      _param1.\u003354927BA = _param1.\u003354927BA << 8 | (uint) (byte) _param1.\u00335B93375.ReadByte();
      _param1.\u003469E2533 <<= 8;
    }
    return 1;
  }
}
