﻿// Decompiled with JetBrains decompiler
// Type: 0B8C7DB0
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

internal static class \u0030B8C7DB0
{
  private const int \u0033623716A = 32;

  internal static void \u0032EA14966(uint[] _param0)
  {
    // ISSUE: unable to decompile the method.
  }

  private static uint[] \u003653E2E72(uint[] _param0, int _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal static void \u003190F7137<T>(ref T _param0, ref T _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal static ulong \u00320B22A9B(uint _param0, uint _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal static uint \u003434417CA(ulong _param0)
  {
    // ISSUE: unable to decompile the method.
  }

  internal static uint \u00339A3450B(ulong _param0)
  {
    // ISSUE: unable to decompile the method.
  }

  private static uint \u003226C542A(uint _param0, uint _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal static int \u00347406344(int _param0, int _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal static int \u00344D37F02(uint _param0)
  {
    // ISSUE: unable to decompile the method.
  }
}
