﻿// Decompiled with JetBrains decompiler
// Type: 6D7B3BE0
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

public class \u0036D7B3BE0
{
  private uint \u0033474388F;

  public \u0036D7B3BE0() => this.\u0033474388F = 26608214U;

  public uint \u00335992766(uint _param1)
  {
    uint num = _param1 ^ this.\u0033474388F;
    this.\u0033474388F = \u0034F981AA2.\u0035A830392(this.\u0033474388F, 7) ^ num;
    return num;
  }
}
