﻿// Decompiled with JetBrains decompiler
// Type: B2ECA476
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
internal sealed class B2ECA476
{
  internal static readonly B2ECA476.\u00352BA96A5 HelloSkid;

  [StructLayout(LayoutKind.Explicit, Size = 20, Pack = 1)]
  private struct \u00352BA96A5
  {
  }
}
