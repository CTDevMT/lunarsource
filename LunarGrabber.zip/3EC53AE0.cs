﻿// Decompiled with JetBrains decompiler
// Type: 3EC53AE0
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

[Serializable]
internal struct \u0033EC53AE0
{
  private const uint \u00343606A61 = 2147483648;
  private const int \u0032AA01350 = 32;
  private readonly int \u00341651168;
  private readonly uint[] \u0031A8B3BCC;
  private static readonly \u0033EC53AE0 \u003697915D4;
  private static readonly \u0033EC53AE0 \u00373886952;
  private static readonly \u0033EC53AE0 \u00375B877E7;
  private static readonly \u0033EC53AE0 \u00369222449;

  [Conditional("DEBUG")]
  private void \u00329182008()
  {
    // ISSUE: unable to decompile the method.
  }

  private static \u0033EC53AE0 \u00323BB3A63
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  private bool \u003006275AE
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  private int \u003505E1F42
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public virtual bool \u0038E80E564(object _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  public virtual int \u00360E614F6()
  {
    // ISSUE: unable to decompile the method.
  }

  private int \u0030438001E(\u0033EC53AE0 _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal byte[] \u0034EBA2CB0()
  {
    // ISSUE: unable to decompile the method.
  }

  private \u0033EC53AE0(int _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal \u0033EC53AE0(byte[] _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal \u0033EC53AE0(int _param1, uint[] _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  private static void \u003435D03D8(
    ref \u00331E30ACC _param0,
    ref \u00331E30ACC _param1,
    ref \u00331E30ACC _param2,
    ref \u00331E30ACC _param3)
  {
    // ISSUE: unable to decompile the method.
  }

  private static void \u00332551EC2(
    ref \u00331E30ACC _param0,
    ref \u00331E30ACC _param1,
    ref \u00331E30ACC _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  private static void \u0035ABA2845(
    uint _param0,
    ref \u00331E30ACC _param1,
    ref \u00331E30ACC _param2,
    ref \u00331E30ACC _param3,
    ref \u00331E30ACC _param4)
  {
    // ISSUE: unable to decompile the method.
  }

  private static void \u0036BC14BA9(
    uint _param0,
    ref \u00331E30ACC _param1,
    ref \u00331E30ACC _param2,
    ref \u00331E30ACC _param3,
    ref \u00331E30ACC _param4)
  {
    // ISSUE: unable to decompile the method.
  }

  internal static \u0033EC53AE0 \u00360CC2700(
    \u0033EC53AE0 _param0,
    \u0033EC53AE0 _param1,
    \u0033EC53AE0 _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  [SpecialName]
  public static bool \u00316F944FF(\u0033EC53AE0 _param0, \u0033EC53AE0 _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  [SpecialName]
  public static bool \u003301002A3(\u0033EC53AE0 _param0, \u0033EC53AE0 _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  [SpecialName]
  public static bool \u0033605273E(\u0033EC53AE0 _param0, \u0033EC53AE0 _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  [SpecialName]
  public static bool \u0034B686996(\u0033EC53AE0 _param0, \u0033EC53AE0 _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  [SpecialName]
  public static bool \u003587B3333(\u0033EC53AE0 _param0, \u0033EC53AE0 _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  [SpecialName]
  public static bool \u00361C13B24(\u0033EC53AE0 _param0, \u0033EC53AE0 _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  private static int \u0035C461BB0(uint[] _param0)
  {
    // ISSUE: unable to decompile the method.
  }

  internal int \u00329AB2964
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  internal uint[] \u00300C71CA6
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  private static int \u00367E87DF6(uint[] _param0, uint[] _param1, int _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  static \u0033EC53AE0()
  {
    // ISSUE: unable to decompile the method.
  }
}
