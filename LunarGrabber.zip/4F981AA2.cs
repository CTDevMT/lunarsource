﻿// Decompiled with JetBrains decompiler
// Type: 4F981AA2
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

public class \u0034F981AA2
{
  public const int \u0034E9314F5 = 32;

  public static uint \u0035A830392(uint _param0, int _param1) => _param0 << _param1 | _param0 >> 32 - _param1;

  public static uint \u0032B3E74E1(uint _param0, int _param1) => _param0 >> _param1 | _param0 << 32 - _param1;

  public static uint \u0031A7514F1(uint _param0)
  {
    uint num1 = _param0 & 16711935U;
    uint num2 = _param0 & 4278255360U;
    return (uint) (((int) (num1 >> 8) | (int) num1 << 24) + ((int) num2 << 8 | (int) (num2 >> 24)));
  }
}
