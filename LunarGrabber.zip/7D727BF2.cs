﻿// Decompiled with JetBrains decompiler
// Type: 7D727BF2
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;
using System.IO;

public class \u0037D727BF2
{
  private uint \u0033B2253B9 = 1;
  private readonly \u0034A936F2C \u0036A4018F9 = new \u0034A936F2C();
  private readonly \u0032FDD6398 \u0033C517070 = new \u0032FDD6398();
  private readonly \u0037C067239[] \u00333915DE2 = new \u0037C067239[192];
  private readonly \u0037C067239[] \u0030D4317D0 = new \u0037C067239[12];
  private readonly \u0037C067239[] \u003030761F7 = new \u0037C067239[12];
  private readonly \u0037C067239[] \u0035FDC60C4 = new \u0037C067239[12];
  private readonly \u0037C067239[] \u0034E355594 = new \u0037C067239[12];
  private readonly \u0037C067239[] \u0032FD371B0 = new \u0037C067239[192];
  private readonly \u00374CF7690[] \u003153B1E63 = new \u00374CF7690[4];
  private readonly \u0037C067239[] \u00359FE4AA7 = new \u0037C067239[114];
  private \u00374CF7690 \u0035432132E = new \u00374CF7690(4);
  private readonly \u0037D727BF2.\u0031366272D \u00338D07FDD = new \u0037D727BF2.\u0031366272D();
  private readonly \u0037D727BF2.\u0031366272D \u00323CB29F1 = new \u0037D727BF2.\u0031366272D();
  private readonly \u0037D727BF2.\u00341DE535B \u0036A20785F = new \u0037D727BF2.\u00341DE535B();
  private uint \u0034D324C34;
  private uint \u003222B0501;
  private uint \u00355394597;

  public \u0037D727BF2()
  {
    this.\u0034D324C34 = uint.MaxValue;
    for (int index = 0; index < 4; ++index)
      this.\u003153B1E63[index] = new \u00374CF7690(6);
  }

  private void \u0030D721FA4(uint _param1)
  {
    if ((int) this.\u0034D324C34 == (int) _param1)
      return;
    this.\u0034D324C34 = _param1;
    this.\u003222B0501 = Math.Max(this.\u0034D324C34, 1U);
    this.\u0036A4018F9.\u0037C706F28(Math.Max(this.\u003222B0501, 4096U));
  }

  private void \u0030BEB39B0(int _param1, int _param2)
  {
    if (_param1 > 8)
      throw new ArgumentException("lp > 8");
    if (_param2 > 8)
      throw new ArgumentException("lc > 8");
    this.\u0036A20785F.\u00331B569E8(_param1, _param2);
  }

  private void \u00307074FC1(int _param1)
  {
    if (_param1 > 4)
      throw new ArgumentException("pb > Base.KNumPosStatesBitsMax");
    uint num = (uint) (1 << _param1);
    this.\u00338D07FDD.\u0033BDF1DE7(num);
    this.\u00323CB29F1.\u0033BDF1DE7(num);
    this.\u00355394597 = num - 1U;
  }

  private void \u00305440FD7(Stream _param1, Stream _param2)
  {
    this.\u0033C517070.\u00342B200AF(_param1);
    this.\u0036A4018F9.\u0036468059F(_param2, false);
    for (uint index1 = 0; index1 < 12U; ++index1)
    {
      for (uint index2 = 0; index2 <= this.\u00355394597; ++index2)
      {
        uint num = (index1 << 4) + index2;
        this.\u00333915DE2[(int) num].\u003205F225E();
        this.\u0032FD371B0[(int) num].\u003205F225E();
      }
      this.\u0030D4317D0[(int) index1].\u003205F225E();
      this.\u003030761F7[(int) index1].\u003205F225E();
      this.\u0035FDC60C4[(int) index1].\u003205F225E();
      this.\u0034E355594[(int) index1].\u003205F225E();
    }
    this.\u0036A20785F.\u0036478747E();
    for (uint index = 0; index < 4U; ++index)
      this.\u003153B1E63[(int) index].\u003683C691D();
    for (uint index = 0; index < 114U; ++index)
      this.\u00359FE4AA7[(int) index].\u003205F225E();
    this.\u00338D07FDD.\u00326E8104A();
    this.\u00323CB29F1.\u00326E8104A();
    this.\u0035432132E.\u003683C691D();
  }

  public void \u00320360A85(Stream _param1, Stream _param2, long _param3)
  {
    this.\u00305440FD7(_param1, _param2);
    \u0036BEF6F02.\u00320640DDD obj = new \u0036BEF6F02.\u00320640DDD();
    obj.\u00335D12107();
    uint num1 = 0;
    uint num2 = 0;
    uint num3 = 0;
    uint num4 = 0;
    ulong num5 = 0;
    ulong num6 = (ulong) _param3;
    if (num5 < num6)
    {
      if (this.\u00333915DE2[(int) obj.\u00313A6211D << 4].\u0037AFF0970(this.\u0033C517070) != 0U)
        throw new InvalidDataException("IsMatchDecoders");
      obj.\u003599F16DB();
      this.\u0036A4018F9.\u00371644D23(this.\u0036A20785F.\u003432C497F(this.\u0033C517070, 0U, (byte) 0));
      ++num5;
    }
    while (num5 < num6)
    {
      uint num7 = (uint) num5 & this.\u00355394597;
      if (this.\u00333915DE2[((int) obj.\u00313A6211D << 4) + (int) num7].\u0037AFF0970(this.\u0033C517070) == 0U)
      {
        byte num8 = this.\u0036A4018F9.\u0034A113372(0U);
        this.\u0036A4018F9.\u00371644D23(obj.\u00331B479B8() ? this.\u0036A20785F.\u003432C497F(this.\u0033C517070, (uint) num5, num8) : this.\u0036A20785F.\u003019E01AD(this.\u0033C517070, (uint) num5, num8, this.\u0036A4018F9.\u0034A113372(num1)));
        obj.\u003599F16DB();
        ++num5;
      }
      else
      {
        uint num8;
        if (this.\u0030D4317D0[(int) obj.\u00313A6211D].\u0037AFF0970(this.\u0033C517070) == 1U)
        {
          if (this.\u003030761F7[(int) obj.\u00313A6211D].\u0037AFF0970(this.\u0033C517070) == 0U)
          {
            if (this.\u0032FD371B0[((int) obj.\u00313A6211D << 4) + (int) num7].\u0037AFF0970(this.\u0033C517070) == 0U)
            {
              obj.\u0031DA23961();
              this.\u0036A4018F9.\u00371644D23(this.\u0036A4018F9.\u0034A113372(num1));
              ++num5;
              continue;
            }
          }
          else
          {
            uint num9;
            if (this.\u0035FDC60C4[(int) obj.\u00313A6211D].\u0037AFF0970(this.\u0033C517070) == 0U)
            {
              num9 = num2;
            }
            else
            {
              if (this.\u0034E355594[(int) obj.\u00313A6211D].\u0037AFF0970(this.\u0033C517070) == 0U)
              {
                num9 = num3;
              }
              else
              {
                num9 = num4;
                num4 = num3;
              }
              num3 = num2;
            }
            num2 = num1;
            num1 = num9;
          }
          num8 = this.\u00323CB29F1.\u00351E4330C(this.\u0033C517070, num7) + 2U;
          obj.\u00311437001();
        }
        else
        {
          num4 = num3;
          num3 = num2;
          num2 = num1;
          num8 = 2U + this.\u00338D07FDD.\u00351E4330C(this.\u0033C517070, num7);
          obj.\u003690D57F2();
          uint num9 = this.\u003153B1E63[(int) \u0036BEF6F02.\u00366D53169(num8)].\u00374BF3736(this.\u0033C517070);
          if (num9 >= 4U)
          {
            int num10 = (int) (num9 >> 1) - 1;
            uint num11 = (uint) ((2 | (int) num9 & 1) << num10);
            num1 = num9 >= 14U ? num11 + (this.\u0033C517070.\u003241C0610(num10 - 4) << 4) + this.\u0035432132E.\u0034F2A7AF3(this.\u0033C517070) : num11 + \u00374CF7690.\u003279730E3(this.\u00359FE4AA7, (uint) ((int) num11 - (int) num9 - 1), this.\u0033C517070, num10);
          }
          else
            num1 = num9;
        }
        if ((ulong) num1 >= (ulong) this.\u0036A4018F9.\u0030A371617 + num5 || num1 >= this.\u003222B0501)
        {
          if (num1 != uint.MaxValue)
            throw new InvalidDataException("rep0");
          break;
        }
        this.\u0036A4018F9.\u0031BB66ED5(num1, num8);
        num5 += (ulong) num8;
      }
    }
    this.\u0036A4018F9.\u00318B324DC();
    this.\u0036A4018F9.\u003238677DA();
    this.\u0033C517070.\u003164C026A();
  }

  public void \u00336487C1C(byte[] _param1)
  {
    if (_param1.Length < 5)
      throw new ArgumentException("properties.Length < 5");
    int num1 = (int) _param1[0] % 9;
    int num2 = (int) _param1[0] / 9;
    int num3 = num2 % 5;
    int num4 = num2 / 5;
    if (num4 > 4)
      throw new ArgumentException("pb > Base.kNumPosStatesBitsMax");
    uint num5 = 0;
    for (int index = 0; index < 4; ++index)
      num5 += (uint) _param1[1 + index] << index * 8;
    this.\u0030D721FA4(num5);
    this.\u0030BEB39B0(num3, num1);
    this.\u00307074FC1(num4);
  }

  private class \u0031366272D
  {
    private \u0037C067239 \u0033B562B91;
    private \u0037C067239 \u003507E378E;
    private readonly \u00374CF7690[] \u0031CCA09FD = new \u00374CF7690[16];
    private readonly \u00374CF7690[] \u003671D2F46 = new \u00374CF7690[16];
    private \u00374CF7690 \u0030F2001C3 = new \u00374CF7690(8);
    private uint \u00301B60EF6;

    public void \u0033BDF1DE7(uint _param1)
    {
      for (uint index = this.\u00301B60EF6; index < _param1; ++index)
      {
        this.\u0031CCA09FD[(int) index] = new \u00374CF7690(3);
        this.\u003671D2F46[(int) index] = new \u00374CF7690(3);
      }
      this.\u00301B60EF6 = _param1;
    }

    public void \u00326E8104A()
    {
      this.\u0033B562B91.\u003205F225E();
      for (uint index = 0; index < this.\u00301B60EF6; ++index)
      {
        this.\u0031CCA09FD[(int) index].\u003683C691D();
        this.\u003671D2F46[(int) index].\u003683C691D();
      }
      this.\u003507E378E.\u003205F225E();
      this.\u0030F2001C3.\u003683C691D();
    }

    public uint \u00351E4330C(\u0032FDD6398 _param1, uint _param2)
    {
      if (this.\u0033B562B91.\u0037AFF0970(_param1) == 0U)
        return this.\u0031CCA09FD[(int) _param2].\u00374BF3736(_param1);
      uint num = 8;
      return this.\u003507E378E.\u0037AFF0970(_param1) != 0U ? num + 8U + this.\u0030F2001C3.\u00374BF3736(_param1) : num + this.\u003671D2F46[(int) _param2].\u00374BF3736(_param1);
    }
  }

  private class \u00341DE535B
  {
    private uint \u00353CA051E = 1;
    private \u0037D727BF2.\u00341DE535B.\u0033A692FA4[] \u00300790195;
    private int \u003012C2456;
    private int \u00314F934DB;
    private uint \u0033F496371;

    public void \u00331B569E8(int _param1, int _param2)
    {
      if (this.\u00300790195 != null && this.\u003012C2456 == _param2 && this.\u00314F934DB == _param1)
        return;
      this.\u00314F934DB = _param1;
      this.\u0033F496371 = (uint) ((1 << _param1) - 1);
      this.\u003012C2456 = _param2;
      uint num = (uint) (1 << this.\u003012C2456 + this.\u00314F934DB);
      this.\u00300790195 = new \u0037D727BF2.\u00341DE535B.\u0033A692FA4[(int) num];
      for (uint index = 0; index < num; ++index)
        this.\u00300790195[(int) index].\u003055D06A7();
    }

    public void \u0036478747E()
    {
      uint num = (uint) (1 << this.\u003012C2456 + this.\u00314F934DB);
      for (uint index = 0; index < num; ++index)
        this.\u00300790195[(int) index].\u003535B33BE();
    }

    private uint \u00349BB6CCC(uint _param1, byte _param2) => (uint) ((((int) _param1 & (int) this.\u0033F496371) << this.\u003012C2456) + ((int) _param2 >> 8 - this.\u003012C2456));

    public byte \u003432C497F(\u0032FDD6398 _param1, uint _param2, byte _param3) => this.\u00300790195[(int) this.\u00349BB6CCC(_param2, _param3)].\u00356871C03(_param1);

    public byte \u003019E01AD(\u0032FDD6398 _param1, uint _param2, byte _param3, byte _param4) => this.\u00300790195[(int) this.\u00349BB6CCC(_param2, _param3)].\u00314F61514(_param1, _param4);

    private struct \u0033A692FA4
    {
      private \u0037C067239[] \u00365CE35DB;

      public void \u003055D06A7() => this.\u00365CE35DB = new \u0037C067239[768];

      public void \u003535B33BE()
      {
        for (int index = 0; index < 768; ++index)
          this.\u00365CE35DB[index].\u003205F225E();
      }

      public byte \u00356871C03(\u0032FDD6398 _param1)
      {
        uint num = 1;
        do
        {
          num = num << 1 | this.\u00365CE35DB[(int) num].\u0037AFF0970(_param1);
        }
        while (num < 256U);
        return (byte) num;
      }

      public byte \u00314F61514(\u0032FDD6398 _param1, byte _param2)
      {
        uint num1 = 1;
        do
        {
          uint num2 = (uint) ((int) _param2 >> 7 & 1);
          _param2 <<= 1;
          uint num3 = this.\u00365CE35DB[(1 + (int) num2 << 8) + (int) num1].\u0037AFF0970(_param1);
          num1 = num1 << 1 | num3;
          if ((int) num2 != (int) num3)
          {
            while (num1 < 256U)
              num1 = num1 << 1 | this.\u00365CE35DB[(int) num1].\u0037AFF0970(_param1);
            break;
          }
        }
        while (num1 < 256U);
        return (byte) num1;
      }
    }
  }
}
