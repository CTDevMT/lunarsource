﻿// Decompiled with JetBrains decompiler
// Type: 0C9C028A
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;
using System.Reflection;

public class \u0030C9C028A
{
  private readonly byte[] \u0032BD06CD4;
  private byte[] \u0034B84256D;
  private readonly object \u003643876F6;
  private \u00355517E44 \u003734E3AC2;
  private long \u003605C2759;
  private readonly int \u00367F56E9F;
  private int \u00325947285;
  private uint \u0037E2F6BEE;

  public \u0030C9C028A(long _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  public \u0030C9C028A(byte[] _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  public class \u0035BD57A3D
  {
    protected bool \u00359FB288A(byte[] _param1)
    {
      // ISSUE: unable to decompile the method.
    }

    protected void \u00357760F1B()
    {
      // ISSUE: unable to decompile the method.
    }

    protected void \u0031E5F03AE(string _param1, string _param2)
    {
      // ISSUE: unable to decompile the method.
    }

    private void \u003395E4AA3(string _param1, bool _param2)
    {
      // ISSUE: unable to decompile the method.
    }

    public string \u00349D22739
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      private set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    public string \u0030F0F7296
    {
      get
      {
        // ISSUE: unable to decompile the method.
      }
      private set
      {
        // ISSUE: unable to decompile the method.
      }
    }

    public \u0035BD57A3D()
    {
      // ISSUE: unable to decompile the method.
    }

    public static unsafe object \u003494F7B3A(void* _param0)
    {
      uint num1 = 794178660;
      void* ptr = _param0;
      uint num2 = 1357255731U & num1;
      Type type = typeof (void*);
      return Pointer.Box(ptr, type);
    }

    public static unsafe void* \u003697E7653(object _param0)
    {
      uint num1 = 1804821622;
      object ptr = _param0;
      uint num2 = num1 / 481957331U;
      return Pointer.Unbox(ptr);
    }
  }

  public class \u003655829C3 : \u0030C9C028A.\u0035BD57A3D
  {
    string \u0030E56067E { }
  }

  public class \u003356B5327 : \u0030C9C028A.\u0035BD57A3D
  {
  }
}
