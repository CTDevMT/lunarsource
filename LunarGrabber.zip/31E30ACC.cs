﻿// Decompiled with JetBrains decompiler
// Type: 31E30ACC
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System.Diagnostics;

internal struct \u00331E30ACC
{
  private const int \u003009627A5 = 32;
  private int \u003752709C1;
  private uint \u003450116CC;
  private uint[] \u0030AB85741;
  private bool \u0030C2A238F;

  [Conditional("DEBUG")]
  private void \u0037CA41E13(bool _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal \u00331E30ACC(int _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal \u00331E30ACC(\u0033EC53AE0 _param1, ref int _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  internal \u0033EC53AE0 \u0034ED34F96(int _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  private void \u0035DB365DC(int _param1, out int _param2, out uint[] _param3)
  {
    // ISSUE: unable to decompile the method.
  }

  private void \u0034AD124D7(uint _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  private void \u003388822DB(ulong _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal int \u00369F3243E
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  private void \u003428B0E65()
  {
    // ISSUE: unable to decompile the method.
  }

  private int \u00373685879
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  private void \u0031940267D(int _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  private void \u00363DA2AB3(int _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  private void \u0030ECB5848(int _param1, int _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  private void \u0037B75302F(int _param1 = 0)
  {
    // ISSUE: unable to decompile the method.
  }

  private void \u0031FB32EC2(ref \u00331E30ACC _param1, int _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  private void \u00314B665A4(uint _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal void \u00375E659AE(ref \u00331E30ACC _param1, ref \u00331E30ACC _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  private static uint \u003579D6D26(ref \u00331E30ACC _param0, uint _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  internal void \u0031CFD20D3(ref \u00331E30ACC _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  private static void \u0036D2E0AB6(
    ref \u00331E30ACC _param0,
    ref \u00331E30ACC _param1,
    bool _param2,
    ref \u00331E30ACC _param3)
  {
    // ISSUE: unable to decompile the method.
  }

  private static uint \u0034BC21765(ref uint _param0, uint _param1, uint _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  private static uint \u0033517135C(ref uint _param0, uint _param1, uint _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  private static uint \u00366EF23C2(ref uint _param0, uint _param1, uint _param2, uint _param3)
  {
    // ISSUE: unable to decompile the method.
  }
}
