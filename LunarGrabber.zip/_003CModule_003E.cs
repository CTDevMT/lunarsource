﻿// Decompiled with JetBrains decompiler
// Type: <Module>
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

internal class \u003CModule\u003E
{
  private static void \u00313FF1363()
  {
    // ISSUE: unable to decompile the method.
  }

  static \u003CModule\u003E() => new \u0031C561093().\u00335B818BE((object[]) null, 25703200);
}
