﻿// Decompiled with JetBrains decompiler
// Type: 47040C12
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;
using System.Runtime.InteropServices;

public class \u00347040C12
{
  private static uint[] \u00321747DFF;

  public \u00347040C12()
  {
    if (\u00347040C12.\u00321747DFF != null)
      return;
    \u00347040C12.\u00321747DFF = new uint[256];
    for (int index1 = 0; index1 < 256; ++index1)
    {
      uint num = (uint) index1;
      for (int index2 = 0; index2 < 8; ++index2)
      {
        if (((int) num & 1) == 1)
          num = num >> 1 ^ 3988292384U;
        else
          num >>= 1;
      }
      \u00347040C12.\u00321747DFF[index1] = num;
    }
  }

  public uint \u0032A7A24BB(IntPtr _param1, uint _param2)
  {
    uint num = 0;
    for (int index = 0; (long) index < (long) _param2; ++index)
      num = \u00347040C12.\u00321747DFF[((int) Marshal.ReadByte(new IntPtr(_param1.ToInt64() + (long) index)) ^ (int) num) & (int) byte.MaxValue] ^ num >> 8;
    return ~num;
  }
}
