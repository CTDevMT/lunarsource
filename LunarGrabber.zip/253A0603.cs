﻿// Decompiled with JetBrains decompiler
// Type: 253A0603
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;

[CompilerGenerated]
internal static class \u003253A0603
{
  private static object HelloSkid;
  private static Dictionary<string, bool> HelloSkid;
  private static Dictionary<string, string> HelloSkid;
  private static Dictionary<string, string> HelloSkid;
  private static int HelloSkid;

  private static string HelloSkid(CultureInfo HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  private static Assembly HelloSkid(AssemblyName HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  private static void HelloSkid(Stream HelloSkid, Stream HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  private static Stream HelloSkid(string HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  private static Stream HelloSkid(Dictionary<string, string> HelloSkid, string HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  private static byte[] HelloSkid(Stream HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  private static Assembly HelloSkid(
    Dictionary<string, string> HelloSkid,
    Dictionary<string, string> HelloSkid,
    AssemblyName HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  public static Assembly HelloSkid(object HelloSkid, ResolveEventArgs HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  static \u003253A0603()
  {
    // ISSUE: unable to decompile the method.
  }

  public static void HelloSkid()
  {
    // ISSUE: unable to decompile the method.
  }
}
