﻿// Decompiled with JetBrains decompiler
// Type: 3F6A510B
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System.Runtime.InteropServices;

public class \u0033F6A510B
{
  private const int \u003652F012E = 15;
  private const int \u0034EF15414 = 8;
  private const int \u0033E5703BE = 2;
  private const int \u00313683F7B = 32;
  private readonly uint[] \u00379F95E8C;
  private const uint \u003441C2B43 = 4207804417;
  private const uint \u003793C6437 = 4207804418;

  public \u0033F6A510B(byte[] _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  private void \u00361AA3AF3(ref \u0033F6A510B.\u00347A77523 _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  private void \u0033A965269(ref \u0033F6A510B.\u00347A77523 _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  public byte[] \u0035B3052C9(byte[] _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  public byte[] \u0036E262DC5(byte[] _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  public void \u003313339B9(byte[] _param1, byte[] _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  public void \u0031AA82F8A(byte[] _param1, byte[] _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  [StructLayout(LayoutKind.Explicit)]
  private struct \u00347A77523
  {
    [FieldOffset(0)]
    public ulong \u00376FA4E42;
    [FieldOffset(0)]
    public uint \u0037EEF228B;
    [FieldOffset(4)]
    public uint \u0034B413933;
  }
}
