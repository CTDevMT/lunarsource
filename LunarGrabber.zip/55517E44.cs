﻿// Decompiled with JetBrains decompiler
// Type: 55517E44
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;

[Flags]
public enum \u00355517E44
{
  Success = 0,
  Corrupted = 1,
  Invalid = 2,
  Blacklisted = 4,
  DateExpired = 8,
  RunningTimeOver = 16, // 0x00000010
  BadHwid = 32, // 0x00000020
  MaxBuildExpired = 64, // 0x00000040
}
