﻿// Decompiled with JetBrains decompiler
// Type: 384D0CBD
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
internal sealed class \u003384D0CBD
{
  internal static readonly \u003384D0CBD.\u0030D1E51C4 \u0037C803DB2;
  internal static readonly \u003384D0CBD.\u00379FF1A7C \u003019F347D;

  [StructLayout(LayoutKind.Explicit, Size = 26, Pack = 1)]
  private struct \u0030D1E51C4
  {
  }

  [StructLayout(LayoutKind.Explicit, Size = 30, Pack = 1)]
  private struct \u00379FF1A7C
  {
  }
}
