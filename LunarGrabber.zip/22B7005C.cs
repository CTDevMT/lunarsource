﻿// Decompiled with JetBrains decompiler
// Type: 22B7005C
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

public static class \u00322B7005C
{
  public static object[] \u0033D677FF6;

  internal static bool \u00315B47004(byte[] _param0)
  {
    for (int index = 0; index < _param0.Length; ++index)
    {
      if (index + 3 < _param0.Length && _param0[index] == (byte) 81 && (_param0[index + 1] == (byte) 69 && _param0[index + 2] == (byte) 77) && _param0[index + 3] == (byte) 85 || index + 8 < _param0.Length && _param0[index] == (byte) 77 && (_param0[index + 1] == (byte) 105 && _param0[index + 2] == (byte) 99) && (_param0[index + 3] == (byte) 114 && _param0[index + 4] == (byte) 111 && (_param0[index + 5] == (byte) 115 && _param0[index + 6] == (byte) 111)) && (_param0[index + 7] == (byte) 102 && _param0[index + 8] == (byte) 116) || (index + 6 < _param0.Length && _param0[index] == (byte) 105 && (_param0[index + 1] == (byte) 110 && _param0[index + 2] == (byte) 110) && (_param0[index + 3] == (byte) 111 && _param0[index + 4] == (byte) 116 && (_param0[index + 5] == (byte) 101 && _param0[index + 6] == (byte) 107)) || index + 9 < _param0.Length && _param0[index] == (byte) 86 && (_param0[index + 1] == (byte) 105 && _param0[index + 2] == (byte) 114) && (_param0[index + 3] == (byte) 116 && _param0[index + 4] == (byte) 117 && (_param0[index + 5] == (byte) 97 && _param0[index + 6] == (byte) 108)) && (_param0[index + 7] == (byte) 66 && _param0[index + 8] == (byte) 111 && _param0[index + 9] == (byte) 120)) || (index + 5 < _param0.Length && _param0[index] == (byte) 86 && (_param0[index + 1] == (byte) 77 && _param0[index + 2] == (byte) 119) && (_param0[index + 3] == (byte) 97 && _param0[index + 4] == (byte) 114 && _param0[index + 5] == (byte) 101) || index + 8 < _param0.Length && _param0[index] == (byte) 80 && (_param0[index + 1] == (byte) 97 && _param0[index + 2] == (byte) 114) && (_param0[index + 3] == (byte) 97 && _param0[index + 4] == (byte) 108 && (_param0[index + 5] == (byte) 108 && _param0[index + 6] == (byte) 101)) && (_param0[index + 7] == (byte) 108 && _param0[index + 8] == (byte) 115)))
        return true;
    }
    return false;
  }
}
