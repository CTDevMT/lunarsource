﻿// Decompiled with JetBrains decompiler
// Type: 1C561093
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Threading;

public class \u0031C561093
{
  private readonly Dictionary<uint, \u0031C561093.\u00329503060> \u003342620F1;
  private readonly Module \u00318CB0DB9;
  private readonly long \u00313EB2311;
  private int \u0035E5D486B;
  private Type \u00373E03C56;
  private Stack<\u0031C561093.\u0033AF92E6D> \u0032B654A18;
  private static readonly Dictionary<int, object> \u0031ACB10FF;
  private static readonly Dictionary<MethodBase, DynamicMethod> \u003696E132D;
  private List<\u0031C561093.\u00304BE210E> \u00310372FF8;
  private List<\u0031C561093.\u0037BC90C3B> \u0033B070E12;
  private Stack<\u0031C561093.\u0037BC90C3B> \u0035EBC5C0D;
  private Stack<int> \u00370214200;
  private Exception \u0034B807558;
  private \u0031C561093.\u0037B071B97 \u00319B82813;
  private List<IntPtr> \u00326FE16FB;

  public \u0031C561093()
  {
label_0:
    uint num1;
    do
    {
      uint num2;
      do
      {
        uint num3 = 1847276293;
        this.\u003342620F1 = new Dictionary<uint, \u0031C561093.\u00329503060>();
        uint num4 = num3 / 1008882900U;
label_1:
        uint num5 = 1280136525U & num4;
        Type type = typeof (\u0031C561093);
        uint num6 = num5 / 1108803742U;
        this.\u00318CB0DB9 = type.Module;
        uint num7 = num6 / 784949204U;
label_2:
        uint num8 = num7 % 1410823482U;
        this.\u0032B654A18 = new Stack<\u0031C561093.\u0033AF92E6D>();
        uint num9 = 873074052U >> (int) num8;
        if (num9 != 1503920166U)
        {
label_3:
          this.\u00310372FF8 = new List<\u0031C561093.\u00304BE210E>();
label_4:
          List<\u0031C561093.\u0037BC90C3B> objList = new List<\u0031C561093.\u0037BC90C3B>();
          uint num10 = 1060728979U + num9;
          this.\u0033B070E12 = objList;
          num4 = num10 << 23;
          if (1418539509U >= num4)
          {
label_5:
            do
            {
              uint num11 = 198711231U / num4;
              Stack<\u0031C561093.\u0037BC90C3B> objStack = new Stack<\u0031C561093.\u0037BC90C3B>();
              num4 = 1873891547U + num11;
              this.\u0035EBC5C0D = objStack;
              if (num4 != 469966296U)
              {
label_6:
                do
                {
                  do
                  {
                    Stack<int> intStack = new Stack<int>();
                    uint num12 = num4 << 9;
                    this.\u00370214200 = intStack;
                    uint num13 = num12 / 577595034U;
label_7:
                    List<IntPtr> numList = new List<IntPtr>();
                    uint num14 = 1342258342U / num13;
                    this.\u00326FE16FB = numList;
                    if (num14 < 1359677136U)
                    {
                      // ISSUE: explicit constructor call
                      base.\u002Ector();
                      if (613566969U != num14)
                      {
                        do
                        {
                          uint num15 = (287991085U ^ num14) + 1927239143U;
                          IntPtr hinstance = Marshal.GetHINSTANCE(this.\u00318CB0DB9);
                          uint num16 = 1804281658U + num15;
                          IntPtr num17 = hinstance;
                          uint num18 = 430057615U % num16;
                          long int64 = num17.ToInt64();
                          uint num19 = num18 % 2146698002U;
                          this.\u00313EB2311 = int64;
                          num7 = 2032669591U * num19;
                          if (1977687830 << (int) num7 != 0)
                          {
                            uint num20 = num7 >> 5;
                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary1 = this.\u003342620F1;
                            uint num21 = num20 % 153377759U;
                            int num22 = (int) num21 - 10507444;
                            uint num23 = 1955348314U * num21;
                            // ISSUE: method pointer
                            IntPtr num24 = __methodptr(\u003304C55CE);
                            uint num25 = num23 - 149172681U;
                            \u0031C561093.\u00329503060 obj1 = new \u0031C561093.\u00329503060((object) this, num24);
                            uint num26 = num25 ^ 1993216442U;
                            dictionary1[(uint) num22] = obj1;
                            uint num27 = 465642065U / num26;
                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary2 = this.\u003342620F1;
                            int num28 = (int) num27 ^ 1;
                            uint num29 = 2060612654U | num27;
                            // ISSUE: method pointer
                            IntPtr num30 = __methodptr(\u0032F1B1F02);
                            num4 = 2097566275U >> (int) num29;
                            \u0031C561093.\u00329503060 obj2 = new \u0031C561093.\u00329503060((object) this, num30);
                            dictionary2[(uint) num28] = obj2;
                            if (835796221 - (int) num4 != 0)
                            {
                              uint num31 = num4 | 1921604877U;
                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary3 = this.\u003342620F1;
                              int num32 = (int) num31 ^ 1921645855;
                              \u0031C561093.\u00329503060 obj3 = new \u0031C561093.\u00329503060(this.\u00347A16E6D);
                              num4 = num31 - 1806719557U;
                              dictionary3[(uint) num32] = obj3;
                              if (46486940U <= num4)
                              {
                                uint num33 = num4 & 1840256513U;
                                this.\u003342620F1[num33 ^ 76546563U] = new \u0031C561093.\u00329503060(this.\u00337533FAF);
                                num9 = 746732462U ^ num33;
                                if (1742481967U > num9)
                                {
                                  uint num34 = num9 + 589111744U;
                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary4 = this.\u003342620F1;
                                  int num35 = (int) num34 ^ 1261394794;
                                  uint num36 = num34 * 1026047019U;
                                  // ISSUE: method pointer
                                  IntPtr num37 = __methodptr(\u00354024839);
                                  uint num38 = num36 | 1788020659U;
                                  \u0031C561093.\u00329503060 obj4 = new \u0031C561093.\u00329503060((object) this, num37);
                                  dictionary4[(uint) num35] = obj4;
                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary5 = this.\u003342620F1;
                                  int num39 = (int) num38 - 2073241590;
                                  uint num40 = num38 << 18;
                                  \u0031C561093.\u00329503060 obj5 = new \u0031C561093.\u00329503060(this.\u0031B2E2C56);
                                  dictionary5[(uint) num39] = obj5;
                                  uint num41 = num40 & 128465353U;
                                  if ((int) num41 + 509107234 != 0)
                                  {
                                    uint num42 = num41 - 2094610168U;
                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary6 = this.\u003342620F1;
                                    int num43 = (int) num42 - -1966159614;
                                    uint num44 = 2147184007U << (int) num42;
                                    // ISSUE: method pointer
                                    IntPtr num45 = __methodptr(\u00333AC5930);
                                    num4 = num44 >> 0;
                                    \u0031C561093.\u00329503060 obj6 = new \u0031C561093.\u00329503060((object) this, num45);
                                    dictionary6[(uint) num43] = obj6;
                                    if ((int) num4 + 1410663289 != 0)
                                    {
                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary7 = this.\u003342620F1;
                                      uint num46 = 411458335U % num4;
                                      int num47 = (int) num46 ^ 411458328;
                                      uint num48 = 775890817U | num46;
                                      // ISSUE: method pointer
                                      IntPtr num49 = __methodptr(\u003772121CE);
                                      uint num50 = num48 << 21;
                                      \u0031C561093.\u00329503060 obj7 = new \u0031C561093.\u00329503060((object) this, num49);
                                      dictionary7[(uint) num47] = obj7;
                                      uint num51 = 44527894U % (1823278200U >> (int) num50);
                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary8 = this.\u003342620F1;
                                      int num52 = (int) num51 - 44527886;
                                      uint num53 = num51 / 1128011532U;
                                      // ISSUE: method pointer
                                      \u0031C561093.\u00329503060 obj8 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u003598D2D17));
                                      dictionary8[(uint) num52] = obj8;
                                      uint num54 = 518528868U >> (int) num53;
                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary9 = this.\u003342620F1;
                                      uint num55 = 1896419069U | num54;
                                      int num56 = (int) num55 - 2145984500;
                                      uint num57 = 281762298U / num55;
                                      // ISSUE: method pointer
                                      \u0031C561093.\u00329503060 obj9 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00327F109A3));
                                      dictionary9[(uint) num56] = obj9;
                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary10 = this.\u003342620F1;
                                      uint num58 = num57 << 0;
                                      int num59 = (int) num58 ^ 10;
                                      \u0031C561093.\u00329503060 obj10 = new \u0031C561093.\u00329503060(this.\u00305881923);
                                      uint num60 = 1404187336U * num58;
                                      dictionary10[(uint) num59] = obj10;
                                      num4 = 386213945U >> (int) num60;
                                      if (988824413 << (int) num4 != 0)
                                      {
                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary11 = this.\u003342620F1;
                                        uint num61 = 535562180U & num4;
                                        int num62 = (int) num61 - 386138101;
                                        uint num63 = num61 << 12;
                                        \u0031C561093.\u00329503060 obj11 = new \u0031C561093.\u00329503060(this.\u00351CA2101);
                                        uint num64 = 1107956436U % num63;
                                        dictionary11[(uint) num62] = obj11;
                                        uint num65 = 2088046262U << (int) num64;
                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary12 = this.\u003342620F1;
                                        int num66 = (int) num65 ^ -346030068;
                                        uint num67 = num65 - 637688820U;
                                        // ISSUE: method pointer
                                        \u0031C561093.\u00329503060 obj12 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00379083E9E));
                                        dictionary12[(uint) num66] = obj12;
                                        num7 = num67 - 2095909158U;
                                        if (num7 != 1915252460U)
                                        {
                                          uint num68 = 1546986616U + num7;
                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary13 = this.\u003342620F1;
                                          uint num69 = num68 & 1406819459U;
                                          int num70 = (int) num69 - 8395765;
                                          uint num71 = 1197480828U >> (int) num69;
                                          // ISSUE: method pointer
                                          IntPtr num72 = __methodptr(\u003006C3635);
                                          uint num73 = num71 >> 25;
                                          \u0031C561093.\u00329503060 obj13 = new \u0031C561093.\u00329503060((object) this, num72);
                                          uint num74 = num73 | 1338460303U;
                                          dictionary13[(uint) num70] = obj13;
                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary14 = this.\u003342620F1;
                                          uint num75 = num74 ^ 193004316U;
                                          int num76 = (int) num75 ^ 1145457565;
                                          uint num77 = num75 >> 22 ^ 701699307U;
                                          // ISSUE: method pointer
                                          \u0031C561093.\u00329503060 obj14 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0036E501963));
                                          uint num78 = 1248669582U % num77;
                                          dictionary14[(uint) num76] = obj14;
                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary15 = this.\u003342620F1;
                                          int num79 = (int) num78 - 546969989;
                                          // ISSUE: method pointer
                                          IntPtr num80 = __methodptr(\u0032098468E);
                                          uint num81 = 1830518475U + num78;
                                          \u0031C561093.\u00329503060 obj15 = new \u0031C561093.\u00329503060((object) this, num80);
                                          num4 = num81 ^ 1328839297U;
                                          dictionary15[(uint) num79] = obj15;
                                          if ((int) num4 << 19 != 0)
                                          {
                                            uint num82 = 945492231U & num4;
                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary16 = this.\u003342620F1;
                                            int num83 = (int) num82 ^ 65558;
                                            uint num84 = num82 ^ 262418045U;
                                            // ISSUE: method pointer
                                            IntPtr num85 = __methodptr(\u0034DC16D57);
                                            uint num86 = num84 - 850202759U;
                                            \u0031C561093.\u00329503060 obj16 = new \u0031C561093.\u00329503060((object) this, num85);
                                            uint num87 = 1613307532U - num86;
                                            dictionary16[(uint) num83] = obj16;
                                            uint num88 = 2030982347U ^ (num87 | 1613777092U);
                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary17 = this.\u003342620F1;
                                            uint num89 = num88 & 1673723937U;
                                            int num90 = (int) num89 ^ 33751056;
                                            uint num91 = num89 - 1001158328U;
                                            // ISSUE: method pointer
                                            \u0031C561093.\u00329503060 obj17 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00322825D79));
                                            dictionary17[(uint) num90] = obj17;
                                            num4 = 1070745673U | num91;
                                            if (num4 >= 1524908090U)
                                            {
                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary18 = this.\u003342620F1;
                                              int num92 = (int) num4 ^ -2700965;
                                              uint num93 = 1639527091U & num4;
                                              // ISSUE: method pointer
                                              \u0031C561093.\u00329503060 obj18 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00375C44302));
                                              uint num94 = num93 | 1714755191U;
                                              dictionary18[(uint) num92] = obj18;
                                              uint num95 = (num94 ^ 16534227U) & 1579430815U;
                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary19 = this.\u003342620F1;
                                              uint num96 = num95 & 2109669666U;
                                              int num97 = (int) num96 ^ 1140850707;
                                              uint num98 = 72697419U - num96;
                                              \u0031C561093.\u00329503060 obj19 = new \u0031C561093.\u00329503060(this.\u0037E5F7AB9);
                                              dictionary19[(uint) num97] = obj19;
                                              uint num99 = 949961962U % num98;
                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary20 = this.\u003342620F1;
                                              uint num100 = 522072397U % num99;
                                              int num101 = (int) num100 ^ 522072409;
                                              \u0031C561093.\u00329503060 obj20 = new \u0031C561093.\u00329503060(this.\u003661818BC);
                                              dictionary20[(uint) num101] = obj20;
                                              uint num102 = 986471566U - num100;
                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary21 = this.\u003342620F1;
                                              uint num103 = num102 >> 4;
                                              int num104 = (int) num103 ^ 29024929;
                                              num4 = num103 & 680657844U;
                                              // ISSUE: method pointer
                                              \u0031C561093.\u00329503060 obj21 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0033D7426D0));
                                              dictionary21[(uint) num104] = obj21;
                                              if (num4 != 304958472U)
                                              {
                                                uint num105 = 846617161U ^ num4;
                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary22 = this.\u003342620F1;
                                                uint num106 = 1447953343U / num105;
                                                int num107 = (int) num106 ^ 23;
                                                // ISSUE: method pointer
                                                IntPtr num108 = __methodptr(\u00378242571);
                                                uint num109 = 1688824833U + num106;
                                                \u0031C561093.\u00329503060 obj22 = new \u0031C561093.\u00329503060((object) this, num108);
                                                uint num110 = num109 & 1794581482U;
                                                dictionary22[(uint) num107] = obj22;
                                                uint num111 = 1452674735U ^ num110;
                                                if (74255908U <= num111)
                                                {
                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary23 = this.\u003342620F1;
                                                  uint num112 = 385944282U & num111;
                                                  int num113 = (int) num112 ^ 369167007;
                                                  uint num114 = 1130395352U * num112 >> 19;
                                                  // ISSUE: method pointer
                                                  \u0031C561093.\u00329503060 obj23 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00369EE2472));
                                                  uint num115 = 1960131397U / num114;
                                                  dictionary23[(uint) num113] = obj23;
                                                  if (495129970U != num115)
                                                  {
                                                    uint num116 = num115 / 1086130363U;
                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary24 = this.\u003342620F1;
                                                    int num117 = (int) num116 ^ 24;
                                                    uint num118 = num116 + 1407870978U;
                                                    // ISSUE: method pointer
                                                    IntPtr num119 = __methodptr(\u00317465818);
                                                    uint num120 = num118 % 1160452923U;
                                                    \u0031C561093.\u00329503060 obj24 = new \u0031C561093.\u00329503060((object) this, num119);
                                                    dictionary24[(uint) num117] = obj24;
                                                    if (num120 != 1651074036U)
                                                    {
                                                      uint num121 = num120 & 1800749519U;
                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary25 = this.\u003342620F1;
                                                      int num122 = (int) num121 - 169164974;
                                                      // ISSUE: method pointer
                                                      IntPtr num123 = __methodptr(\u00363AE4409);
                                                      uint num124 = 1561808698U - num121;
                                                      \u0031C561093.\u00329503060 obj25 = new \u0031C561093.\u00329503060((object) this, num123);
                                                      dictionary25[(uint) num122] = obj25;
                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary26 = this.\u003342620F1;
                                                      uint num125 = 1735018223U & num124;
                                                      int num126 = (int) num125 - 1124206153;
                                                      uint num127 = 621032919U >> (int) (num125 + 420037740U);
                                                      // ISSUE: method pointer
                                                      \u0031C561093.\u00329503060 obj26 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0035A337EF5));
                                                      uint num128 = num127 << 9;
                                                      dictionary26[(uint) num126] = obj26;
                                                      uint num129 = num128 * 1725105692U;
                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary27 = this.\u003342620F1;
                                                      int num130 = (int) num129 ^ -1198407653;
                                                      // ISSUE: method pointer
                                                      IntPtr num131 = __methodptr(\u0031F287E0C);
                                                      uint num132 = num129 % 654993726U;
                                                      \u0031C561093.\u00329503060 obj27 = new \u0031C561093.\u00329503060((object) this, num131);
                                                      uint num133 = 1014593484U ^ num132;
                                                      dictionary27[(uint) num130] = obj27;
                                                      uint num134 = 1810524199U & num133;
                                                      if (621282252 + (int) num134 != 0)
                                                      {
                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary28 = this.\u003342620F1;
                                                        uint num135 = 1478259974U / num134;
                                                        int num136 = (int) num135 ^ 30;
                                                        // ISSUE: method pointer
                                                        IntPtr num137 = __methodptr(\u003019B1616);
                                                        num7 = 177999549U & num135;
                                                        \u0031C561093.\u00329503060 obj28 = new \u0031C561093.\u00329503060((object) this, num137);
                                                        dictionary28[(uint) num136] = obj28;
                                                        if ((1518410132 ^ (int) num7) != 0)
                                                        {
                                                          uint num138 = 1061371643U - num7;
                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary29 = this.\u003342620F1;
                                                          uint num139 = 1956131203U | num138;
                                                          int num140 = (int) num139 - 2145075166;
                                                          uint num141 = 1323114382U % (num139 % 2036405106U);
                                                          // ISSUE: method pointer
                                                          \u0031C561093.\u00329503060 obj29 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00334DD32D5));
                                                          dictionary29[(uint) num140] = obj29;
                                                          uint num142 = 1590576867U / num141;
                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary30 = this.\u003342620F1;
                                                          uint num143 = 1180965264U * num142;
                                                          int num144 = (int) num143 - -764130926;
                                                          // ISSUE: method pointer
                                                          IntPtr num145 = __methodptr(\u00301B65D58);
                                                          uint num146 = 1911492605U + num143;
                                                          \u0031C561093.\u00329503060 obj30 = new \u0031C561093.\u00329503060((object) this, num145);
                                                          uint num147 = 1057829525U + num146;
                                                          dictionary30[(uint) num144] = obj30;
                                                          uint num148 = (1259864702U | num147) * 1623416854U;
                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary31 = this.\u003342620F1;
                                                          uint num149 = 431689439U >> (int) num148;
                                                          int num150 = (int) num149 - 380;
                                                          num9 = 628438543U >> (int) num149;
                                                          // ISSUE: method pointer
                                                          \u0031C561093.\u00329503060 obj31 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u003253C5A20));
                                                          dictionary31[(uint) num150] = obj31;
                                                          if (num9 < 657741304U)
                                                          {
                                                            uint num151 = num9 & 1934061661U;
                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary32 = this.\u003342620F1;
                                                            uint num152 = num151 * 1545109473U;
                                                            int num153 = (int) num152 - 1885470564;
                                                            uint num154 = 1315843622U >> (int) (1002062309U ^ num152);
                                                            // ISSUE: method pointer
                                                            IntPtr num155 = __methodptr(\u00372474421);
                                                            uint num156 = 155869670U | num154;
                                                            \u0031C561093.\u00329503060 obj32 = new \u0031C561093.\u00329503060((object) this, num155);
                                                            dictionary32[(uint) num153] = obj32;
                                                            uint num157 = 1568354763U | num156;
                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary33 = this.\u003342620F1;
                                                            int num158 = (int) num157 ^ 2139060190;
                                                            uint num159 = (num157 ^ 165103438U) * 300162115U;
                                                            // ISSUE: method pointer
                                                            IntPtr num160 = __methodptr(\u00363B91F43);
                                                            uint num161 = 703428069U % num159;
                                                            \u0031C561093.\u00329503060 obj33 = new \u0031C561093.\u00329503060((object) this, num160);
                                                            num4 = num161 * 415984171U;
                                                            dictionary33[(uint) num158] = obj33;
                                                            if (1213477789 << (int) num4 != 0)
                                                            {
                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary34 = this.\u003342620F1;
                                                              int num162 = (int) num4 - 1380622165;
                                                              uint num163 = num4 >> 28;
                                                              \u0031C561093.\u00329503060 obj34 = new \u0031C561093.\u00329503060(this.\u0032E270349);
                                                              uint num164 = 860635890U & num163;
                                                              dictionary34[(uint) num162] = obj34;
                                                              uint num165 = 824314887U | num164;
                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary35 = this.\u003342620F1;
                                                              uint num166 = num165 ^ 2028215604U;
                                                              int num167 = (int) num166 ^ 1237717264;
                                                              uint num168 = 2134840770U | num166;
                                                              // ISSUE: method pointer
                                                              IntPtr num169 = __methodptr(\u0034ECD6316);
                                                              uint num170 = 1642231107U << (int) num168;
                                                              \u0031C561093.\u00329503060 obj35 = new \u0031C561093.\u00329503060((object) this, num169);
                                                              dictionary35[(uint) num167] = obj35;
                                                              num9 = num170 + 959120651U;
                                                              if (852626097U < num9)
                                                              {
                                                                uint num171 = 1224900585U & num9;
                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary36 = this.\u003342620F1;
                                                                uint num172 = 1206732698U % num171;
                                                                int num173 = (int) num172 ^ 116081333;
                                                                uint num174 = 88624657U / num172;
                                                                \u0031C561093.\u00329503060 obj36 = new \u0031C561093.\u00329503060(this.\u0033B5C3155);
                                                                uint num175 = num174 | 818630609U;
                                                                dictionary36[(uint) num173] = obj36;
                                                                uint num176 = num175 & 70983349U;
                                                                if (42362235 - (int) num176 != 0)
                                                                {
                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary37 = this.\u003342620F1;
                                                                  uint num177 = 2051701976U * num176;
                                                                  int num178 = (int) num177 ^ -1270053251;
                                                                  uint num179 = 1750092572U * num177 ^ 1983729614U;
                                                                  // ISSUE: method pointer
                                                                  \u0031C561093.\u00329503060 obj37 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00326700CB8));
                                                                  dictionary37[(uint) num178] = obj37;
                                                                  num7 = num179 ^ 1329491665U;
                                                                  if (1737647381 << (int) num7 != 0)
                                                                  {
                                                                    uint num180 = num7 >> 28;
                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary38 = this.\u003342620F1;
                                                                    int num181 = (int) num180 + 24;
                                                                    uint num182 = num180 + 419966821U;
                                                                    // ISSUE: method pointer
                                                                    \u0031C561093.\u00329503060 obj38 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u003148208EA));
                                                                    uint num183 = num182 ^ 1746031679U;
                                                                    dictionary38[(uint) num181] = obj38;
                                                                    uint num184 = num183 / 687741212U % 2110525643U;
                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary39 = this.\u003342620F1;
                                                                    int num185 = (int) num184 ^ 37;
                                                                    uint num186 = num184 / 367409360U;
                                                                    // ISSUE: method pointer
                                                                    IntPtr num187 = __methodptr(\u00325E44E64);
                                                                    uint num188 = 1137341772U >> (int) num186;
                                                                    \u0031C561093.\u00329503060 obj39 = new \u0031C561093.\u00329503060((object) this, num187);
                                                                    uint num189 = num188 & 220295493U;
                                                                    dictionary39[(uint) num185] = obj39;
                                                                    uint num190 = num189 % 342236615U;
                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary40 = this.\u003342620F1;
                                                                    uint num191 = num190 | 612172559U;
                                                                    int num192 = (int) num191 ^ 628978535;
                                                                    uint num193 = num191 * 1567784168U - 1684940115U;
                                                                    // ISSUE: method pointer
                                                                    \u0031C561093.\u00329503060 obj40 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0032E881566));
                                                                    dictionary40[(uint) num192] = obj40;
                                                                    uint num194 = 1429041030U ^ num193;
                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary41 = this.\u003342620F1;
                                                                    uint num195 = num194 ^ 1847935043U;
                                                                    int num196 = (int) num195 ^ 1581429161;
                                                                    uint num197 = 1222795276U | 29313323U ^ num195;
                                                                    // ISSUE: method pointer
                                                                    \u0031C561093.\u00329503060 obj41 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0034D8821C6));
                                                                    uint num198 = num197 * 740385856U;
                                                                    dictionary41[(uint) num196] = obj41;
                                                                    uint num199 = 1851786077U & num198;
                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary42 = this.\u003342620F1;
                                                                    int num200 = (int) num199 ^ 236979050;
                                                                    uint num201 = 130380548U - num199;
                                                                    // ISSUE: method pointer
                                                                    IntPtr num202 = __methodptr(\u0034ADE09E8);
                                                                    uint num203 = 536416244U >> (int) num201;
                                                                    \u0031C561093.\u00329503060 obj42 = new \u0031C561093.\u00329503060((object) this, num202);
                                                                    num4 = 1720137095U + num203;
                                                                    dictionary42[(uint) num200] = obj42;
                                                                    if (num4 < 1856725467U)
                                                                    {
                                                                      uint num204 = num4 ^ 1464288994U;
                                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary43 = this.\u003342620F1;
                                                                      int num205 = (int) num204 - 1069645881;
                                                                      uint num206 = 1930038495U & num204;
                                                                      // ISSUE: method pointer
                                                                      IntPtr num207 = __methodptr(\u0030D231658);
                                                                      uint num208 = 1691493825U >> (int) num206;
                                                                      \u0031C561093.\u00329503060 obj43 = new \u0031C561093.\u00329503060((object) this, num207);
                                                                      uint num209 = 862257341U - num208;
                                                                      dictionary43[(uint) num205] = obj43;
                                                                      uint num210 = num209 & 1327634913U;
                                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary44 = this.\u003342620F1;
                                                                      int num211 = (int) num210 ^ 218241101;
                                                                      \u0031C561093.\u00329503060 obj44 = new \u0031C561093.\u00329503060(this.\u00361DF0502);
                                                                      num4 = 1475559083U << (int) num210;
                                                                      dictionary44[(uint) num211] = obj44;
                                                                      if (num4 != 934884778U)
                                                                      {
                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary45 = this.\u003342620F1;
                                                                        uint num212 = 586023509U + num4;
                                                                        int num213 = (int) num212 ^ -757825658;
                                                                        uint num214 = num212 & 1994213219U;
                                                                        // ISSUE: method pointer
                                                                        IntPtr num215 = __methodptr(\u00306AB7707);
                                                                        uint num216 = 1216176524U + num214;
                                                                        \u0031C561093.\u00329503060 obj45 = new \u0031C561093.\u00329503060((object) this, num215);
                                                                        uint num217 = 1209270641U % num216;
                                                                        dictionary45[(uint) num213] = obj45;
                                                                        uint num218 = num217 / 895945225U;
                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary46 = this.\u003342620F1;
                                                                        uint num219 = num218 * 143882625U;
                                                                        int num220 = (int) num219 - 143882579;
                                                                        num7 = 965150312U + num219;
                                                                        \u0031C561093.\u00329503060 obj46 = new \u0031C561093.\u00329503060(this.\u0034722764A);
                                                                        dictionary46[(uint) num220] = obj46;
                                                                        if (num7 / 388393326U != 0U)
                                                                        {
                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary47 = this.\u003342620F1;
                                                                          uint num221 = num7 << 10;
                                                                          int num222 = (int) num221 ^ 1778361391;
                                                                          // ISSUE: method pointer
                                                                          IntPtr num223 = __methodptr(\u00368797CCB);
                                                                          uint num224 = num221 << 24;
                                                                          \u0031C561093.\u00329503060 obj47 = new \u0031C561093.\u00329503060((object) this, num223);
                                                                          dictionary47[(uint) num222] = obj47;
                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary48 = this.\u003342620F1;
                                                                          uint num225 = 1027080428U + num224;
                                                                          int num226 = (int) num225 - 1027080380;
                                                                          uint num227 = 1360284870U >> (int) num225 >> 0;
                                                                          // ISSUE: method pointer
                                                                          IntPtr num228 = __methodptr(\u00345220DC2);
                                                                          uint num229 = num227 % 151002457U;
                                                                          \u0031C561093.\u00329503060 obj48 = new \u0031C561093.\u00329503060((object) this, num228);
                                                                          dictionary48[(uint) num226] = obj48;
                                                                          uint num230 = 105729507U / num229;
                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary49 = this.\u003342620F1;
                                                                          uint num231 = 1664746413U % num230;
                                                                          int num232 = (int) num231 ^ 242;
                                                                          uint num233 = 338509463U / num231;
                                                                          \u0031C561093.\u00329503060 obj49 = new \u0031C561093.\u00329503060(this.\u003480E7F57);
                                                                          dictionary49[(uint) num232] = obj49;
                                                                          uint num234 = 1762221573U + num233;
                                                                          if ((228209585 ^ (int) num234) != 0)
                                                                          {
                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary50 = this.\u003342620F1;
                                                                            uint num235 = num234 & 187397456U;
                                                                            int num236 = (int) num235 - 153309390;
                                                                            uint num237 = 1661614233U ^ num235 + 342255657U;
                                                                            // ISSUE: method pointer
                                                                            IntPtr num238 = __methodptr(\u003417C37F2);
                                                                            uint num239 = 1391733645U - num237;
                                                                            \u0031C561093.\u00329503060 obj50 = new \u0031C561093.\u00329503060((object) this, num238);
                                                                            dictionary50[(uint) num236] = obj50;
                                                                            uint num240 = 129642625U * num239;
                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary51 = this.\u003342620F1;
                                                                            int num241 = (int) num240 + 1573844950;
                                                                            uint num242 = num240 % 135140865U;
                                                                            \u0031C561093.\u00329503060 obj51 = new \u0031C561093.\u00329503060(this.\u0034D6B2980);
                                                                            num7 = num242 + 338516456U;
                                                                            dictionary51[(uint) num241] = obj51;
                                                                            if (1101493276 - (int) num7 != 0)
                                                                            {
                                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary52 = this.\u003342620F1;
                                                                              int num243 = (int) num7 ^ 356821509;
                                                                              uint num244 = num7 & 1372288373U;
                                                                              // ISSUE: method pointer
                                                                              IntPtr num245 = __methodptr(\u003241C3A12);
                                                                              uint num246 = num244 ^ 929719343U;
                                                                              \u0031C561093.\u00329503060 obj52 = new \u0031C561093.\u00329503060((object) this, num245);
                                                                              uint num247 = 1791117281U >> (int) num246;
                                                                              dictionary52[(uint) num243] = obj52;
                                                                              if (295584107U >= num247)
                                                                              {
                                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary53 = this.\u003342620F1;
                                                                                uint num248 = num247 << 21;
                                                                                int num249 = (int) num248 ^ 2097205;
                                                                                uint num250 = num248 / 1768892469U;
                                                                                // ISSUE: method pointer
                                                                                IntPtr num251 = __methodptr(\u0033CB32B5C);
                                                                                uint num252 = 1545022545U >> (int) num250;
                                                                                \u0031C561093.\u00329503060 obj53 = new \u0031C561093.\u00329503060((object) this, num251);
                                                                                uint num253 = num252 << 30;
                                                                                dictionary53[(uint) num249] = obj53;
                                                                                uint num254 = 1740786036U ^ num253;
                                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary54 = this.\u003342620F1;
                                                                                int num255 = (int) num254 - 667044158;
                                                                                uint num256 = num254 - 1983582672U;
                                                                                // ISSUE: method pointer
                                                                                IntPtr num257 = __methodptr(\u00345977C35);
                                                                                uint num258 = 946943951U >> (int) num256;
                                                                                \u0031C561093.\u00329503060 obj54 = new \u0031C561093.\u00329503060((object) this, num257);
                                                                                uint num259 = 247485224U + num258;
                                                                                dictionary54[(uint) num255] = obj54;
                                                                                uint num260 = 299647482U ^ num259;
                                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary55 = this.\u003342620F1;
                                                                                uint num261 = num260 + 2024683667U;
                                                                                int num262 = (int) num261 ^ 2085183430;
                                                                                uint num263 = num261 >> 0;
                                                                                // ISSUE: method pointer
                                                                                IntPtr num264 = __methodptr(\u003413A06CC);
                                                                                uint num265 = num263 >> 15;
                                                                                \u0031C561093.\u00329503060 obj55 = new \u0031C561093.\u00329503060((object) this, num264);
                                                                                uint num266 = 1377792463U & num265;
                                                                                dictionary55[(uint) num262] = obj55;
                                                                                uint num267 = num266 / 1704146767U;
                                                                                if ((int) num267 - 1588012402 != 0)
                                                                                {
                                                                                  uint num268 = num267 << 10;
                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary56 = this.\u003342620F1;
                                                                                  int num269 = (int) num268 - -56;
                                                                                  uint num270 = (num268 | 692531909U) ^ 1503614326U;
                                                                                  // ISSUE: method pointer
                                                                                  \u0031C561093.\u00329503060 obj56 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00367690095));
                                                                                  dictionary56[(uint) num269] = obj56;
                                                                                  uint num271 = num270 ^ 2065643105U;
                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary57 = this.\u003342620F1;
                                                                                  int num272 = (int) num271 ^ 197612011;
                                                                                  // ISSUE: method pointer
                                                                                  IntPtr num273 = __methodptr(\u00301451C01);
                                                                                  uint num274 = num271 * 1860069542U;
                                                                                  \u0031C561093.\u00329503060 obj57 = new \u0031C561093.\u00329503060((object) this, num273);
                                                                                  uint num275 = 2115318770U >> (int) num274;
                                                                                  dictionary57[(uint) num272] = obj57;
                                                                                  if (1145250893U > num275)
                                                                                  {
                                                                                    uint num276 = num275 * 586557444U;
                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary58 = this.\u003342620F1;
                                                                                    uint num277 = 1415927990U + num276;
                                                                                    int num278 = (int) num277 ^ 461100600;
                                                                                    uint num279 = num277 * 1014892080U;
                                                                                    \u0031C561093.\u00329503060 obj58 = new \u0031C561093.\u00329503060(this.\u0033EFF2212);
                                                                                    dictionary58[(uint) num278] = obj58;
                                                                                    uint num280 = (num279 | 126572264U) % 132602664U;
                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary59 = this.\u003342620F1;
                                                                                    uint num281 = 251685607U % num280;
                                                                                    int num282 = (int) num281 - 7291772;
                                                                                    uint num283 = num281 ^ 1103330263U;
                                                                                    \u0031C561093.\u00329503060 obj59 = new \u0031C561093.\u00329503060(this.\u0031D5457E7);
                                                                                    dictionary59[(uint) num282] = obj59;
                                                                                    if (43873325U <= num283)
                                                                                    {
                                                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary60 = this.\u003342620F1;
                                                                                      int num284 = (int) num283 ^ 1101805660;
                                                                                      uint num285 = 1810896457U / num283;
                                                                                      \u0031C561093.\u00329503060 obj60 = new \u0031C561093.\u00329503060(this.\u00355BE1401);
                                                                                      dictionary60[(uint) num284] = obj60;
                                                                                      uint num286 = 873801789U * num285;
                                                                                      if (708460630U < num286)
                                                                                      {
                                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary61 = this.\u003342620F1;
                                                                                        uint num287 = num286 << 22;
                                                                                        int num288 = (int) num287 ^ 255852605;
                                                                                        uint num289 = num287 / 427295005U;
                                                                                        // ISSUE: method pointer
                                                                                        IntPtr num290 = __methodptr(\u0032A890723);
                                                                                        uint num291 = num289 & 670195716U;
                                                                                        \u0031C561093.\u00329503060 obj61 = new \u0031C561093.\u00329503060((object) this, num290);
                                                                                        uint num292 = num291 + 1336166760U;
                                                                                        dictionary61[(uint) num288] = obj61;
                                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary62 = this.\u003342620F1;
                                                                                        int num293 = (int) num292 ^ 1336166742;
                                                                                        uint num294 = 1269438527U | num292;
                                                                                        // ISSUE: method pointer
                                                                                        IntPtr num295 = __methodptr(\u003542961F1);
                                                                                        uint num296 = 678434306U - num294;
                                                                                        \u0031C561093.\u00329503060 obj62 = new \u0031C561093.\u00329503060((object) this, num295);
                                                                                        dictionary62[(uint) num293] = obj62;
                                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary63 = this.\u003342620F1;
                                                                                        int num297 = (int) num296 + 658391996;
                                                                                        num13 = num296 & 1190159186U;
                                                                                        \u0031C561093.\u00329503060 obj63 = new \u0031C561093.\u00329503060(this.\u00348C31A52);
                                                                                        dictionary63[(uint) num297] = obj63;
                                                                                        if ((1593651845 ^ (int) num13) != 0)
                                                                                        {
                                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary64 = this.\u003342620F1;
                                                                                          int num298 = (int) num13 - 1086332866;
                                                                                          \u0031C561093.\u00329503060 obj64 = new \u0031C561093.\u00329503060(this.\u00334B11578);
                                                                                          uint num299 = num13 ^ 885136571U;
                                                                                          dictionary64[(uint) num298] = obj64;
                                                                                          uint num300 = 413539547U % num299;
                                                                                          if (((int) num300 ^ 1888369172) != 0)
                                                                                          {
                                                                                            uint num301 = 255548106U >> (int) num300;
                                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary65 = this.\u003342620F1;
                                                                                            int num302 = (int) num301 - -64;
                                                                                            uint num303 = 1985500043U ^ num301 >> 13;
                                                                                            // ISSUE: method pointer
                                                                                            \u0031C561093.\u00329503060 obj65 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0035E492702));
                                                                                            dictionary65[(uint) num302] = obj65;
                                                                                            uint num304 = num303 / 1981438393U;
                                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary66 = this.\u003342620F1;
                                                                                            uint num305 = 1489921053U ^ num304;
                                                                                            int num306 = (int) num305 - 1489920986;
                                                                                            uint num307 = 65486637U >> (int) num305;
                                                                                            // ISSUE: method pointer
                                                                                            \u0031C561093.\u00329503060 obj66 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00368DD47A5));
                                                                                            dictionary66[(uint) num306] = obj66;
                                                                                            uint num308 = 284258291U + num307;
                                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary67 = this.\u003342620F1;
                                                                                            int num309 = (int) num308 - 284258224;
                                                                                            uint num310 = (num308 | 1931810606U) + 340554066U;
                                                                                            // ISSUE: method pointer
                                                                                            \u0031C561093.\u00329503060 obj67 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0031F9B2F7F));
                                                                                            dictionary67[(uint) num309] = obj67;
                                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary68 = this.\u003342620F1;
                                                                                            uint num311 = 275123064U ^ num310;
                                                                                            int num312 = (int) num311 ^ -1742210451;
                                                                                            uint num313 = num311 | 1832789568U;
                                                                                            // ISSUE: method pointer
                                                                                            IntPtr num314 = __methodptr(\u00300AF38F6);
                                                                                            uint num315 = num313 & 1779783311U;
                                                                                            \u0031C561093.\u00329503060 obj68 = new \u0031C561093.\u00329503060((object) this, num314);
                                                                                            num7 = 1182273121U * num315;
                                                                                            dictionary68[(uint) num312] = obj68;
                                                                                            if (868712052U <= num7)
                                                                                            {
                                                                                              uint num316 = 751512355U + num7;
                                                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary69 = this.\u003342620F1;
                                                                                              uint num317 = num316 % 1997475613U;
                                                                                              int num318 = (int) num317 - 448672554;
                                                                                              uint num319 = 95814182U - num317 - 1493252086U;
                                                                                              // ISSUE: method pointer
                                                                                              \u0031C561093.\u00329503060 obj69 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00369BD537E));
                                                                                              dictionary69[(uint) num318] = obj69;
                                                                                              uint num320 = 94921789U - num319;
                                                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary70 = this.\u003342620F1;
                                                                                              int num321 = (int) num320 - 1941032246;
                                                                                              uint num322 = 697792380U << (int) num320;
                                                                                              \u0031C561093.\u00329503060 obj70 = new \u0031C561093.\u00329503060(this.\u0036FD1447C);
                                                                                              dictionary70[(uint) num321] = obj70;
                                                                                              uint num323 = 768217726U & num322;
                                                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary71 = this.\u003342620F1;
                                                                                              uint num324 = 2122138370U >> (int) num323;
                                                                                              int num325 = (int) num324 - 2122138299;
                                                                                              uint num326 = 685598887U ^ num324;
                                                                                              // ISSUE: method pointer
                                                                                              \u0031C561093.\u00329503060 obj71 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u003638A7597));
                                                                                              dictionary71[(uint) num325] = obj71;
                                                                                              uint num327 = 1837061979U ^ num326;
                                                                                              if (num327 > 996152566U)
                                                                                              {
                                                                                                uint num328 = num327 << 1;
                                                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary72 = this.\u003342620F1;
                                                                                                int num329 = (int) num328 - 2009004468;
                                                                                                uint num330 = num328 - 621491432U;
                                                                                                // ISSUE: method pointer
                                                                                                \u0031C561093.\u00329503060 obj72 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00316F5471F));
                                                                                                dictionary72[(uint) num329] = obj72;
                                                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary73 = this.\u003342620F1;
                                                                                                uint num331 = 635379199U & num330;
                                                                                                int num332 = (int) num331 - 9635019;
                                                                                                \u0031C561093.\u00329503060 obj73 = new \u0031C561093.\u00329503060(this.\u0033A0A5115);
                                                                                                dictionary73[(uint) num332] = obj73;
                                                                                                if (1425368259U >= num331)
                                                                                                {
                                                                                                  uint num333 = num331 >> 25;
                                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary74 = this.\u003342620F1;
                                                                                                  uint num334 = num333 / 382279296U;
                                                                                                  int num335 = (int) num334 ^ 74;
                                                                                                  uint num336 = num334 & 94858361U;
                                                                                                  // ISSUE: method pointer
                                                                                                  IntPtr num337 = __methodptr(\u0031F0971C2);
                                                                                                  uint num338 = 840442384U - num336;
                                                                                                  \u0031C561093.\u00329503060 obj74 = new \u0031C561093.\u00329503060((object) this, num337);
                                                                                                  dictionary74[(uint) num335] = obj74;
                                                                                                  uint num339 = 1181908839U * num338 / 384118044U;
                                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary75 = this.\u003342620F1;
                                                                                                  uint num340 = 1600131248U * num339;
                                                                                                  int num341 = (int) num340 ^ -1683983205;
                                                                                                  uint num342 = num340 - 1970943447U << 11;
                                                                                                  // ISSUE: method pointer
                                                                                                  \u0031C561093.\u00329503060 obj75 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0032DF91857));
                                                                                                  uint num343 = 81594422U << (int) num342;
                                                                                                  dictionary75[(uint) num341] = obj75;
                                                                                                  uint num344 = 1565404510U + num343;
                                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary76 = this.\u003342620F1;
                                                                                                  uint num345 = 1493321459U << (int) num344;
                                                                                                  int num346 = (int) num345 ^ 1865416780;
                                                                                                  uint num347 = num345 & 694234973U;
                                                                                                  // ISSUE: method pointer
                                                                                                  IntPtr num348 = __methodptr(\u00303DD46B9);
                                                                                                  num7 = 530919722U | num347;
                                                                                                  \u0031C561093.\u00329503060 obj76 = new \u0031C561093.\u00329503060((object) this, num348);
                                                                                                  dictionary76[(uint) num346] = obj76;
                                                                                                  if (434185239U != num7)
                                                                                                  {
                                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary77 = this.\u003342620F1;
                                                                                                    uint num349 = num7 >> 23;
                                                                                                    int num350 = (int) num349 ^ 50;
                                                                                                    // ISSUE: method pointer
                                                                                                    IntPtr num351 = __methodptr(\u0034ADE09E8);
                                                                                                    uint num352 = num349 * 773139175U;
                                                                                                    \u0031C561093.\u00329503060 obj77 = new \u0031C561093.\u00329503060((object) this, num351);
                                                                                                    uint num353 = 2131388641U | num352;
                                                                                                    dictionary77[(uint) num350] = obj77;
                                                                                                    if (2063872089U != num353)
                                                                                                    {
                                                                                                      uint num354 = num353 % 235996099U;
                                                                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary78 = this.\u003342620F1;
                                                                                                      uint num355 = num354 - 455804114U;
                                                                                                      int num356 = (int) num355 + 416473053;
                                                                                                      uint num357 = 1207135312U * num355;
                                                                                                      // ISSUE: method pointer
                                                                                                      IntPtr num358 = __methodptr(\u0035A337EF5);
                                                                                                      uint num359 = 495209508U % num357;
                                                                                                      \u0031C561093.\u00329503060 obj78 = new \u0031C561093.\u00329503060((object) this, num358);
                                                                                                      uint num360 = num359 * 70069478U;
                                                                                                      dictionary78[(uint) num356] = obj78;
                                                                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary79 = this.\u003342620F1;
                                                                                                      int num361 = (int) num360 ^ 877041687;
                                                                                                      // ISSUE: method pointer
                                                                                                      IntPtr num362 = __methodptr(\u0031F287E0C);
                                                                                                      num4 = num360 >> 23;
                                                                                                      \u0031C561093.\u00329503060 obj79 = new \u0031C561093.\u00329503060((object) this, num362);
                                                                                                      dictionary79[(uint) num361] = obj79;
                                                                                                      if ((int) num4 * 2110356360 != 0)
                                                                                                      {
                                                                                                        uint num363 = 497516446U >> (int) num4;
                                                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary80 = this.\u003342620F1;
                                                                                                        uint num364 = 627376929U >> (int) num363;
                                                                                                        int num365 = (int) num364 + 80;
                                                                                                        uint num366 = num364 & 1444698272U;
                                                                                                        // ISSUE: method pointer
                                                                                                        IntPtr num367 = __methodptr(\u003542961F1);
                                                                                                        uint num368 = num366 % 869008392U;
                                                                                                        \u0031C561093.\u00329503060 obj80 = new \u0031C561093.\u00329503060((object) this, num367);
                                                                                                        uint num369 = 1487619116U + num368;
                                                                                                        dictionary80[(uint) num365] = obj80;
                                                                                                        num4 = 1640583253U + num369;
                                                                                                        if (((int) num4 & 954492268) != 0)
                                                                                                        {
                                                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary81 = this.\u003342620F1;
                                                                                                          int num370 = (int) num4 - -1166765008;
                                                                                                          uint num371 = 1525297424U % num4;
                                                                                                          // ISSUE: method pointer
                                                                                                          \u0031C561093.\u00329503060 obj81 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u003417C37F2));
                                                                                                          uint num372 = num371 << 5;
                                                                                                          dictionary81[(uint) num370] = obj81;
                                                                                                          uint num373 = num372 >> 26;
                                                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary82 = this.\u003342620F1;
                                                                                                          int num374 = (int) num373 ^ 69;
                                                                                                          // ISSUE: method pointer
                                                                                                          IntPtr num375 = __methodptr(\u00369EE2472);
                                                                                                          uint num376 = 2053525579U >> (int) num373;
                                                                                                          \u0031C561093.\u00329503060 obj82 = new \u0031C561093.\u00329503060((object) this, num375);
                                                                                                          dictionary82[(uint) num374] = obj82;
                                                                                                          uint num377 = num376 >> 10;
                                                                                                          if (853882337U > num377)
                                                                                                          {
                                                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary83 = this.\u003342620F1;
                                                                                                            uint num378 = 13174628U << (int) num377;
                                                                                                            int num379 = (int) num378 - 13174545;
                                                                                                            \u0031C561093.\u00329503060 obj83 = new \u0031C561093.\u00329503060(this.\u0031F287E0C);
                                                                                                            dictionary83[(uint) num379] = obj83;
                                                                                                            uint num380 = num378 * 890399910U;
                                                                                                            if (1228414813U < num380)
                                                                                                            {
                                                                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary84 = this.\u003342620F1;
                                                                                                              uint num381 = 982408783U % num380;
                                                                                                              int num382 = (int) num381 ^ 982408731;
                                                                                                              uint num383 = num381 + 1815570557U;
                                                                                                              // ISSUE: method pointer
                                                                                                              \u0031C561093.\u00329503060 obj84 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0033D7426D0));
                                                                                                              dictionary84[(uint) num382] = obj84;
                                                                                                              num4 = num383 << 16;
                                                                                                              if (371995141U <= num4)
                                                                                                              {
                                                                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary85 = this.\u003342620F1;
                                                                                                                uint num384 = 1337595249U << (int) num4;
                                                                                                                int num385 = (int) num384 - 1337595164;
                                                                                                                uint num386 = 200374759U / num384;
                                                                                                                // ISSUE: method pointer
                                                                                                                \u0031C561093.\u00329503060 obj85 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00369EE2472));
                                                                                                                uint num387 = num386 + 1680498591U;
                                                                                                                dictionary85[(uint) num385] = obj85;
                                                                                                                uint num388 = num387 + 910968212U;
                                                                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary86 = this.\u003342620F1;
                                                                                                                int num389 = (int) num388 - -1703500579;
                                                                                                                uint num390 = 1641295575U >> (int) (num388 / 339705703U);
                                                                                                                // ISSUE: method pointer
                                                                                                                \u0031C561093.\u00329503060 obj86 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0033CB32B5C));
                                                                                                                uint num391 = 1477138336U + num390;
                                                                                                                dictionary86[(uint) num389] = obj86;
                                                                                                                num4 = num391 + 1345326337U;
                                                                                                                if ((int) num4 * 1244364629 != 0)
                                                                                                                {
                                                                                                                  uint num392 = 1870946123U - num4;
                                                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary87 = this.\u003342620F1;
                                                                                                                  int num393 = (int) num392 - -964341258;
                                                                                                                  uint num394 = 1568767840U * (num392 - 1043424257U);
                                                                                                                  // ISSUE: method pointer
                                                                                                                  \u0031C561093.\u00329503060 obj87 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0035A337EF5));
                                                                                                                  uint num395 = num394 >> 16;
                                                                                                                  dictionary87[(uint) num393] = obj87;
                                                                                                                  num4 = num395 - 1994863193U;
                                                                                                                  if (373191180U < num4)
                                                                                                                  {
                                                                                                                    uint num396 = num4 / 323840392U;
                                                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary88 = this.\u003342620F1;
                                                                                                                    uint num397 = 2124575169U & num396;
                                                                                                                    int num398 = (int) num397 + 87;
                                                                                                                    uint num399 = 260123594U & num397;
                                                                                                                    // ISSUE: method pointer
                                                                                                                    IntPtr num400 = __methodptr(\u003661818BC);
                                                                                                                    uint num401 = 402261867U ^ num399;
                                                                                                                    \u0031C561093.\u00329503060 obj88 = new \u0031C561093.\u00329503060((object) this, num400);
                                                                                                                    dictionary88[(uint) num398] = obj88;
                                                                                                                    uint num402 = 1845840317U ^ num401;
                                                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary89 = this.\u003342620F1;
                                                                                                                    int num403 = (int) num402 ^ 2046774927;
                                                                                                                    uint num404 = 1287147638U + num402;
                                                                                                                    // ISSUE: method pointer
                                                                                                                    IntPtr num405 = __methodptr(\u00305881923);
                                                                                                                    uint num406 = 1687903177U / num404;
                                                                                                                    \u0031C561093.\u00329503060 obj89 = new \u0031C561093.\u00329503060((object) this, num405);
                                                                                                                    dictionary89[(uint) num403] = obj89;
                                                                                                                    uint num407 = 221985069U * num406;
                                                                                                                    if (num407 <= 606435336U)
                                                                                                                    {
                                                                                                                      this.\u003342620F1[num407 + 90U] = new \u0031C561093.\u00329503060(this.\u00351CA2101);
                                                                                                                      num9 = 650077982U + num407;
                                                                                                                      if (num9 != 1047678171U)
                                                                                                                      {
                                                                                                                        uint num408 = num9 / 2116902821U;
                                                                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary90 = this.\u003342620F1;
                                                                                                                        int num409 = (int) num408 - -91;
                                                                                                                        // ISSUE: method pointer
                                                                                                                        IntPtr num410 = __methodptr(\u00348C31A52);
                                                                                                                        uint num411 = 705519101U + num408;
                                                                                                                        \u0031C561093.\u00329503060 obj90 = new \u0031C561093.\u00329503060((object) this, num410);
                                                                                                                        dictionary90[(uint) num409] = obj90;
                                                                                                                        uint num412 = 955193140U % (2146321938U / num411);
                                                                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary91 = this.\u003342620F1;
                                                                                                                        uint num413 = 14094467U & num412;
                                                                                                                        int num414 = (int) num413 ^ 93;
                                                                                                                        uint num415 = 133068281U * (num413 | 1341791110U);
                                                                                                                        // ISSUE: method pointer
                                                                                                                        \u0031C561093.\u00329503060 obj91 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u003417C37F2));
                                                                                                                        uint num416 = 1394285448U - num415;
                                                                                                                        dictionary91[(uint) num414] = obj91;
                                                                                                                        uint num417 = 1467550182U >> (int) (num416 | 1977877423U);
                                                                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary92 = this.\u003342620F1;
                                                                                                                        int num418 = (int) num417 ^ 93;
                                                                                                                        uint num419 = 1536912165U & num417 & 1449351008U;
                                                                                                                        // ISSUE: method pointer
                                                                                                                        IntPtr num420 = __methodptr(\u0031F287E0C);
                                                                                                                        uint num421 = num419 * 1632003213U;
                                                                                                                        \u0031C561093.\u00329503060 obj92 = new \u0031C561093.\u00329503060((object) this, num420);
                                                                                                                        uint num422 = 2108652783U - num421;
                                                                                                                        dictionary92[(uint) num418] = obj92;
                                                                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary93 = this.\u003342620F1;
                                                                                                                        uint num423 = num422 >> 19;
                                                                                                                        int num424 = (int) num423 - 3927;
                                                                                                                        uint num425 = num423 / 1478106626U;
                                                                                                                        // ISSUE: method pointer
                                                                                                                        \u0031C561093.\u00329503060 obj93 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u003417C37F2));
                                                                                                                        num9 = num425 + 1961574322U;
                                                                                                                        dictionary93[(uint) num424] = obj93;
                                                                                                                        if (num9 != 1052719206U)
                                                                                                                        {
                                                                                                                          uint num426 = num9 * 1850344904U;
                                                                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary94 = this.\u003342620F1;
                                                                                                                          uint num427 = 60111775U & num426;
                                                                                                                          int num428 = (int) num427 - 18102449;
                                                                                                                          uint num429 = 430852630U | num427 / 1576080523U;
                                                                                                                          // ISSUE: method pointer
                                                                                                                          IntPtr num430 = __methodptr(\u00345220DC2);
                                                                                                                          num7 = num429 * 46274273U;
                                                                                                                          \u0031C561093.\u00329503060 obj94 = new \u0031C561093.\u00329503060((object) this, num430);
                                                                                                                          dictionary94[(uint) num428] = obj94;
                                                                                                                          if (1241151763U != num7)
                                                                                                                          {
                                                                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary95 = this.\u003342620F1;
                                                                                                                            uint num431 = num7 | 1033717926U;
                                                                                                                            int num432 = (int) num431 ^ -37926506;
                                                                                                                            uint num433 = (1219176377U >> (int) num431) * 29300077U;
                                                                                                                            // ISSUE: method pointer
                                                                                                                            IntPtr num434 = __methodptr(\u0033CB32B5C);
                                                                                                                            uint num435 = num433 - 1148257147U;
                                                                                                                            \u0031C561093.\u00329503060 obj95 = new \u0031C561093.\u00329503060((object) this, num434);
                                                                                                                            uint num436 = 1626101218U * num435;
                                                                                                                            dictionary95[(uint) num432] = obj95;
                                                                                                                            uint num437 = num436 / 574906454U;
                                                                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary96 = this.\u003342620F1;
                                                                                                                            int num438 = (int) num437 ^ 103;
                                                                                                                            uint num439 = 1674254138U * (num437 & 486899294U);
                                                                                                                            // ISSUE: method pointer
                                                                                                                            \u0031C561093.\u00329503060 obj96 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0031F287E0C));
                                                                                                                            dictionary96[(uint) num438] = obj96;
                                                                                                                            uint num440 = num439 * 558784843U;
                                                                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary97 = this.\u003342620F1;
                                                                                                                            uint num441 = num440 ^ 411635918U;
                                                                                                                            int num442 = (int) num441 ^ 1801305944;
                                                                                                                            uint num443 = num441 >> 1;
                                                                                                                            // ISSUE: method pointer
                                                                                                                            IntPtr num444 = __methodptr(\u00345220DC2);
                                                                                                                            num4 = 179832882U ^ num443;
                                                                                                                            \u0031C561093.\u00329503060 obj97 = new \u0031C561093.\u00329503060((object) this, num444);
                                                                                                                            dictionary97[(uint) num442] = obj97;
                                                                                                                            if (num4 > 186217880U)
                                                                                                                            {
                                                                                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary98 = this.\u003342620F1;
                                                                                                                              int num445 = (int) num4 - 1058461516;
                                                                                                                              // ISSUE: method pointer
                                                                                                                              IntPtr num446 = __methodptr(\u0034D6B2980);
                                                                                                                              uint num447 = 1833703783U / num4;
                                                                                                                              \u0031C561093.\u00329503060 obj98 = new \u0031C561093.\u00329503060((object) this, num446);
                                                                                                                              uint num448 = 1138950919U >> (int) num447;
                                                                                                                              dictionary98[(uint) num445] = obj98;
                                                                                                                              uint num449 = num448 | 1326413093U;
                                                                                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary99 = this.\u003342620F1;
                                                                                                                              uint num450 = num449 << 23;
                                                                                                                              int num451 = (int) num450 - -746586212;
                                                                                                                              uint num452 = 709124733U << (int) (num450 + 1508055198U);
                                                                                                                              // ISSUE: method pointer
                                                                                                                              IntPtr num453 = __methodptr(\u003417C37F2);
                                                                                                                              uint num454 = 1736522185U % num452;
                                                                                                                              \u0031C561093.\u00329503060 obj99 = new \u0031C561093.\u00329503060((object) this, num453);
                                                                                                                              dictionary99[(uint) num451] = obj99;
                                                                                                                              num7 = 71054227U + num454;
                                                                                                                              if (1743747412 << (int) num7 != 0)
                                                                                                                              {
                                                                                                                                uint num455 = 1036998980U | num7;
                                                                                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary100 = this.\u003342620F1;
                                                                                                                                int num456 = (int) num455 ^ 1073708345;
                                                                                                                                uint num457 = 1792551631U * num455;
                                                                                                                                // ISSUE: method pointer
                                                                                                                                \u0031C561093.\u00329503060 obj100 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00301B65D58));
                                                                                                                                uint num458 = 660233990U << (int) num457;
                                                                                                                                dictionary100[(uint) num456] = obj100;
                                                                                                                                if ((int) num458 * 1255689509 != 0)
                                                                                                                                {
                                                                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary101 = this.\u003342620F1;
                                                                                                                                  int num459 = (int) num458 - 1973809146;
                                                                                                                                  uint num460 = num458 >> 11;
                                                                                                                                  \u0031C561093.\u00329503060 obj101 = new \u0031C561093.\u00329503060(this.\u0031F9B2F7F);
                                                                                                                                  dictionary101[(uint) num459] = obj101;
                                                                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary102 = this.\u003342620F1;
                                                                                                                                  uint num461 = 405168689U - num460;
                                                                                                                                  int num462 = (int) num461 ^ 404204820;
                                                                                                                                  \u0031C561093.\u00329503060 obj102 = new \u0031C561093.\u00329503060(this.\u0035A337EF5);
                                                                                                                                  dictionary102[(uint) num462] = obj102;
                                                                                                                                  uint num463 = num461 ^ 53831105U;
                                                                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary103 = this.\u003342620F1;
                                                                                                                                  uint num464 = 725630546U << (int) num463;
                                                                                                                                  int num465 = (int) num464 ^ -112721816;
                                                                                                                                  // ISSUE: method pointer
                                                                                                                                  IntPtr num466 = __methodptr(\u003772121CE);
                                                                                                                                  uint num467 = 732314529U >> (int) num464;
                                                                                                                                  \u0031C561093.\u00329503060 obj103 = new \u0031C561093.\u00329503060((object) this, num466);
                                                                                                                                  num4 = 1512574850U << (int) num467;
                                                                                                                                  dictionary103[(uint) num465] = obj103;
                                                                                                                                  if (num4 > 647564300U)
                                                                                                                                  {
                                                                                                                                    uint num468 = num4 / 1056726884U;
                                                                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary104 = this.\u003342620F1;
                                                                                                                                    int num469 = (int) num468 ^ 107;
                                                                                                                                    uint num470 = num468 % 173824778U;
                                                                                                                                    \u0031C561093.\u00329503060 obj104 = new \u0031C561093.\u00329503060(this.\u00345977C35);
                                                                                                                                    uint num471 = 1421953932U / num470;
                                                                                                                                    dictionary104[(uint) num469] = obj104;
                                                                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary105 = this.\u003342620F1;
                                                                                                                                    int num472 = (int) num471 ^ 710976940;
                                                                                                                                    \u0031C561093.\u00329503060 obj105 = new \u0031C561093.\u00329503060(this.\u0031F0971C2);
                                                                                                                                    num9 = 2023191005U << (int) num471;
                                                                                                                                    dictionary105[(uint) num472] = obj105;
                                                                                                                                    if (num9 < 689721288U)
                                                                                                                                    {
                                                                                                                                      uint num473 = 1495216831U - num9;
                                                                                                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary106 = this.\u003342620F1;
                                                                                                                                      uint num474 = num473 & 1198275417U;
                                                                                                                                      int num475 = (int) num474 ^ 54541106;
                                                                                                                                      uint num476 = 2034900292U << (int) num474;
                                                                                                                                      // ISSUE: method pointer
                                                                                                                                      IntPtr num477 = __methodptr(\u003542961F1);
                                                                                                                                      uint num478 = num476 + 1016882837U;
                                                                                                                                      \u0031C561093.\u00329503060 obj106 = new \u0031C561093.\u00329503060((object) this, num477);
                                                                                                                                      uint num479 = num478 << 21;
                                                                                                                                      dictionary106[(uint) num475] = obj106;
                                                                                                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary107 = this.\u003342620F1;
                                                                                                                                      uint num480 = 959935102U - num479;
                                                                                                                                      int num481 = (int) num480 - 1721201170;
                                                                                                                                      \u0031C561093.\u00329503060 obj107 = new \u0031C561093.\u00329503060(this.\u00372474421);
                                                                                                                                      uint num482 = num480 - 343935129U;
                                                                                                                                      dictionary107[(uint) num481] = obj107;
                                                                                                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary108 = this.\u003342620F1;
                                                                                                                                      int num483 = (int) num482 ^ 1377266056;
                                                                                                                                      uint num484 = num482 - 409038747U;
                                                                                                                                      \u0031C561093.\u00329503060 obj108 = new \u0031C561093.\u00329503060(this.\u0032F1B1F02);
                                                                                                                                      uint num485 = 494801723U - num484;
                                                                                                                                      dictionary108[(uint) num483] = obj108;
                                                                                                                                      uint num486 = num485 % 1541935211U;
                                                                                                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary109 = this.\u003342620F1;
                                                                                                                                      int num487 = (int) num486 ^ 737671285;
                                                                                                                                      uint num488 = 1168516386U >> (int) num486;
                                                                                                                                      // ISSUE: method pointer
                                                                                                                                      \u0031C561093.\u00329503060 obj109 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00378242571));
                                                                                                                                      uint num489 = 1325403630U % num488;
                                                                                                                                      dictionary109[(uint) num487] = obj109;
                                                                                                                                      num14 = 1478060876U | num489;
                                                                                                                                    }
                                                                                                                                    else
                                                                                                                                      goto label_3;
                                                                                                                                  }
                                                                                                                                  else
                                                                                                                                    goto label_1;
                                                                                                                                }
                                                                                                                                else
                                                                                                                                  goto label_0;
                                                                                                                              }
                                                                                                                              else
                                                                                                                                goto label_2;
                                                                                                                            }
                                                                                                                            else
                                                                                                                              goto label_6;
                                                                                                                          }
                                                                                                                          else
                                                                                                                            goto label_2;
                                                                                                                        }
                                                                                                                        else
                                                                                                                          goto label_3;
                                                                                                                      }
                                                                                                                      else
                                                                                                                        goto label_4;
                                                                                                                    }
                                                                                                                    else
                                                                                                                      goto label_0;
                                                                                                                  }
                                                                                                                  else
                                                                                                                    goto label_1;
                                                                                                                }
                                                                                                                else
                                                                                                                  goto label_5;
                                                                                                              }
                                                                                                              else
                                                                                                                goto label_1;
                                                                                                            }
                                                                                                            else
                                                                                                              goto label_0;
                                                                                                          }
                                                                                                          else
                                                                                                            goto label_0;
                                                                                                        }
                                                                                                        else
                                                                                                          goto label_1;
                                                                                                      }
                                                                                                      else
                                                                                                        goto label_1;
                                                                                                    }
                                                                                                    else
                                                                                                      goto label_0;
                                                                                                  }
                                                                                                  else
                                                                                                    goto label_2;
                                                                                                }
                                                                                                else
                                                                                                  goto label_0;
                                                                                              }
                                                                                              else
                                                                                                goto label_0;
                                                                                            }
                                                                                            else
                                                                                              goto label_2;
                                                                                          }
                                                                                          else
                                                                                            goto label_0;
                                                                                        }
                                                                                        else
                                                                                          goto label_7;
                                                                                      }
                                                                                      else
                                                                                        goto label_0;
                                                                                    }
                                                                                    else
                                                                                      goto label_0;
                                                                                  }
                                                                                  else
                                                                                    goto label_0;
                                                                                }
                                                                                else
                                                                                  goto label_0;
                                                                              }
                                                                              else
                                                                                goto label_0;
                                                                            }
                                                                            else
                                                                              goto label_2;
                                                                          }
                                                                          else
                                                                            goto label_0;
                                                                        }
                                                                        else
                                                                          goto label_2;
                                                                      }
                                                                      else
                                                                        goto label_1;
                                                                    }
                                                                    else
                                                                      goto label_1;
                                                                  }
                                                                  else
                                                                    goto label_2;
                                                                }
                                                                else
                                                                  goto label_0;
                                                              }
                                                              else
                                                                goto label_4;
                                                            }
                                                            else
                                                              goto label_1;
                                                          }
                                                          else
                                                            goto label_4;
                                                        }
                                                        else
                                                          goto label_2;
                                                      }
                                                      else
                                                        goto label_0;
                                                    }
                                                    else
                                                      goto label_0;
                                                  }
                                                  else
                                                    goto label_0;
                                                }
                                                else
                                                  goto label_0;
                                              }
                                              else
                                                goto label_1;
                                            }
                                            else
                                              goto label_1;
                                          }
                                          else
                                            goto label_1;
                                        }
                                        else
                                          goto label_2;
                                      }
                                      else
                                        goto label_1;
                                    }
                                    else
                                      goto label_1;
                                  }
                                  else
                                    goto label_0;
                                }
                                else
                                  goto label_3;
                              }
                              else
                                goto label_1;
                            }
                            else
                              goto label_1;
                          }
                          else
                            goto label_2;
                        }
                        while (num14 == 33691739U);
                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary110 = this.\u003342620F1;
                        uint num490 = num14 - 1051939780U;
                        int num491 = (int) num490 - 426120987;
                        uint num492 = 648884763U / (num490 ^ 1574730627U);
                        // ISSUE: method pointer
                        \u0031C561093.\u00329503060 obj110 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0033D7426D0));
                        uint num493 = 579101129U * num492;
                        dictionary110[(uint) num491] = obj110;
                        uint num494 = num493 << 10;
                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary111 = this.\u003342620F1;
                        int num495 = (int) num494 - -112;
                        uint num496 = 939738124U << (int) (num494 & 1367244334U);
                        // ISSUE: method pointer
                        IntPtr num497 = __methodptr(\u0031F287E0C);
                        uint num498 = num496 % 300159835U;
                        \u0031C561093.\u00329503060 obj111 = new \u0031C561093.\u00329503060((object) this, num497);
                        dictionary111[(uint) num495] = obj111;
                        uint num499 = num498 >> 17;
                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary112 = this.\u003342620F1;
                        uint num500 = 1247116949U - num499;
                        int num501 = (int) num500 - 1247116537;
                        uint num502 = 642268830U / num500 / 2020215042U;
                        // ISSUE: method pointer
                        IntPtr num503 = __methodptr(\u0033A0A5115);
                        uint num504 = num502 ^ 1523278344U;
                        \u0031C561093.\u00329503060 obj112 = new \u0031C561093.\u00329503060((object) this, num503);
                        uint num505 = 683940397U - num504;
                        dictionary112[(uint) num501] = obj112;
                        uint num506 = 1646948806U + (num505 ^ 1835991712U);
                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary113 = this.\u003342620F1;
                        uint num507 = 2098796471U << (int) num506;
                        int num508 = (int) num507 ^ -927090574;
                        // ISSUE: method pointer
                        IntPtr num509 = __methodptr(\u0033B5C3155);
                        uint num510 = num507 & 1017596743U;
                        \u0031C561093.\u00329503060 obj113 = new \u0031C561093.\u00329503060((object) this, num509);
                        uint num511 = num510 - 1970085706U;
                        dictionary113[(uint) num508] = obj113;
                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary114 = this.\u003342620F1;
                        num4 = 1344286603U % num511;
                        int num512 = (int) num4 - 1344286488;
                        \u0031C561093.\u00329503060 obj114 = new \u0031C561093.\u00329503060(this.\u0033CB32B5C);
                        dictionary114[(uint) num512] = obj114;
                        if (1811440036U % num4 != 0U)
                        {
                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary1 = this.\u003342620F1;
                          int num15 = (int) num4 - 1344286487;
                          uint num16 = 1597915378U / num4;
                          // ISSUE: method pointer
                          IntPtr num17 = __methodptr(\u00369BD537E);
                          uint num18 = 1683316842U * num16;
                          \u0031C561093.\u00329503060 obj1 = new \u0031C561093.\u00329503060((object) this, num17);
                          uint num19 = num18 - 1788816188U;
                          dictionary1[(uint) num15] = obj1;
                          uint num20 = 801052071U - num19;
                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary2 = this.\u003342620F1;
                          uint num21 = num20 & 1175135365U;
                          int num22 = (int) num21 ^ 101195892;
                          uint num23 = 994930496U * num21;
                          // ISSUE: method pointer
                          IntPtr num24 = __methodptr(\u00345220DC2);
                          uint num25 = num23 << 22;
                          \u0031C561093.\u00329503060 obj2 = new \u0031C561093.\u00329503060((object) this, num24);
                          uint num26 = num25 * 1836014748U;
                          dictionary2[(uint) num22] = obj2;
                          if (num26 >= 554654465U)
                          {
                            uint num27 = num26 % 897804938U;
                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary3 = this.\u003342620F1;
                            int num28 = (int) num27 - 527810540;
                            uint num29 = 280834942U & 1741698746U << (int) num27;
                            // ISSUE: method pointer
                            IntPtr num30 = __methodptr(\u0033EFF2212);
                            uint num31 = 2021602518U & num29;
                            \u0031C561093.\u00329503060 obj3 = new \u0031C561093.\u00329503060((object) this, num30);
                            uint num32 = num31 << 24;
                            dictionary3[(uint) num28] = obj3;
                            if (num32 < 1114733685U)
                            {
                              uint num33 = 1910785183U / num32;
                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary4 = this.\u003342620F1;
                              uint num34 = 1540228500U * num33;
                              int num35 = (int) num34 - 1540228381;
                              uint num36 = num34 / 524814949U;
                              // ISSUE: method pointer
                              IntPtr num37 = __methodptr(\u0033D7426D0);
                              uint num38 = num36 + 1589591760U;
                              \u0031C561093.\u00329503060 obj4 = new \u0031C561093.\u00329503060((object) this, num37);
                              uint num39 = 399075672U - num38;
                              dictionary4[(uint) num35] = obj4;
                              uint num40 = num39 / 256521167U;
                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary5 = this.\u003342620F1;
                              uint num41 = 6571733U >> (int) num40;
                              int num42 = (int) num41 ^ 1596;
                              uint num43 = 958693269U << (int) num41;
                              // ISSUE: method pointer
                              IntPtr num44 = __methodptr(\u0031F9B2F7F);
                              uint num45 = 420898635U * num43;
                              \u0031C561093.\u00329503060 obj5 = new \u0031C561093.\u00329503060((object) this, num44);
                              dictionary5[(uint) num42] = obj5;
                              uint num46 = 896891977U | num45;
                              if (1590052482U >= num46)
                              {
                                uint num47 = 458557262U | num46;
                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary6 = this.\u003342620F1;
                                uint num48 = num47 - 1947820026U;
                                int num49 = (int) num48 ^ -883154948;
                                uint num50 = num48 & 239601802U;
                                // ISSUE: method pointer
                                \u0031C561093.\u00329503060 obj6 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u003480E7F57));
                                dictionary6[(uint) num49] = obj6;
                                if (2014588841U >= num50)
                                {
                                  uint num51 = 1921463709U + num50;
                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary7 = this.\u003342620F1;
                                  uint num52 = num51 % 572536346U;
                                  int num53 = (int) num52 ^ 376347573;
                                  // ISSUE: method pointer
                                  IntPtr num54 = __methodptr(\u0032F1B1F02);
                                  uint num55 = 1649552645U << (int) num52;
                                  \u0031C561093.\u00329503060 obj7 = new \u0031C561093.\u00329503060((object) this, num54);
                                  dictionary7[(uint) num53] = obj7;
                                  uint num56 = 1401375695U % (80747646U << (int) num55);
                                  this.\u003342620F1[num56 + 4266301706U] = new \u0031C561093.\u00329503060(this.\u0030D231658);
                                  uint num57 = 466058388U >> (int) num56;
                                  if (1806244439 << (int) num57 != 0)
                                  {
                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary8 = this.\u003342620F1;
                                    int num58 = (int) num57 ^ 3487;
                                    uint num59 = 1832727175U & num57;
                                    // ISSUE: method pointer
                                    IntPtr num60 = __methodptr(\u0034722764A);
                                    uint num61 = num59 ^ 172364966U;
                                    \u0031C561093.\u00329503060 obj8 = new \u0031C561093.\u00329503060((object) this, num60);
                                    uint num62 = num61 * 765481283U;
                                    dictionary8[(uint) num58] = obj8;
                                    uint num63 = 1726551147U * num62;
                                    if (((int) num63 & 1014969212) != 0)
                                    {
                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary9 = this.\u003342620F1;
                                      int num64 = (int) num63 ^ 79131480;
                                      uint num65 = num63 / 701509456U;
                                      \u0031C561093.\u00329503060 obj9 = new \u0031C561093.\u00329503060(this.\u0031F9B2F7F);
                                      uint num66 = 628181454U ^ num65;
                                      dictionary9[(uint) num64] = obj9;
                                      uint num67 = num66 << 23;
                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary10 = this.\u003342620F1;
                                      int num68 = (int) num67 - -419430526;
                                      uint num69 = num67 + 414399452U;
                                      // ISSUE: method pointer
                                      IntPtr num70 = __methodptr(\u00345220DC2);
                                      uint num71 = num69 % 1544315217U;
                                      \u0031C561093.\u00329503060 obj10 = new \u0031C561093.\u00329503060((object) this, num70);
                                      uint num72 = num71 / 1559833520U;
                                      dictionary10[(uint) num68] = obj10;
                                      uint num73 = (num72 ^ 1954159224U) >> 27;
                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary11 = this.\u003342620F1;
                                      int num74 = (int) num73 ^ 113;
                                      uint num75 = num73 & 874385022U;
                                      // ISSUE: method pointer
                                      IntPtr num76 = __methodptr(\u0030D231658);
                                      uint num77 = 121983293U >> (int) num75;
                                      \u0031C561093.\u00329503060 obj11 = new \u0031C561093.\u00329503060((object) this, num76);
                                      dictionary11[(uint) num74] = obj11;
                                      if (633231834U != num77)
                                      {
                                        uint num78 = num77 ^ 1733116291U;
                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary12 = this.\u003342620F1;
                                        int num79 = (int) num78 - 1733123094;
                                        uint num80 = 1328767934U & num78;
                                        \u0031C561093.\u00329503060 obj12 = new \u0031C561093.\u00329503060(this.\u0031F287E0C);
                                        uint num81 = num80 >> 25;
                                        dictionary12[(uint) num79] = obj12;
                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary13 = this.\u003342620F1;
                                        int num82 = (int) num81 - -94;
                                        uint num83 = 257649970U / (num81 | 1350639557U);
                                        // ISSUE: method pointer
                                        \u0031C561093.\u00329503060 obj13 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00369BD537E));
                                        uint num84 = num83 - 495936678U;
                                        dictionary13[(uint) num82] = obj13;
                                        uint num85 = num84 * 1308450745U;
                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary14 = this.\u003342620F1;
                                        int num86 = (int) num85 - 116959624;
                                        uint num87 = num85 | 1566455219U;
                                        // ISSUE: method pointer
                                        IntPtr num88 = __methodptr(\u0032DF91857);
                                        num4 = 83626538U / num87;
                                        \u0031C561093.\u00329503060 obj14 = new \u0031C561093.\u00329503060((object) this, num88);
                                        dictionary14[(uint) num86] = obj14;
                                        if ((651590736 ^ (int) num4) != 0)
                                        {
                                          uint num89 = 543564759U - num4;
                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary15 = this.\u003342620F1;
                                          uint num90 = num89 << 23;
                                          int num91 = (int) num90 ^ -343932797;
                                          uint num92 = 2105492950U | num90;
                                          // ISSUE: method pointer
                                          IntPtr num93 = __methodptr(\u00334B11578);
                                          uint num94 = num92 / 1597269856U;
                                          \u0031C561093.\u00329503060 obj15 = new \u0031C561093.\u00329503060((object) this, num93);
                                          dictionary15[(uint) num91] = obj15;
                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary16 = this.\u003342620F1;
                                          uint num95 = num94 % 1353940493U;
                                          int num96 = (int) num95 - -130;
                                          uint num97 = (184366959U ^ num95) * 460534752U;
                                          // ISSUE: method pointer
                                          \u0031C561093.\u00329503060 obj16 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00334B11578));
                                          uint num98 = num97 | 700146442U;
                                          dictionary16[(uint) num96] = obj16;
                                          uint num99 = (num98 >> 29) + 1400198087U;
                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary17 = this.\u003342620F1;
                                          int num100 = (int) num99 - 1400197957;
                                          uint num101 = 206913733U / (num99 * 210635554U);
                                          // ISSUE: method pointer
                                          IntPtr num102 = __methodptr(\u00337533FAF);
                                          uint num103 = num101 + 1634620394U;
                                          \u0031C561093.\u00329503060 obj17 = new \u0031C561093.\u00329503060((object) this, num102);
                                          uint num104 = 310144288U ^ num103;
                                          dictionary17[(uint) num100] = obj17;
                                          uint num105 = num104 / 291906589U;
                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary18 = this.\u003342620F1;
                                          int num106 = (int) num105 ^ 128;
                                          uint num107 = (num105 + 238881817U) % 399918136U;
                                          // ISSUE: method pointer
                                          \u0031C561093.\u00329503060 obj18 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00301B65D58));
                                          num4 = 857818335U >> (int) num107;
                                          dictionary18[(uint) num106] = obj18;
                                          if (1374238631 << (int) num4 != 0)
                                          {
                                            uint num108 = 205859347U * num4;
                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary19 = this.\u003342620F1;
                                            int num109 = (int) num108 + 135;
                                            uint num110 = (2139579167U | num108) + 1754801996U;
                                            // ISSUE: method pointer
                                            IntPtr num111 = __methodptr(\u0034722764A);
                                            uint num112 = num110 >> 30;
                                            \u0031C561093.\u00329503060 obj19 = new \u0031C561093.\u00329503060((object) this, num111);
                                            uint num113 = 1144926745U % num112;
                                            dictionary19[(uint) num109] = obj19;
                                            if (1121922339U > num113)
                                            {
                                              uint num114 = num113 / 1577650507U;
                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary20 = this.\u003342620F1;
                                              uint num115 = num114 ^ 1129977929U;
                                              int num116 = (int) num115 - 1129977793;
                                              uint num117 = 573525559U - (num115 - 118048303U);
                                              // ISSUE: method pointer
                                              IntPtr num118 = __methodptr(\u003480E7F57);
                                              uint num119 = num117 % 1330067308U;
                                              \u0031C561093.\u00329503060 obj20 = new \u0031C561093.\u00329503060((object) this, num118);
                                              uint num120 = num119 % 749759793U;
                                              dictionary20[(uint) num116] = obj20;
                                              num7 = num120 << 26;
                                              if (1872430956U > num7)
                                              {
                                                uint num121 = num7 & 91041554U;
                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary21 = this.\u003342620F1;
                                                uint num122 = 1495890160U & num121;
                                                int num123 = (int) num122 - -137;
                                                uint num124 = 2029736998U ^ 1727087278U + num122;
                                                // ISSUE: method pointer
                                                IntPtr num125 = __methodptr(\u003542961F1);
                                                uint num126 = num124 & 1860519173U;
                                                \u0031C561093.\u00329503060 obj21 = new \u0031C561093.\u00329503060((object) this, num125);
                                                uint num127 = 1613567309U - num126;
                                                dictionary21[(uint) num123] = obj21;
                                                uint num128 = num127 * 1320687058U;
                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary22 = this.\u003342620F1;
                                                uint num129 = 1945793720U / num128;
                                                int num130 = (int) num129 - 20;
                                                uint num131 = 1417180393U >> (int) (728261307U ^ num129);
                                                // ISSUE: method pointer
                                                IntPtr num132 = __methodptr(\u0033A0A5115);
                                                uint num133 = num131 << 22;
                                                \u0031C561093.\u00329503060 obj22 = new \u0031C561093.\u00329503060((object) this, num132);
                                                dictionary22[(uint) num130] = obj22;
                                                uint num134 = num133 >> 18;
                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary23 = this.\u003342620F1;
                                                uint num135 = 184838250U - num134;
                                                int num136 = (int) num135 - 184823151;
                                                // ISSUE: method pointer
                                                IntPtr num137 = __methodptr(\u0033A0A5115);
                                                uint num138 = num135 >> 11;
                                                \u0031C561093.\u00329503060 obj23 = new \u0031C561093.\u00329503060((object) this, num137);
                                                dictionary23[(uint) num136] = obj23;
                                                num4 = 1022893184U % num138;
                                                if (num4 >> 21 == 0U)
                                                {
                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary24 = this.\u003342620F1;
                                                  int num139 = (int) num4 - 56214;
                                                  uint num140 = 1777277641U + num4;
                                                  \u0031C561093.\u00329503060 obj24 = new \u0031C561093.\u00329503060(this.\u00306AB7707);
                                                  uint num141 = num140 & 1838820837U;
                                                  dictionary24[(uint) num139] = obj24;
                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary25 = this.\u003342620F1;
                                                  uint num142 = 2058489260U / num141;
                                                  int num143 = (int) num142 - -140;
                                                  uint num144 = 1726372753U * (1156014085U % num142);
                                                  // ISSUE: method pointer
                                                  \u0031C561093.\u00329503060 obj25 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00306AB7707));
                                                  dictionary25[(uint) num143] = obj25;
                                                  uint num145 = 255278795U & (1304170150U & num144);
                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary26 = this.\u003342620F1;
                                                  int num146 = (int) num145 ^ 142;
                                                  // ISSUE: method pointer
                                                  IntPtr num147 = __methodptr(\u00334DD32D5);
                                                  uint num148 = 1244345785U - num145;
                                                  \u0031C561093.\u00329503060 obj26 = new \u0031C561093.\u00329503060((object) this, num147);
                                                  dictionary26[(uint) num146] = obj26;
                                                  num4 = num148 / 169832778U;
                                                  if (59712209U != num4)
                                                  {
                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary27 = this.\u003342620F1;
                                                    uint num149 = num4 << 2;
                                                    int num150 = (int) num149 + 115;
                                                    \u0031C561093.\u00329503060 obj27 = new \u0031C561093.\u00329503060(this.\u0033A0A5115);
                                                    uint num151 = num149 + 579341012U;
                                                    dictionary27[(uint) num150] = obj27;
                                                    if (1601967982U >= num151)
                                                    {
                                                      uint num152 = 743329361U - num151;
                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary28 = this.\u003342620F1;
                                                      uint num153 = 1267952917U * num152;
                                                      int num154 = (int) num153 ^ 1403442021;
                                                      // ISSUE: method pointer
                                                      IntPtr num155 = __methodptr(\u00316F5471F);
                                                      uint num156 = num153 / 1613835875U;
                                                      \u0031C561093.\u00329503060 obj28 = new \u0031C561093.\u00329503060((object) this, num155);
                                                      dictionary28[(uint) num154] = obj28;
                                                      uint num157 = num156 / 1661027187U;
                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary29 = this.\u003342620F1;
                                                      int num158 = (int) num157 - -145;
                                                      uint num159 = num157 << 27;
                                                      // ISSUE: method pointer
                                                      IntPtr num160 = __methodptr(\u003253C5A20);
                                                      uint num161 = 825960153U >> (int) num159;
                                                      \u0031C561093.\u00329503060 obj29 = new \u0031C561093.\u00329503060((object) this, num160);
                                                      uint num162 = 818375015U | num161;
                                                      dictionary29[(uint) num158] = obj29;
                                                      num4 = num162 ^ 1644716647U;
                                                      if (((int) num4 ^ 1755528418) != 0)
                                                      {
                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary30 = this.\u003342620F1;
                                                        int num163 = (int) num4 - 1408699654;
                                                        // ISSUE: method pointer
                                                        IntPtr num164 = __methodptr(\u0032F1B1F02);
                                                        uint num165 = num4 << 2;
                                                        \u0031C561093.\u00329503060 obj30 = new \u0031C561093.\u00329503060((object) this, num164);
                                                        uint num166 = num165 / 312884332U;
                                                        dictionary30[(uint) num163] = obj30;
                                                        uint num167 = 1160327234U * num166;
                                                        if ((int) num167 << 6 != 0)
                                                        {
                                                          uint num168 = num167 % 936140377U;
                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary31 = this.\u003342620F1;
                                                          uint num169 = 25903988U | num168;
                                                          int num170 = (int) num169 ^ 363840495;
                                                          uint num171 = num169 & 1655452324U;
                                                          // ISSUE: method pointer
                                                          \u0031C561093.\u00329503060 obj31 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00345977C35));
                                                          dictionary31[(uint) num170] = obj31;
                                                          num4 = num171 ^ 1854610504U;
                                                          if (252313902U % num4 != 0U)
                                                          {
                                                            uint num172 = 1114114825U + num4;
                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary32 = this.\u003342620F1;
                                                            uint num173 = num172 * 1549404067U;
                                                            int num174 = (int) num173 ^ -194275093;
                                                            uint num175 = num173 ^ 559053292U;
                                                            \u0031C561093.\u00329503060 obj32 = new \u0031C561093.\u00329503060(this.\u0033D7426D0);
                                                            uint num176 = num175 << 18;
                                                            dictionary32[(uint) num174] = obj32;
                                                            if ((int) num176 + 2137018657 != 0)
                                                            {
                                                              uint num177 = 1819219589U % num176;
                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary33 = this.\u003342620F1;
                                                              uint num178 = num177 << 4;
                                                              int num179 = (int) num178 - -957257797;
                                                              // ISSUE: method pointer
                                                              IntPtr num180 = __methodptr(\u0033A0A5115);
                                                              uint num181 = num178 << 21;
                                                              \u0031C561093.\u00329503060 obj33 = new \u0031C561093.\u00329503060((object) this, num180);
                                                              dictionary33[(uint) num179] = obj33;
                                                              if (num181 != 1383737694U)
                                                              {
                                                                uint num182 = 43791051U >> (int) num181;
                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary34 = this.\u003342620F1;
                                                                int num183 = (int) num182 ^ 43790941;
                                                                uint num184 = (num182 << 25) - 557580404U;
                                                                // ISSUE: method pointer
                                                                \u0031C561093.\u00329503060 obj34 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0033A0A5115));
                                                                uint num185 = num184 + 199058677U;
                                                                dictionary34[(uint) num183] = obj34;
                                                                uint num186 = num185 | 1617838746U;
                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary35 = this.\u003342620F1;
                                                                num7 = num186 ^ 1940787711U;
                                                                int num187 = (int) num7 ^ -1824425997;
                                                                \u0031C561093.\u00329503060 obj35 = new \u0031C561093.\u00329503060(this.\u0033D7426D0);
                                                                dictionary35[(uint) num187] = obj35;
                                                                if (num7 != 159079748U)
                                                                {
                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary36 = this.\u003342620F1;
                                                                  uint num188 = 520500011U * num7;
                                                                  int num189 = (int) num188 + 1356859084;
                                                                  uint num190 = num188 / 938292526U;
                                                                  // ISSUE: method pointer
                                                                  IntPtr num191 = __methodptr(\u0033A0A5115);
                                                                  uint num192 = num190 & 1875670585U;
                                                                  \u0031C561093.\u00329503060 obj36 = new \u0031C561093.\u00329503060((object) this, num191);
                                                                  dictionary36[(uint) num189] = obj36;
                                                                  uint num193 = 66915391U + num192;
                                                                  if (224030543U >= num193)
                                                                  {
                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary37 = this.\u003342620F1;
                                                                    uint num194 = 1682703353U >> (int) num193;
                                                                    int num195 = (int) num194 ^ 1682703200;
                                                                    // ISSUE: method pointer
                                                                    IntPtr num196 = __methodptr(\u00301B65D58);
                                                                    num4 = num194 << 30;
                                                                    \u0031C561093.\u00329503060 obj37 = new \u0031C561093.\u00329503060((object) this, num196);
                                                                    dictionary37[(uint) num195] = obj37;
                                                                    if (num4 < 1817125950U)
                                                                    {
                                                                      uint num197 = 1786452810U - num4;
                                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary38 = this.\u003342620F1;
                                                                      uint num198 = 1875920428U * num197;
                                                                      int num199 = (int) num198 - 952036382;
                                                                      num7 = 1872843752U & num198 % 308769516U;
                                                                      // ISSUE: method pointer
                                                                      \u0031C561093.\u00329503060 obj38 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00363B91F43));
                                                                      dictionary38[(uint) num199] = obj38;
                                                                      if (1641575804U >= num7)
                                                                      {
                                                                        uint num200 = num7 + 1111307839U;
                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary39 = this.\u003342620F1;
                                                                        int num201 = (int) num200 - 1136478596;
                                                                        \u0031C561093.\u00329503060 obj39 = new \u0031C561093.\u00329503060(this.\u00301B65D58);
                                                                        uint num202 = 1803959648U * num200;
                                                                        dictionary39[(uint) num201] = obj39;
                                                                        uint num203 = 1706316749U * num202;
                                                                        this.\u003342620F1[num203 - 3512087940U] = new \u0031C561093.\u00329503060(this.\u00363AE4409);
                                                                        if (num203 >= 342769504U)
                                                                        {
                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary40 = this.\u003342620F1;
                                                                          int num204 = (int) num203 + 782879357;
                                                                          uint num205 = 937785729U / num203 >> 13;
                                                                          // ISSUE: method pointer
                                                                          \u0031C561093.\u00329503060 obj40 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00322825D79));
                                                                          uint num206 = 1922120736U + num205;
                                                                          dictionary40[(uint) num204] = obj40;
                                                                          uint num207 = 2143825006U & num206 - 1431120410U;
                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary41 = this.\u003342620F1;
                                                                          uint num208 = num207 << 6;
                                                                          int num209 = (int) num208 ^ 1342177566;
                                                                          uint num210 = num208 / 380780528U / 136516382U;
                                                                          // ISSUE: method pointer
                                                                          IntPtr num211 = __methodptr(\u00351CA2101);
                                                                          uint num212 = num210 | 1414685604U;
                                                                          \u0031C561093.\u00329503060 obj41 = new \u0031C561093.\u00329503060((object) this, num211);
                                                                          dictionary41[(uint) num209] = obj41;
                                                                          uint num213 = 681794108U | num212;
                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary42 = this.\u003342620F1;
                                                                          uint num214 = 1598296825U ^ num213;
                                                                          int num215 = (int) num214 ^ 599222746;
                                                                          num7 = num214 * 1121205696U;
                                                                          // ISSUE: method pointer
                                                                          \u0031C561093.\u00329503060 obj42 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00369BD537E));
                                                                          dictionary42[(uint) num215] = obj42;
                                                                          if (num7 != 1872912656U)
                                                                          {
                                                                            uint num216 = num7 / 844123519U;
                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary43 = this.\u003342620F1;
                                                                            int num217 = (int) num216 + 158;
                                                                            uint num218 = 3040261U | num216 - 288759409U;
                                                                            // ISSUE: method pointer
                                                                            IntPtr num219 = __methodptr(\u00345220DC2);
                                                                            uint num220 = num218 % 138967993U;
                                                                            \u0031C561093.\u00329503060 obj43 = new \u0031C561093.\u00329503060((object) this, num219);
                                                                            dictionary43[(uint) num217] = obj43;
                                                                            uint num221 = num220 - 480014530U ^ 180832602U;
                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary44 = this.\u003342620F1;
                                                                            uint num222 = num221 << 29;
                                                                            int num223 = (int) num222 - -1610612897;
                                                                            uint num224 = num222 >> 20;
                                                                            // ISSUE: method pointer
                                                                            \u0031C561093.\u00329503060 obj44 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u003006C3635));
                                                                            uint num225 = 1393909312U | num224;
                                                                            dictionary44[(uint) num223] = obj44;
                                                                            num4 = 1691567537U | num225;
                                                                            if ((int) num4 + 1772896079 != 0)
                                                                            {
                                                                              uint num226 = 1897202188U % num4;
                                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary45 = this.\u003342620F1;
                                                                              uint num227 = 746130567U * num226;
                                                                              int num228 = (int) num227 - -1512528974;
                                                                              // ISSUE: method pointer
                                                                              IntPtr num229 = __methodptr(\u00337533FAF);
                                                                              uint num230 = 406726018U >> (int) num227;
                                                                              \u0031C561093.\u00329503060 obj45 = new \u0031C561093.\u00329503060((object) this, num229);
                                                                              dictionary45[(uint) num228] = obj45;
                                                                              uint num231 = 2076451550U ^ num230;
                                                                              if (868433462U <= num231)
                                                                              {
                                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary46 = this.\u003342620F1;
                                                                                uint num232 = 1106251642U / num231;
                                                                                int num233 = (int) num232 ^ 163;
                                                                                uint num234 = num232 | 1743267394U;
                                                                                // ISSUE: method pointer
                                                                                \u0031C561093.\u00329503060 obj46 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00363B91F43));
                                                                                num9 = 2109486227U * num234;
                                                                                dictionary46[(uint) num233] = obj46;
                                                                                if ((102436495 ^ (int) num9) != 0)
                                                                                {
                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary47 = this.\u003342620F1;
                                                                                  int num235 = (int) num9 - 613113666;
                                                                                  uint num236 = (num9 ^ 1988841630U) % 164304005U;
                                                                                  // ISSUE: method pointer
                                                                                  \u0031C561093.\u00329503060 obj47 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0032F1B1F02));
                                                                                  uint num237 = 2024082351U >> (int) num236;
                                                                                  dictionary47[(uint) num235] = obj47;
                                                                                  num7 = num237 >> 19;
                                                                                  if (651957770 - (int) num7 != 0)
                                                                                  {
                                                                                    uint num238 = num7 & 1250771737U;
                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary48 = this.\u003342620F1;
                                                                                    uint num239 = num238 >> 6;
                                                                                    int num240 = (int) num239 ^ 165;
                                                                                    uint num241 = 810616921U - num239;
                                                                                    \u0031C561093.\u00329503060 obj48 = new \u0031C561093.\u00329503060(this.\u003542961F1);
                                                                                    dictionary48[(uint) num240] = obj48;
                                                                                    uint num242 = num241 >> 18;
                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary49 = this.\u003342620F1;
                                                                                    uint num243 = num242 | 1446280559U;
                                                                                    int num244 = (int) num243 ^ 1446280665;
                                                                                    // ISSUE: method pointer
                                                                                    IntPtr num245 = __methodptr(\u00301B65D58);
                                                                                    uint num246 = num243 & 51846957U;
                                                                                    \u0031C561093.\u00329503060 obj49 = new \u0031C561093.\u00329503060((object) this, num245);
                                                                                    uint num247 = 1707298612U ^ num246;
                                                                                    dictionary49[(uint) num244] = obj49;
                                                                                    uint num248 = 1574245823U + num247;
                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary50 = this.\u003342620F1;
                                                                                    int num249 = (int) num248 - -978557135;
                                                                                    uint num250 = num248 % 417159101U - 146608956U;
                                                                                    // ISSUE: method pointer
                                                                                    \u0031C561093.\u00329503060 obj50 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0030D231658));
                                                                                    uint num251 = num250 + 1230660413U;
                                                                                    dictionary50[(uint) num249] = obj50;
                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary51 = this.\u003342620F1;
                                                                                    int num252 = (int) num251 ^ 1480347910;
                                                                                    uint num253 = 640888039U << (int) num251;
                                                                                    \u0031C561093.\u00329503060 obj51 = new \u0031C561093.\u00329503060(this.\u0033A0A5115);
                                                                                    dictionary51[(uint) num252] = obj51;
                                                                                    uint num254 = 2001158160U << (int) num253;
                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary52 = this.\u003342620F1;
                                                                                    uint num255 = num254 & 349191120U;
                                                                                    int num256 = (int) num255 ^ 339738809;
                                                                                    uint num257 = 1013713213U % num255;
                                                                                    // ISSUE: method pointer
                                                                                    IntPtr num258 = __methodptr(\u00322825D79);
                                                                                    uint num259 = 531787125U & num257;
                                                                                    \u0031C561093.\u00329503060 obj52 = new \u0031C561093.\u00329503060((object) this, num258);
                                                                                    uint num260 = 1557728818U % num259;
                                                                                    dictionary52[(uint) num256] = obj52;
                                                                                    uint num261 = num260 / 561279240U / 1721714464U;
                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary53 = this.\u003342620F1;
                                                                                    int num262 = (int) num261 ^ 170;
                                                                                    uint num263 = 1276931148U & 648177270U >> (int) num261;
                                                                                    // ISSUE: method pointer
                                                                                    \u0031C561093.\u00329503060 obj53 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0034722764A));
                                                                                    uint num264 = num263 ^ 1720063450U;
                                                                                    dictionary53[(uint) num262] = obj53;
                                                                                    uint num265 = 2030336405U - num264;
                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary54 = this.\u003342620F1;
                                                                                    uint num266 = num265 / 1274311662U;
                                                                                    int num267 = (int) num266 ^ 171;
                                                                                    num4 = 939935849U >> (int) num266;
                                                                                    // ISSUE: method pointer
                                                                                    \u0031C561093.\u00329503060 obj54 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00369BD537E));
                                                                                    dictionary54[(uint) num267] = obj54;
                                                                                    if (145497235 << (int) num4 != 0)
                                                                                    {
                                                                                      uint num268 = 1904574389U % num4;
                                                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary55 = this.\u003342620F1;
                                                                                      uint num269 = num268 | 780209857U;
                                                                                      int num270 = (int) num269 - 804908599;
                                                                                      uint num271 = num269 << 19;
                                                                                      // ISSUE: method pointer
                                                                                      IntPtr num272 = __methodptr(\u0031F9B2F7F);
                                                                                      uint num273 = 2087404796U + num271;
                                                                                      \u0031C561093.\u00329503060 obj55 = new \u0031C561093.\u00329503060((object) this, num272);
                                                                                      num7 = num273 % 1411329384U;
                                                                                      dictionary55[(uint) num270] = obj55;
                                                                                      if (((int) num7 ^ 1576551527) != 0)
                                                                                      {
                                                                                        uint num274 = num7 + 1134523781U;
                                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary56 = this.\u003342620F1;
                                                                                        int num275 = (int) num274 - -1897636092;
                                                                                        uint num276 = num274 / 287777939U;
                                                                                        // ISSUE: method pointer
                                                                                        IntPtr num277 = __methodptr(\u0035A337EF5);
                                                                                        uint num278 = num276 - 334578013U;
                                                                                        \u0031C561093.\u00329503060 obj56 = new \u0031C561093.\u00329503060((object) this, num277);
                                                                                        dictionary56[(uint) num275] = obj56;
                                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary57 = this.\u003342620F1;
                                                                                        int num279 = (int) num278 - -334578179;
                                                                                        uint num280 = 1218982563U ^ num278;
                                                                                        // ISSUE: method pointer
                                                                                        IntPtr num281 = __methodptr(\u00379083E9E);
                                                                                        uint num282 = num280 & 1809996704U;
                                                                                        \u0031C561093.\u00329503060 obj57 = new \u0031C561093.\u00329503060((object) this, num281);
                                                                                        dictionary57[(uint) num279] = obj57;
                                                                                        uint num283 = 1782997591U % num282;
                                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary58 = this.\u003342620F1;
                                                                                        uint num284 = 205745964U % num283;
                                                                                        int num285 = (int) num284 ^ 65217658;
                                                                                        uint num286 = num284 * 761164955U;
                                                                                        // ISSUE: method pointer
                                                                                        IntPtr num287 = __methodptr(\u00316F5471F);
                                                                                        uint num288 = 1076110115U - num286;
                                                                                        \u0031C561093.\u00329503060 obj58 = new \u0031C561093.\u00329503060((object) this, num287);
                                                                                        uint num289 = 732659521U + num288;
                                                                                        dictionary58[(uint) num285] = obj58;
                                                                                        uint num290 = num289 | 889809484U;
                                                                                        if ((int) num290 + 400313838 != 0)
                                                                                        {
                                                                                          uint num291 = 601237800U - num290;
                                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary59 = this.\u003342620F1;
                                                                                          uint num292 = num291 >> 24;
                                                                                          int num293 = (int) num292 ^ 86;
                                                                                          \u0031C561093.\u00329503060 obj59 = new \u0031C561093.\u00329503060(this.\u0034ECD6316);
                                                                                          uint num294 = 104137209U * num292;
                                                                                          dictionary59[(uint) num293] = obj59;
                                                                                          if (430772911U < num294)
                                                                                          {
                                                                                            uint num295 = num294 >> 29;
                                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary60 = this.\u003342620F1;
                                                                                            int num296 = (int) num295 - -173;
                                                                                            uint num297 = num295 - 1080954568U;
                                                                                            // ISSUE: method pointer
                                                                                            IntPtr num298 = __methodptr(\u0034D6B2980);
                                                                                            uint num299 = num297 % 845826658U;
                                                                                            \u0031C561093.\u00329503060 obj60 = new \u0031C561093.\u00329503060((object) this, num298);
                                                                                            dictionary60[(uint) num296] = obj60;
                                                                                            num4 = 1996976057U + num299;
                                                                                            if (num4 >= 2028625783U)
                                                                                            {
                                                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary61 = this.\u003342620F1;
                                                                                              uint num300 = 1253265147U + num4;
                                                                                              int num301 = (int) num300 + 368193512;
                                                                                              // ISSUE: method pointer
                                                                                              IntPtr num302 = __methodptr(\u0031F9B2F7F);
                                                                                              uint num303 = 374242737U | num300;
                                                                                              \u0031C561093.\u00329503060 obj61 = new \u0031C561093.\u00329503060((object) this, num302);
                                                                                              uint num304 = num303 * 308572861U;
                                                                                              dictionary61[(uint) num301] = obj61;
                                                                                              uint num305 = 776036179U % num304;
                                                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary62 = this.\u003342620F1;
                                                                                              uint num306 = 927663981U + num305;
                                                                                              int num307 = (int) num306 - 1703699981;
                                                                                              uint num308 = 529277973U >> (int) num306;
                                                                                              \u0031C561093.\u00329503060 obj62 = new \u0031C561093.\u00329503060(this.\u00337533FAF);
                                                                                              uint num309 = num308 >> 12;
                                                                                              dictionary62[(uint) num307] = obj62;
                                                                                              if (431970953U >> (int) num309 != 0U)
                                                                                              {
                                                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary63 = this.\u003342620F1;
                                                                                                int num310 = (int) num309 - 129038;
                                                                                                uint num311 = num309 * 1135412318U;
                                                                                                \u0031C561093.\u00329503060 obj63 = new \u0031C561093.\u00329503060(this.\u0034722764A);
                                                                                                dictionary63[(uint) num310] = obj63;
                                                                                                uint num312 = 1631154851U | num311;
                                                                                                if (22237895 << (int) num312 != 0)
                                                                                                {
                                                                                                  uint num313 = 710871149U & num312;
                                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary64 = this.\u003342620F1;
                                                                                                  uint num314 = num313 % 1272327635U;
                                                                                                  int num315 = (int) num314 ^ 673122456;
                                                                                                  uint num316 = num314 ^ 330318592U;
                                                                                                  // ISSUE: method pointer
                                                                                                  \u0031C561093.\u00329503060 obj64 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00351CA2101));
                                                                                                  uint num317 = 1868448635U << (int) num316;
                                                                                                  dictionary64[(uint) num315] = obj64;
                                                                                                  uint num318 = num317 | 857677112U;
                                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary65 = this.\u003342620F1;
                                                                                                  uint num319 = 1004554059U & num318;
                                                                                                  int num320 = (int) num319 ^ 996165054;
                                                                                                  uint num321 = 1013456940U | num319;
                                                                                                  \u0031C561093.\u00329503060 obj65 = new \u0031C561093.\u00329503060(this.\u00301B65D58);
                                                                                                  dictionary65[(uint) num320] = obj65;
                                                                                                  uint num322 = num321 / 1760526060U;
                                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary66 = this.\u003342620F1;
                                                                                                  int num323 = (int) num322 + 183;
                                                                                                  // ISSUE: method pointer
                                                                                                  IntPtr num324 = __methodptr(\u00345220DC2);
                                                                                                  uint num325 = 1861638253U - num322;
                                                                                                  \u0031C561093.\u00329503060 obj66 = new \u0031C561093.\u00329503060((object) this, num324);
                                                                                                  dictionary66[(uint) num323] = obj66;
                                                                                                  uint num326 = 1227321650U / (982204817U ^ num325);
                                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary67 = this.\u003342620F1;
                                                                                                  int num327 = (int) num326 ^ 184;
                                                                                                  uint num328 = 793665507U | num326;
                                                                                                  // ISSUE: method pointer
                                                                                                  IntPtr num329 = __methodptr(\u003006C3635);
                                                                                                  num7 = num328 / 1431708639U;
                                                                                                  \u0031C561093.\u00329503060 obj67 = new \u0031C561093.\u00329503060((object) this, num329);
                                                                                                  dictionary67[(uint) num327] = obj67;
                                                                                                  if (1704938247U >= num7)
                                                                                                  {
                                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary68 = this.\u003342620F1;
                                                                                                    int num330 = (int) num7 ^ 185;
                                                                                                    // ISSUE: method pointer
                                                                                                    IntPtr num331 = __methodptr(\u0035A337EF5);
                                                                                                    uint num332 = 1646095991U << (int) num7;
                                                                                                    \u0031C561093.\u00329503060 obj68 = new \u0031C561093.\u00329503060((object) this, num331);
                                                                                                    uint num333 = num332 - 851250990U;
                                                                                                    dictionary68[(uint) num330] = obj68;
                                                                                                    uint num334 = num333 & 1128735143U;
                                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary69 = this.\u003342620F1;
                                                                                                    int num335 = (int) num334 - 54526023;
                                                                                                    uint num336 = 494688224U - num334;
                                                                                                    // ISSUE: method pointer
                                                                                                    IntPtr num337 = __methodptr(\u003417C37F2);
                                                                                                    uint num338 = 877206931U * num336;
                                                                                                    \u0031C561093.\u00329503060 obj69 = new \u0031C561093.\u00329503060((object) this, num337);
                                                                                                    uint num339 = 15683396U << (int) num338;
                                                                                                    dictionary69[(uint) num335] = obj69;
                                                                                                    uint num340 = 211315711U / num339;
                                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary70 = this.\u003342620F1;
                                                                                                    int num341 = (int) num340 ^ 187;
                                                                                                    uint num342 = num340 ^ 1249738209U;
                                                                                                    // ISSUE: method pointer
                                                                                                    IntPtr num343 = __methodptr(\u0034ADE09E8);
                                                                                                    uint num344 = 783291656U / num342;
                                                                                                    \u0031C561093.\u00329503060 obj70 = new \u0031C561093.\u00329503060((object) this, num343);
                                                                                                    uint num345 = 2038983147U ^ num344;
                                                                                                    dictionary70[(uint) num341] = obj70;
                                                                                                    uint num346 = 1897925957U ^ 215504299U / num345;
                                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary71 = this.\u003342620F1;
                                                                                                    int num347 = (int) num346 ^ 1897926137;
                                                                                                    // ISSUE: method pointer
                                                                                                    IntPtr num348 = __methodptr(\u00369EE2472);
                                                                                                    uint num349 = num346 + 131411702U;
                                                                                                    \u0031C561093.\u00329503060 obj71 = new \u0031C561093.\u00329503060((object) this, num348);
                                                                                                    dictionary71[(uint) num347] = obj71;
                                                                                                    uint num350 = num349 << 6;
                                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary72 = this.\u003342620F1;
                                                                                                    int num351 = (int) num350 ^ 1028591229;
                                                                                                    uint num352 = 1649691029U / num350;
                                                                                                    // ISSUE: method pointer
                                                                                                    \u0031C561093.\u00329503060 obj72 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00326700CB8));
                                                                                                    uint num353 = 1533234447U + num352;
                                                                                                    dictionary72[(uint) num351] = obj72;
                                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary73 = this.\u003342620F1;
                                                                                                    int num354 = (int) num353 ^ 1533234606;
                                                                                                    uint num355 = 1104222843U + num353;
                                                                                                    // ISSUE: method pointer
                                                                                                    IntPtr num356 = __methodptr(\u0032098468E);
                                                                                                    uint num357 = 186590843U << (int) num355;
                                                                                                    \u0031C561093.\u00329503060 obj73 = new \u0031C561093.\u00329503060((object) this, num356);
                                                                                                    num4 = 980251650U % num357;
                                                                                                    dictionary73[(uint) num354] = obj73;
                                                                                                  }
                                                                                                  else
                                                                                                    goto label_2;
                                                                                                }
                                                                                                else
                                                                                                  goto label_0;
                                                                                              }
                                                                                              else
                                                                                                goto label_0;
                                                                                            }
                                                                                            else
                                                                                              goto label_1;
                                                                                          }
                                                                                          else
                                                                                            goto label_0;
                                                                                        }
                                                                                        else
                                                                                          goto label_0;
                                                                                      }
                                                                                      else
                                                                                        goto label_2;
                                                                                    }
                                                                                    else
                                                                                      goto label_1;
                                                                                  }
                                                                                  else
                                                                                    goto label_2;
                                                                                }
                                                                                else
                                                                                  goto label_4;
                                                                              }
                                                                              else
                                                                                goto label_0;
                                                                            }
                                                                            else
                                                                              goto label_1;
                                                                          }
                                                                          else
                                                                            goto label_2;
                                                                        }
                                                                        else
                                                                          goto label_0;
                                                                      }
                                                                      else
                                                                        goto label_2;
                                                                    }
                                                                    else
                                                                      goto label_1;
                                                                  }
                                                                  else
                                                                    goto label_0;
                                                                }
                                                                else
                                                                  goto label_2;
                                                              }
                                                              else
                                                                goto label_0;
                                                            }
                                                            else
                                                              goto label_0;
                                                          }
                                                          else
                                                            goto label_1;
                                                        }
                                                        else
                                                          goto label_0;
                                                      }
                                                      else
                                                        goto label_1;
                                                    }
                                                    else
                                                      goto label_0;
                                                  }
                                                  else
                                                    goto label_1;
                                                }
                                                else
                                                  goto label_1;
                                              }
                                              else
                                                goto label_2;
                                            }
                                            else
                                              goto label_0;
                                          }
                                          else
                                            goto label_1;
                                        }
                                        else
                                          goto label_1;
                                      }
                                      else
                                        goto label_0;
                                    }
                                    else
                                      goto label_0;
                                  }
                                  else
                                    goto label_0;
                                }
                                else
                                  goto label_0;
                              }
                              else
                                goto label_0;
                            }
                            else
                              goto label_0;
                          }
                          else
                            goto label_0;
                        }
                        else
                          goto label_1;
                      }
                      else
                        goto label_0;
                    }
                    else
                      goto label_0;
                  }
                  while (num4 < 546134763U);
                  uint num513 = 1477252170U & num4;
                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary115 = this.\u003342620F1;
                  uint num514 = num513 << 0;
                  int num515 = (int) num514 ^ 403510461;
                  uint num516 = 677333456U % (354102560U << (int) num514);
                  // ISSUE: method pointer
                  IntPtr num517 = __methodptr(\u0030D231658);
                  uint num518 = 1723228061U + num516;
                  \u0031C561093.\u00329503060 obj115 = new \u0031C561093.\u00329503060((object) this, num517);
                  dictionary115[(uint) num515] = obj115;
                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary116 = this.\u003342620F1;
                  uint num519 = 78527208U / num518;
                  int num520 = (int) num519 - -192;
                  uint num521 = 617883916U + num519;
                  // ISSUE: method pointer
                  IntPtr num522 = __methodptr(\u0034D8821C6);
                  uint num523 = num521 * 1728792033U;
                  \u0031C561093.\u00329503060 obj116 = new \u0031C561093.\u00329503060((object) this, num522);
                  dictionary116[(uint) num520] = obj116;
                  uint num524 = 280652802U % num523 | 1300190590U;
                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary117 = this.\u003342620F1;
                  uint num525 = num524 * 1243940157U;
                  int num526 = (int) num525 + 225813435;
                  uint num527 = num525 / 6619280U;
                  // ISSUE: method pointer
                  IntPtr num528 = __methodptr(\u0033B5C3155);
                  num4 = 1511999840U - num527;
                  \u0031C561093.\u00329503060 obj117 = new \u0031C561093.\u00329503060((object) this, num528);
                  dictionary117[(uint) num526] = obj117;
                  if (1386030535 << (int) num4 != 0)
                  {
                    uint num12 = num4 * 1540504704U;
                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary1 = this.\u003342620F1;
                    int num13 = (int) num12 ^ 2069501378;
                    uint num14 = num12 | 1700285127U;
                    \u0031C561093.\u00329503060 obj1 = new \u0031C561093.\u00329503060(this.\u0034D6B2980);
                    uint num15 = num14 & 485367461U;
                    dictionary1[(uint) num13] = obj1;
                    uint num16 = 360929740U - num15;
                    if (((int) num16 ^ 1403086764) != 0)
                    {
                      uint num17 = num16 | 1664771317U;
                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary2 = this.\u003342620F1;
                      uint num18 = 584781425U ^ num17;
                      int num19 = (int) num18 ^ -639602363;
                      uint num20 = 1032346112U - num18 & 156981711U;
                      // ISSUE: method pointer
                      \u0031C561093.\u00329503060 obj2 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0034D6B2980));
                      dictionary2[(uint) num19] = obj2;
                      num9 = 428628825U ^ num20;
                      if (((int) num9 ^ 1829849319) != 0)
                      {
                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary3 = this.\u003342620F1;
                        int num21 = (int) num9 ^ 412029911;
                        uint num22 = 1323719329U >> (int) num9;
                        // ISSUE: method pointer
                        IntPtr num23 = __methodptr(\u00334B11578);
                        uint num24 = num22 << 9;
                        \u0031C561093.\u00329503060 obj3 = new \u0031C561093.\u00329503060((object) this, num23);
                        uint num25 = num24 | 832588200U;
                        dictionary3[(uint) num21] = obj3;
                        uint num26 = num25 / 1020668653U;
                        if (((int) num26 ^ 782985355) != 0)
                        {
                          uint num27 = 296177041U | num26;
                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary4 = this.\u003342620F1;
                          int num28 = (int) num27 - 296176844;
                          uint num29 = num27 / 300840700U;
                          // ISSUE: method pointer
                          IntPtr num30 = __methodptr(\u003542961F1);
                          uint num31 = num29 | 2027318365U;
                          \u0031C561093.\u00329503060 obj4 = new \u0031C561093.\u00329503060((object) this, num30);
                          uint num32 = 1720915934U + num31;
                          dictionary4[(uint) num28] = obj4;
                          if (1535255504U != num32)
                          {
                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary5 = this.\u003342620F1;
                            uint num33 = 170998637U + num32;
                            int num34 = (int) num33 - -375734558;
                            uint num35 = 813399885U * num33 ^ 548277794U;
                            // ISSUE: method pointer
                            IntPtr num36 = __methodptr(\u0030D231658);
                            uint num37 = num35 | 1759789605U;
                            \u0031C561093.\u00329503060 obj5 = new \u0031C561093.\u00329503060((object) this, num36);
                            dictionary5[(uint) num34] = obj5;
                            uint num38 = 713704974U ^ num37;
                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary6 = this.\u003342620F1;
                            uint num39 = num38 & 1214645891U;
                            int num40 = (int) num39 - 1080427450;
                            uint num41 = 2018736982U | num39;
                            \u0031C561093.\u00329503060 obj6 = new \u0031C561093.\u00329503060(this.\u0031F9B2F7F);
                            uint num42 = num41 - 486097254U;
                            dictionary6[(uint) num40] = obj6;
                            uint num43 = 30491018U - num42;
                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary7 = this.\u003342620F1;
                            int num44 = (int) num43 ^ -1504508975;
                            uint num45 = num43 << 10;
                            // ISSUE: method pointer
                            IntPtr num46 = __methodptr(\u00337533FAF);
                            uint num47 = 1451179586U % num45;
                            \u0031C561093.\u00329503060 obj7 = new \u0031C561093.\u00329503060((object) this, num46);
                            uint num48 = num47 * 1536372646U;
                            dictionary7[(uint) num44] = obj7;
                            uint num49 = num48 >> 28;
                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary8 = this.\u003342620F1;
                            uint num50 = num49 + 2072346516U;
                            int num51 = (int) num50 - 2072346325;
                            uint num52 = 755976434U & num50;
                            \u0031C561093.\u00329503060 obj8 = new \u0031C561093.\u00329503060(this.\u00306AB7707);
                            uint num53 = 138822107U - num52;
                            dictionary8[(uint) num51] = obj8;
                            if (num53 >= 1076836342U)
                            {
                              uint num54 = 125393761U + num53;
                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary9 = this.\u003342620F1;
                              uint num55 = 1063549513U ^ num54;
                              int num56 = (int) num55 - -639750631;
                              uint num57 = num55 / 1621710186U;
                              // ISSUE: method pointer
                              IntPtr num58 = __methodptr(\u00363B91F43);
                              uint num59 = num57 & 1159295468U;
                              \u0031C561093.\u00329503060 obj9 = new \u0031C561093.\u00329503060((object) this, num58);
                              dictionary9[(uint) num56] = obj9;
                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary10 = this.\u003342620F1;
                              uint num60 = 1981958417U | num59;
                              int num61 = (int) num60 - 1981958214;
                              uint num62 = (num60 >> 14) / 1854677752U;
                              // ISSUE: method pointer
                              IntPtr num63 = __methodptr(\u0031F287E0C);
                              uint num64 = num62 << 9;
                              \u0031C561093.\u00329503060 obj10 = new \u0031C561093.\u00329503060((object) this, num63);
                              dictionary10[(uint) num61] = obj10;
                              num7 = num64 & 1027044518U;
                              if (num7 != 1867935812U)
                              {
                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary11 = this.\u003342620F1;
                                int num65 = (int) num7 + 204;
                                uint num66 = num7 % 1820084922U;
                                // ISSUE: method pointer
                                \u0031C561093.\u00329503060 obj11 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0035A337EF5));
                                dictionary11[(uint) num65] = obj11;
                                uint num67 = 1944459853U >> (int) num66;
                                if (2062157466U >= num67)
                                {
                                  uint num68 = num67 / 1405640626U;
                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary12 = this.\u003342620F1;
                                  uint num69 = num68 * 1301636231U;
                                  int num70 = (int) num69 - 1301636026;
                                  uint num71 = 1890211535U / (118120426U << (int) num69);
                                  // ISSUE: method pointer
                                  \u0031C561093.\u00329503060 obj12 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0032F1B1F02));
                                  uint num72 = 481842325U << (int) num71;
                                  dictionary12[(uint) num70] = obj12;
                                  uint num73 = 1895654960U % num72;
                                  if ((1538466190 ^ (int) num73) != 0)
                                  {
                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary13 = this.\u003342620F1;
                                    uint num74 = num73 / 1642486121U;
                                    int num75 = (int) num74 + 206;
                                    uint num76 = num74 << 21;
                                    \u0031C561093.\u00329503060 obj13 = new \u0031C561093.\u00329503060(this.\u003241C3A12);
                                    uint num77 = 887308242U & num76;
                                    dictionary13[(uint) num75] = obj13;
                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary14 = this.\u003342620F1;
                                    int num78 = (int) num77 ^ 207;
                                    uint num79 = 562195368U & num77;
                                    // ISSUE: method pointer
                                    IntPtr num80 = __methodptr(\u00303DD46B9);
                                    uint num81 = num79 * 400189939U;
                                    \u0031C561093.\u00329503060 obj14 = new \u0031C561093.\u00329503060((object) this, num80);
                                    dictionary14[(uint) num78] = obj14;
                                    uint num82 = num81 % 1580489707U;
                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary15 = this.\u003342620F1;
                                    int num83 = (int) num82 - -208;
                                    uint num84 = num82 / 1106595517U;
                                    \u0031C561093.\u00329503060 obj15 = new \u0031C561093.\u00329503060(this.\u003417C37F2);
                                    dictionary15[(uint) num83] = obj15;
                                    if (num84 != 1275932560U)
                                    {
                                      uint num85 = num84 & 1200584400U;
                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary16 = this.\u003342620F1;
                                      int num86 = (int) num85 + 209;
                                      uint num87 = 1720856919U * num85;
                                      // ISSUE: method pointer
                                      \u0031C561093.\u00329503060 obj16 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0035E492702));
                                      uint num88 = 1241333753U * num87;
                                      dictionary16[(uint) num86] = obj16;
                                      if (((int) num88 & 158598864) == 0)
                                      {
                                        uint num89 = 1586192719U - num88;
                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary17 = this.\u003342620F1;
                                        int num90 = (int) num89 ^ 1586192797;
                                        // ISSUE: method pointer
                                        IntPtr num91 = __methodptr(\u0034D6B2980);
                                        uint num92 = 424627322U + num89;
                                        \u0031C561093.\u00329503060 obj17 = new \u0031C561093.\u00329503060((object) this, num91);
                                        uint num93 = num92 << 25;
                                        dictionary17[(uint) num90] = obj17;
                                        uint num94 = 1545825183U >> (int) num93;
                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary18 = this.\u003342620F1;
                                        int num95 = (int) num94 - 1545824972;
                                        uint num96 = 787618921U ^ num94;
                                        // ISSUE: method pointer
                                        \u0031C561093.\u00329503060 obj18 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0034D6B2980));
                                        uint num97 = 1584882102U & num96;
                                        dictionary18[(uint) num95] = obj18;
                                        uint num98 = num97 ^ 1248547590U;
                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary19 = this.\u003342620F1;
                                        uint num99 = 1529311509U / num98;
                                        int num100 = (int) num99 + 209;
                                        uint num101 = num99 + 1591173725U ^ 1241598410U;
                                        // ISSUE: method pointer
                                        IntPtr num102 = __methodptr(\u00301B65D58);
                                        uint num103 = 1377785710U | num101;
                                        \u0031C561093.\u00329503060 obj19 = new \u0031C561093.\u00329503060((object) this, num102);
                                        uint num104 = 1511981824U + num103;
                                        dictionary19[(uint) num100] = obj19;
                                        uint num105 = num104 & 786716248U;
                                        if (331630580 * (int) num105 != 0)
                                        {
                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary20 = this.\u003342620F1;
                                          int num106 = (int) num105 ^ 551813789;
                                          uint num107 = (46539158U << (int) num105) % 630552838U;
                                          // ISSUE: method pointer
                                          IntPtr num108 = __methodptr(\u00301B65D58);
                                          uint num109 = num107 << 21;
                                          \u0031C561093.\u00329503060 obj20 = new \u0031C561093.\u00329503060((object) this, num108);
                                          dictionary20[(uint) num106] = obj20;
                                          if (num109 % 1526168559U != 0U)
                                          {
                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary21 = this.\u003342620F1;
                                            uint num110 = num109 >> 5;
                                            int num111 = (int) num110 ^ 14811350;
                                            uint num112 = num110 & 1599146261U ^ 533288975U;
                                            // ISSUE: method pointer
                                            \u0031C561093.\u00329503060 obj21 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0034722764A));
                                            dictionary21[(uint) num111] = obj21;
                                            uint num113 = num112 % 129791746U;
                                            if ((int) num113 * 1080184009 != 0)
                                            {
                                              uint num114 = 233526610U - num113;
                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary22 = this.\u003342620F1;
                                              uint num115 = 2140938580U & num114;
                                              int num116 = (int) num115 - 219152489;
                                              uint num117 = num115 >> 27;
                                              \u0031C561093.\u00329503060 obj22 = new \u0031C561093.\u00329503060(this.\u003253C5A20);
                                              dictionary22[(uint) num116] = obj22;
                                              uint num118 = 246575483U * num117;
                                              if (1130563576U != num118)
                                              {
                                                uint num119 = 74601640U + num118;
                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary23 = this.\u003342620F1;
                                                uint num120 = 757881214U << (int) num119;
                                                int num121 = (int) num120 ^ 1768082216;
                                                // ISSUE: method pointer
                                                IntPtr num122 = __methodptr(\u00345220DC2);
                                                uint num123 = 1624316793U - num120;
                                                \u0031C561093.\u00329503060 obj23 = new \u0031C561093.\u00329503060((object) this, num122);
                                                uint num124 = num123 ^ 86397970U;
                                                dictionary23[(uint) num121] = obj23;
                                                num4 = 1222399583U + num124;
                                                if (295503896U <= num4)
                                                {
                                                  uint num125 = num4 ^ 738096842U;
                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary24 = this.\u003342620F1;
                                                  uint num126 = num125 + 178014840U;
                                                  int num127 = (int) num126 ^ 460738929;
                                                  uint num128 = 969738267U + num126;
                                                  // ISSUE: method pointer
                                                  \u0031C561093.\u00329503060 obj24 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00345220DC2));
                                                  dictionary24[(uint) num127] = obj24;
                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary25 = this.\u003342620F1;
                                                  int num129 = (int) num128 - 1430477033;
                                                  uint num130 = 13382302U & num128;
                                                  // ISSUE: method pointer
                                                  IntPtr num131 = __methodptr(\u00303DD46B9);
                                                  uint num132 = 1275227428U * num130;
                                                  \u0031C561093.\u00329503060 obj25 = new \u0031C561093.\u00329503060((object) this, num131);
                                                  uint num133 = num132 & 290854883U;
                                                  dictionary25[(uint) num129] = obj25;
                                                  uint num134 = num133 + 227740923U;
                                                  if (num134 >= 217466931U)
                                                  {
                                                    uint num135 = num134 | 14304375U;
                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary26 = this.\u003342620F1;
                                                    int num136 = (int) num135 ^ 249517476;
                                                    uint num137 = num135 & 2001474970U;
                                                    // ISSUE: method pointer
                                                    IntPtr num138 = __methodptr(\u00363AE4409);
                                                    uint num139 = num137 >> 0;
                                                    \u0031C561093.\u00329503060 obj26 = new \u0031C561093.\u00329503060((object) this, num138);
                                                    dictionary26[(uint) num136] = obj26;
                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary27 = this.\u003342620F1;
                                                    uint num140 = 1762207677U & num139;
                                                    int num141 = (int) num140 - 525372;
                                                    uint num142 = num140 << 13;
                                                    // ISSUE: method pointer
                                                    \u0031C561093.\u00329503060 obj27 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00325E44E64));
                                                    uint num143 = num142 - 1133009530U;
                                                    dictionary27[(uint) num141] = obj27;
                                                    uint num144 = num143 ^ 1497257639U;
                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary28 = this.\u003342620F1;
                                                    int num145 = (int) num144 - -467340732;
                                                    // ISSUE: method pointer
                                                    IntPtr num146 = __methodptr(\u00378242571);
                                                    uint num147 = num144 * 1428951378U;
                                                    \u0031C561093.\u00329503060 obj28 = new \u0031C561093.\u00329503060((object) this, num146);
                                                    dictionary28[(uint) num145] = obj28;
                                                    uint num148 = num147 * 2006327436U;
                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary29 = this.\u003342620F1;
                                                    int num149 = (int) num148 ^ -1357128954;
                                                    \u0031C561093.\u00329503060 obj29 = new \u0031C561093.\u00329503060(this.\u00351CA2101);
                                                    uint num150 = num148 * 23863882U;
                                                    dictionary29[(uint) num149] = obj29;
                                                    uint num151 = 1813801621U + num150;
                                                    if (1532844913U > num151)
                                                    {
                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary30 = this.\u003342620F1;
                                                      int num152 = (int) num151 - 1417455142;
                                                      uint num153 = 491874578U * (1916763534U - num151);
                                                      // ISSUE: method pointer
                                                      IntPtr num154 = __methodptr(\u003542961F1);
                                                      uint num155 = num153 * 923232174U;
                                                      \u0031C561093.\u00329503060 obj30 = new \u0031C561093.\u00329503060((object) this, num154);
                                                      uint num156 = num155 - 1862283524U;
                                                      dictionary30[(uint) num152] = obj30;
                                                      uint num157 = 322974087U - num156;
                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary31 = this.\u003342620F1;
                                                      int num158 = (int) num157 + 328519281;
                                                      uint num159 = 484535193U * num157 - 1510356447U;
                                                      // ISSUE: method pointer
                                                      IntPtr num160 = __methodptr(\u0033CB32B5C);
                                                      uint num161 = 447566977U & num159;
                                                      \u0031C561093.\u00329503060 obj31 = new \u0031C561093.\u00329503060((object) this, num160);
                                                      num7 = num161 / 1580817369U;
                                                      dictionary31[(uint) num158] = obj31;
                                                      if (num7 % 901530453U == 0U)
                                                      {
                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary32 = this.\u003342620F1;
                                                        uint num162 = num7 + 1719945142U;
                                                        int num163 = (int) num162 ^ 1719945047;
                                                        \u0031C561093.\u00329503060 obj32 = new \u0031C561093.\u00329503060(this.\u0032DF91857);
                                                        uint num164 = num162 / 790910580U;
                                                        dictionary32[(uint) num163] = obj32;
                                                        uint num165 = num164 - 1193610326U;
                                                        if (((int) num165 & 364128318) != 0)
                                                        {
                                                          uint num166 = 540414317U >> (int) num165;
                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary33 = this.\u003342620F1;
                                                          int num167 = (int) num166 - 131711;
                                                          num4 = 1735748881U % num166;
                                                          \u0031C561093.\u00329503060 obj33 = new \u0031C561093.\u00329503060(this.\u0035A337EF5);
                                                          dictionary33[(uint) num167] = obj33;
                                                          if (151076255U != num4)
                                                          {
                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary34 = this.\u003342620F1;
                                                            num7 = 469901586U ^ num4;
                                                            int num168 = (int) num7 ^ 470018687;
                                                            \u0031C561093.\u00329503060 obj34 = new \u0031C561093.\u00329503060(this.\u0037E5F7AB9);
                                                            dictionary34[(uint) num168] = obj34;
                                                            if (num7 <= 1511488148U)
                                                            {
                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary35 = this.\u003342620F1;
                                                              uint num169 = 397098107U - num7;
                                                              int num170 = (int) num169 + 72920837;
                                                              uint num171 = 1762215500U - (1032008055U & num169);
                                                              // ISSUE: method pointer
                                                              \u0031C561093.\u00329503060 obj35 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0032F1B1F02));
                                                              uint num172 = 334591289U / num171;
                                                              dictionary35[(uint) num170] = obj35;
                                                              num4 = num172 | 1211266414U;
                                                              if (((int) num4 & 1885628577) != 0)
                                                              {
                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary36 = this.\u003342620F1;
                                                                uint num173 = 689969281U * num4;
                                                                int num174 = (int) num173 - 1747942281;
                                                                uint num175 = num173 & 412047548U;
                                                                // ISSUE: method pointer
                                                                IntPtr num176 = __methodptr(\u0034722764A);
                                                                uint num177 = num175 & 1777087080U;
                                                                \u0031C561093.\u00329503060 obj36 = new \u0031C561093.\u00329503060((object) this, num176);
                                                                dictionary36[(uint) num174] = obj36;
                                                                if ((1676287016 ^ (int) num177) != 0)
                                                                {
                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary37 = this.\u003342620F1;
                                                                  int num178 = (int) num177 ^ 135008462;
                                                                  // ISSUE: method pointer
                                                                  IntPtr num179 = __methodptr(\u0035A337EF5);
                                                                  uint num180 = 2061699066U ^ num177;
                                                                  \u0031C561093.\u00329503060 obj37 = new \u0031C561093.\u00329503060((object) this, num179);
                                                                  uint num181 = 1015097399U * num180;
                                                                  dictionary37[(uint) num178] = obj37;
                                                                  if (464420771U <= num181)
                                                                  {
                                                                    uint num182 = 1722368859U - num181;
                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary38 = this.\u003342620F1;
                                                                    int num183 = (int) num182 ^ 549475802;
                                                                    uint num184 = num182 * 188176548U;
                                                                    // ISSUE: method pointer
                                                                    IntPtr num185 = __methodptr(\u0031F287E0C);
                                                                    uint num186 = 966150448U >> (int) num184;
                                                                    \u0031C561093.\u00329503060 obj38 = new \u0031C561093.\u00329503060((object) this, num185);
                                                                    dictionary38[(uint) num183] = obj38;
                                                                    this.\u003342620F1[num186 + 4294966607U] = new \u0031C561093.\u00329503060(this.\u0031F9B2F7F);
                                                                    uint num187 = 1105528125U % (2022795834U | num186);
                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary39 = this.\u003342620F1;
                                                                    int num188 = (int) num187 ^ 1105528276;
                                                                    uint num189 = 1687177936U / num187;
                                                                    \u0031C561093.\u00329503060 obj39 = new \u0031C561093.\u00329503060(this.\u00372474421);
                                                                    uint num190 = num189 + 1423924702U;
                                                                    dictionary39[(uint) num188] = obj39;
                                                                    uint num191 = 453379959U + num190;
                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary40 = this.\u003342620F1;
                                                                    uint num192 = num191 & 871857874U;
                                                                    int num193 = (int) num192 ^ 602236088;
                                                                    uint num194 = 2091847148U >> (int) num192;
                                                                    \u0031C561093.\u00329503060 obj40 = new \u0031C561093.\u00329503060(this.\u0033CB32B5C);
                                                                    dictionary40[(uint) num193] = obj40;
                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary41 = this.\u003342620F1;
                                                                    uint num195 = num194 * 589173180U;
                                                                    int num196 = (int) num195 - -1976386135;
                                                                    uint num197 = num195 / 1183345561U;
                                                                    // ISSUE: method pointer
                                                                    \u0031C561093.\u00329503060 obj41 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00316F5471F));
                                                                    dictionary41[(uint) num196] = obj41;
                                                                    uint num198 = num197 & 1768628591U;
                                                                    this.\u003342620F1[num198 ^ 237U] = new \u0031C561093.\u00329503060(this.\u003480E7F57);
                                                                    uint num199 = num198 << 19;
                                                                    if (117209907U >> (int) num199 != 0U)
                                                                    {
                                                                      Dictionary<uint, \u0031C561093.\u00329503060> dictionary42 = this.\u003342620F1;
                                                                      uint num200 = num199 * 355235263U;
                                                                      int num201 = (int) num200 ^ -1376255763;
                                                                      uint num202 = num200 + 2112110926U;
                                                                      \u0031C561093.\u00329503060 obj42 = new \u0031C561093.\u00329503060(this.\u0030D231658);
                                                                      dictionary42[(uint) num201] = obj42;
                                                                      if (873813141U > num202)
                                                                      {
                                                                        uint num203 = 1450845057U + num202;
                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary43 = this.\u003342620F1;
                                                                        int num204 = (int) num203 ^ -2108267487;
                                                                        uint num205 = num203 - 1872825124U;
                                                                        // ISSUE: method pointer
                                                                        IntPtr num206 = __methodptr(\u00363AE4409);
                                                                        uint num207 = num205 + 1824917892U;
                                                                        \u0031C561093.\u00329503060 obj43 = new \u0031C561093.\u00329503060((object) this, num206);
                                                                        dictionary43[(uint) num204] = obj43;
                                                                        uint num208 = num207 + 392966020U;
                                                                        Dictionary<uint, \u0031C561093.\u00329503060> dictionary44 = this.\u003342620F1;
                                                                        int num209 = (int) num208 ^ -1763208612;
                                                                        uint num210 = 1486321543U | 885196831U >> (int) num208;
                                                                        // ISSUE: method pointer
                                                                        IntPtr num211 = __methodptr(\u00326700CB8);
                                                                        uint num212 = 1078084894U % num210;
                                                                        \u0031C561093.\u00329503060 obj44 = new \u0031C561093.\u00329503060((object) this, num211);
                                                                        dictionary44[(uint) num209] = obj44;
                                                                        uint num213 = 2116509410U >> (int) num212;
                                                                        if (((int) num213 ^ 1031365098) != 0)
                                                                        {
                                                                          uint num214 = num213 * 183378290U;
                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary45 = this.\u003342620F1;
                                                                          uint num215 = 1468340981U << (int) num214;
                                                                          int num216 = (int) num215 ^ 1809055984;
                                                                          uint num217 = 1048581294U * num215 % 1974947738U;
                                                                          // ISSUE: method pointer
                                                                          \u0031C561093.\u00329503060 obj45 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0032F1B1F02));
                                                                          dictionary45[(uint) num216] = obj45;
                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary46 = this.\u003342620F1;
                                                                          uint num218 = num217 * 593627918U;
                                                                          int num219 = (int) num218 - 501876387;
                                                                          uint num220 = 902192573U & num218;
                                                                          // ISSUE: method pointer
                                                                          IntPtr num221 = __methodptr(\u00369BD537E);
                                                                          uint num222 = 1759671599U & num220;
                                                                          \u0031C561093.\u00329503060 obj46 = new \u0031C561093.\u00329503060((object) this, num221);
                                                                          uint num223 = 926089796U * num222;
                                                                          dictionary46[(uint) num219] = obj46;
                                                                          uint num224 = num223 & 1978008965U;
                                                                          Dictionary<uint, \u0031C561093.\u00329503060> dictionary47 = this.\u003342620F1;
                                                                          int num225 = (int) num224 ^ 289801714;
                                                                          uint num226 = num224 * 744518840U;
                                                                          \u0031C561093.\u00329503060 obj47 = new \u0031C561093.\u00329503060(this.\u003598D2D17);
                                                                          dictionary47[(uint) num225] = obj47;
                                                                          uint num227 = 1394020744U >> (int) num226;
                                                                          if (65951981U < num227)
                                                                          {
                                                                            uint num228 = num227 - 763525289U;
                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary48 = this.\u003342620F1;
                                                                            uint num229 = num228 - 1483164094U;
                                                                            int num230 = (int) num229 ^ -852668462;
                                                                            \u0031C561093.\u00329503060 obj48 = new \u0031C561093.\u00329503060(this.\u00345220DC2);
                                                                            uint num231 = num229 & 1113328768U;
                                                                            dictionary48[(uint) num230] = obj48;
                                                                            uint num232 = 707230987U - (num231 + 1065173640U);
                                                                            Dictionary<uint, \u0031C561093.\u00329503060> dictionary49 = this.\u003342620F1;
                                                                            int num233 = (int) num232 ^ -1432473993;
                                                                            uint num234 = (1615081170U ^ num232) & 549011667U;
                                                                            // ISSUE: method pointer
                                                                            IntPtr num235 = __methodptr(\u0031F9B2F7F);
                                                                            uint num236 = 1340161312U / num234;
                                                                            \u0031C561093.\u00329503060 obj49 = new \u0031C561093.\u00329503060((object) this, num235);
                                                                            num4 = num236 / 65610671U;
                                                                            dictionary49[(uint) num233] = obj49;
                                                                            if (num4 % 323304218U == 0U)
                                                                            {
                                                                              uint num237 = num4 * 2109342495U;
                                                                              Dictionary<uint, \u0031C561093.\u00329503060> dictionary50 = this.\u003342620F1;
                                                                              int num238 = (int) num237 ^ 245;
                                                                              uint num239 = 1975808933U | num237;
                                                                              // ISSUE: method pointer
                                                                              IntPtr num240 = __methodptr(\u0034722764A);
                                                                              uint num241 = 1329093604U + num239;
                                                                              \u0031C561093.\u00329503060 obj50 = new \u0031C561093.\u00329503060((object) this, num240);
                                                                              uint num242 = num241 * 70846817U;
                                                                              dictionary50[(uint) num238] = obj50;
                                                                              num4 = num242 * 47277181U;
                                                                              if (147466133U < num4)
                                                                              {
                                                                                Dictionary<uint, \u0031C561093.\u00329503060> dictionary51 = this.\u003342620F1;
                                                                                int num243 = (int) num4 ^ 1181981747;
                                                                                num4 = 1289844656U % (937262095U >> (int) num4);
                                                                                // ISSUE: method pointer
                                                                                \u0031C561093.\u00329503060 obj51 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00372474421));
                                                                                dictionary51[(uint) num243] = obj51;
                                                                                if (1434792598U >= num4)
                                                                                {
                                                                                  uint num244 = num4 + 827673293U;
                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary52 = this.\u003342620F1;
                                                                                  uint num245 = 233195285U * num244;
                                                                                  int num246 = (int) num245 ^ -1925725642;
                                                                                  uint num247 = 431058113U ^ num245;
                                                                                  \u0031C561093.\u00329503060 obj52 = new \u0031C561093.\u00329503060(this.\u003253C5A20);
                                                                                  uint num248 = 979177983U - num247;
                                                                                  dictionary52[(uint) num246] = obj52;
                                                                                  uint num249 = 414599023U & num248;
                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary53 = this.\u003342620F1;
                                                                                  int num250 = (int) num249 - 9847415;
                                                                                  uint num251 = num249 >> 23;
                                                                                  // ISSUE: method pointer
                                                                                  IntPtr num252 = __methodptr(\u0031F287E0C);
                                                                                  uint num253 = 259589272U + num251;
                                                                                  \u0031C561093.\u00329503060 obj53 = new \u0031C561093.\u00329503060((object) this, num252);
                                                                                  dictionary53[(uint) num250] = obj53;
                                                                                  Dictionary<uint, \u0031C561093.\u00329503060> dictionary54 = this.\u003342620F1;
                                                                                  int num254 = (int) num253 - 259589024;
                                                                                  uint num255 = num253 * 1767245937U;
                                                                                  // ISSUE: method pointer
                                                                                  \u0031C561093.\u00329503060 obj54 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00345977C35));
                                                                                  uint num256 = 207650431U * num255;
                                                                                  dictionary54[(uint) num254] = obj54;
                                                                                  uint num257 = 1060790960U + num256;
                                                                                  if (1392729302U != num257)
                                                                                  {
                                                                                    uint num258 = num257 + 1542338967U;
                                                                                    Dictionary<uint, \u0031C561093.\u00329503060> dictionary55 = this.\u003342620F1;
                                                                                    uint num259 = num258 | 254411904U;
                                                                                    int num260 = (int) num259 ^ 1874853700;
                                                                                    uint num261 = 481758107U & num259;
                                                                                    \u0031C561093.\u00329503060 obj55 = new \u0031C561093.\u00329503060(this.\u00363B91F43);
                                                                                    num4 = num261 << 30;
                                                                                    dictionary55[(uint) num260] = obj55;
                                                                                  }
                                                                                  else
                                                                                    goto label_0;
                                                                                }
                                                                                else
                                                                                  goto label_1;
                                                                              }
                                                                              else
                                                                                goto label_1;
                                                                            }
                                                                            else
                                                                              goto label_1;
                                                                          }
                                                                          else
                                                                            goto label_0;
                                                                        }
                                                                        else
                                                                          goto label_0;
                                                                      }
                                                                      else
                                                                        goto label_0;
                                                                    }
                                                                    else
                                                                      goto label_0;
                                                                  }
                                                                  else
                                                                    goto label_0;
                                                                }
                                                                else
                                                                  goto label_0;
                                                              }
                                                              else
                                                                goto label_1;
                                                            }
                                                            else
                                                              goto label_2;
                                                          }
                                                          else
                                                            goto label_1;
                                                        }
                                                        else
                                                          goto label_0;
                                                      }
                                                      else
                                                        goto label_2;
                                                    }
                                                    else
                                                      goto label_0;
                                                  }
                                                  else
                                                    goto label_0;
                                                }
                                                else
                                                  goto label_1;
                                              }
                                              else
                                                goto label_0;
                                            }
                                            else
                                              goto label_0;
                                          }
                                          else
                                            goto label_0;
                                        }
                                        else
                                          goto label_0;
                                      }
                                      else
                                        goto label_0;
                                    }
                                    else
                                      goto label_0;
                                  }
                                  else
                                    goto label_0;
                                }
                                else
                                  goto label_0;
                              }
                              else
                                goto label_2;
                            }
                            else
                              goto label_0;
                          }
                          else
                            goto label_0;
                        }
                        else
                          goto label_0;
                      }
                      else
                        goto label_3;
                    }
                    else
                      goto label_0;
                  }
                  else
                    goto label_1;
                }
                while (num4 == 68757127U);
                Dictionary<uint, \u0031C561093.\u00329503060> dictionary118 = this.\u003342620F1;
                int num529 = (int) num4 - 2147483397;
                uint num530 = num4 / 1520390797U;
                \u0031C561093.\u00329503060 obj118 = new \u0031C561093.\u00329503060(this.\u0031F287E0C);
                dictionary118[(uint) num529] = obj118;
                uint num531 = (num530 ^ 91048954U) + 643314843U;
                Dictionary<uint, \u0031C561093.\u00329503060> dictionary119 = this.\u003342620F1;
                int num532 = (int) num531 ^ 734363754;
                uint num533 = 6701161U / (num531 & 633999318U);
                // ISSUE: method pointer
                IntPtr num534 = __methodptr(\u0035A337EF5);
                uint num535 = num533 | 1234711084U;
                \u0031C561093.\u00329503060 obj119 = new \u0031C561093.\u00329503060((object) this, num534);
                uint num536 = num535 + 1385324044U;
                dictionary119[(uint) num532] = obj119;
                uint num537 = num536 / 727273593U;
                Dictionary<uint, \u0031C561093.\u00329503060> dictionary120 = this.\u003342620F1;
                int num538 = (int) num537 ^ 254;
                uint num539 = (1777817678U << (int) num537) * 1116633981U;
                // ISSUE: method pointer
                \u0031C561093.\u00329503060 obj120 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u0035A337EF5));
                uint num540 = num539 - 730480075U;
                dictionary120[(uint) num538] = obj120;
                num4 = num540 - 190713019U;
              }
              else
                goto label_1;
            }
            while (num4 >= 1300912294U);
            Dictionary<uint, \u0031C561093.\u00329503060> dictionary = this.\u003342620F1;
            uint num541 = 1210070546U % num4;
            int num542 = (int) num541 - 457948906;
            // ISSUE: method pointer
            IntPtr num543 = __methodptr(\u0033EFF2212);
            uint num544 = num541 / 1500793085U;
            \u0031C561093.\u00329503060 obj = new \u0031C561093.\u00329503060((object) this, num543);
            uint num545 = 293168786U + num544;
            dictionary[(uint) num542] = obj;
            num2 = 1686272000U * num545;
          }
          else
            goto label_1;
        }
      }
      while (409042509U < num2);
      Dictionary<uint, \u0031C561093.\u00329503060> dictionary121 = this.\u003342620F1;
      uint num546 = num2 >> 17;
      int num547 = (int) num546 ^ 995;
      uint num548 = num546 * 638059587U;
      // ISSUE: method pointer
      \u0031C561093.\u00329503060 obj121 = new \u0031C561093.\u00329503060((object) this, __methodptr(\u00351CA2101));
      num1 = num548 + 1682200960U;
      dictionary121[(uint) num547] = obj121;
    }
    while (num1 < 2102199550U);
  }

  private void \u0035FD24B62(\u0031C561093.\u00304BE210E _param1)
  {
    uint num1 = (uint) (1904620154 | 612912849);
    Stack<\u0031C561093.\u0033AF92E6D> objStack = this.\u0032B654A18;
    uint num2 = num1 | 888079623U;
    \u0031C561093.\u00304BE210E obj1 = _param1;
    uint num3 = num2 << 14;
    \u0031C561093.\u0033AF92E6D obj2 = obj1.\u00366E9DD83();
    uint num4 = 1167615642U - num3;
    objStack.Push(obj2);
  }

  private \u0031C561093.\u00304BE210E \u003253508E5()
  {
    uint num1 = 1970542053U >> 1316892173;
    Stack<\u0031C561093.\u0033AF92E6D> objStack = this.\u0032B654A18;
    uint num2 = num1 / 1516193296U;
    return (\u0031C561093.\u00304BE210E) objStack.Pop();
  }

  private \u0031C561093.\u00304BE210E \u003764760FF() => (\u0031C561093.\u00304BE210E) this.\u0032B654A18.Peek();

  private byte \u00353B340B3()
  {
    uint num1 = 932395228;
    long num2 = this.\u00313EB2311;
    uint num3 = num1 >> 7;
    int num4 = this.\u0035E5D486B;
    uint num5 = 1665432540U >> (int) num3;
    long num6 = (long) num4;
    uint num7 = 1091062739U << (int) num5;
    long num8 = num2 + num6;
    uint num9 = 436875205U + num7;
    IntPtr ptr = new IntPtr(num8);
    uint num10 = 2041129492U / num9;
    int num11 = (int) Marshal.ReadByte(ptr);
    uint num12 = 1155006566U * num10 - 2143442250U;
    int num13 = this.\u0035E5D486B;
    int num14 = (int) num12 ^ -1818383281;
    uint num15 = num12 | 1977093386U;
    int num16 = num13 + num14;
    uint num17 = 1696154174U << (int) num15;
    this.\u0035E5D486B = num16;
    return (byte) num11;
  }

  private short \u003514C63E6()
  {
    uint num1 = 1325870240U >> 1961566617;
    long num2 = this.\u00313EB2311 + (long) this.\u0035E5D486B;
    uint num3 = 1189480560U ^ num1;
    int num4 = (int) Marshal.ReadInt16(new IntPtr(num2));
    int num5 = this.\u0035E5D486B;
    uint num6 = num3 + 1111886761U;
    int num7 = (int) num6 + 1993600002;
    int num8 = num5 + num7;
    uint num9 = 803283436U | num6;
    this.\u0035E5D486B = num8;
    return (short) num4;
  }

  private int \u0033D5821EF()
  {
    uint num1 = (uint) (991368469 & 550781651);
    long num2 = this.\u00313EB2311;
    uint num3 = 1680679981U / (442183299U | num1);
    int num4 = this.\u0035E5D486B;
    uint num5 = 540545425U >> (int) num3;
    long num6 = (long) num4;
    IntPtr ptr = new IntPtr(num2 + num6);
    uint num7 = 638672359U << (int) num5;
    int num8 = Marshal.ReadInt32(ptr);
    uint num9 = 1281503185U << (int) (num7 % 1534355865U & 152335065U);
    int num10 = this.\u0035E5D486B + ((int) num9 - 1281503181);
    uint num11 = 2031619476U / num9;
    this.\u0035E5D486B = num10;
    return num8;
  }

  private long \u00373564BCC()
  {
    long num1 = this.\u00313EB2311;
    uint num2 = 1595889418;
    long num3 = (long) this.\u0035E5D486B;
    long num4 = num1 + num3;
    uint num5 = num2 ^ 1016755073U;
    IntPtr ptr = new IntPtr(num4);
    uint num6 = num5 % 1018121751U;
    long num7 = Marshal.ReadInt64(ptr);
    uint num8 = (1415781991U - num6) * 1403995395U / 1208039968U;
    int num9 = this.\u0035E5D486B;
    uint num10 = 951801879U - num8;
    int num11 = (int) num10 ^ 951801885;
    uint num12 = 867513830U ^ num10;
    this.\u0035E5D486B = num9 + num11;
    return num7;
  }

  private float \u0033DDD1100()
  {
    byte[] bytes = BitConverter.GetBytes(this.\u0033D5821EF());
    uint num1 = 452938553;
    int startIndex = (int) num1 ^ 452938553;
    uint num2 = 2006671443U >> (int) num1;
    return BitConverter.ToSingle(bytes, startIndex);
  }

  private double \u00308834866()
  {
    uint num1 = 1451046807U / 2023902676U;
    long num2 = this.\u00373564BCC();
    uint num3 = num1 ^ 591089663U;
    return BitConverter.ToDouble(BitConverter.GetBytes(num2), (int) num3 - 591089663);
  }

  private void \u00369EE2472()
  {
label_0:
    uint num1;
    do
    {
      uint num2 = 771896882;
      int num3 = (int) this.\u00353B340B3();
      uint num4 = num2 / 1812727380U;
      byte num5 = (byte) num3;
      uint num6 = num4 % 1942907925U;
      if (((int) num6 & 326464216) != 0)
        goto label_3;
label_1:
      uint num7 = num6 | 1794795172U;
      int num8 = this.\u0033D5821EF();
      int num9;
      if (num7 != 1071015948U)
      {
        uint num10 = num7 + 1114641179U;
        int num11 = this.\u0033D5821EF();
        uint num12 = num10 - 980365162U;
        num9 = num11;
        num6 = 1363086215U | num12;
        if (1262758092 - (int) num6 == 0)
          continue;
      }
      else
        continue;
label_3:
      uint num13 = 130118530U * num6;
      int num14 = this.\u0033D5821EF();
      uint num15 = 203504380U << (int) num13;
      if ((642393893 ^ (int) num15) != 0)
      {
        int num10 = this.\u0033D5821EF();
        uint num11 = 1717070528U - (657936333U | num15);
        \u0031C561093.\u0037BC90C3B obj1 = (\u0031C561093.\u0037BC90C3B) null;
label_5:
        int num12 = (int) num11 ^ -157738253;
        uint num16 = num11 >> 10;
        int num17 = num12;
        \u0031C561093.\u0037BC90C3B obj2;
        uint num18;
        uint num19;
        while (true)
        {
          if (1946842165U / num16 != 0U)
          {
            int num20 = num17;
            uint num21 = num16 >> 30;
            List<\u0031C561093.\u0037BC90C3B> objList1 = this.\u0033B070E12;
            num19 = num21 * 798438844U;
            int count = objList1.Count;
            if (num20 < count)
            {
              uint num22 = 1750737425;
              List<\u0031C561093.\u0037BC90C3B> objList2 = this.\u0033B070E12;
              uint num23 = 181093009U >> (int) num22;
              int index = num17;
              uint num24 = num23 * 1710054332U;
              obj2 = objList2[index];
              if (923618626U <= num24)
              {
                \u0031C561093.\u0037BC90C3B obj3 = obj2;
                num18 = num24 / 52526178U;
                if (obj3.\u00307744ACD() == num8)
                {
                  uint num25 = 835605575U | num18;
                  int num26 = obj2.\u00371A73A97();
                  uint num27 = num25 - 995638744U;
                  int num28 = num9;
                  num18 = num27 + 160033238U;
                  if (num26 == num28)
                    break;
                }
                uint num29 = num18 - 589520905U;
                int num30 = num17;
                uint num31 = 1081817714U | num29;
                int num32 = (int) num31 + 587220355;
                uint num33 = 945647424U << (int) num31;
                int num34 = num30 + num32;
                uint num35 = num33 * 1801585451U;
                num17 = num34;
                num16 = num35 ^ 4040262U;
              }
              else
                goto label_0;
            }
            else
              goto label_13;
          }
          else
            goto label_0;
        }
        obj1 = obj2;
        goto label_14;
label_13:
        num18 = num19 + 69U;
label_14:
        if (num18 <= 1612449891U)
        {
          if (obj1 == null)
          {
            uint num20 = 71779512U % num18;
            int num21 = (int) num20 - 54;
            uint num22 = 832731667U - num20;
            bool flag = num21 != 0;
            num6 = num22 / 1202158627U;
            if (((int) num6 ^ 67718471) != 0)
            {
              int num23 = num8;
              uint num24 = 1095964430U << (int) num6;
              int num25 = num9;
              num6 = num24 >> 23;
              obj1 = new \u0031C561093.\u0037BC90C3B(num23, num25);
              int num26 = (int) num6 ^ 130;
              if (num6 >> 2 != 0U)
              {
                uint num27;
                while (true)
                {
                  uint num28 = 1372063336U % num6;
                  int num29 = num26;
                  List<\u0031C561093.\u0037BC90C3B> objList1 = this.\u0033B070E12;
                  num27 = 167779616U << (int) num28;
                  int count = objList1.Count;
                  if (num29 < count)
                  {
                    List<\u0031C561093.\u0037BC90C3B> objList2 = this.\u0033B070E12;
                    uint num30 = 2134516630;
                    int index = num26;
                    \u0031C561093.\u0037BC90C3B obj3 = objList2[index];
                    uint num31 = num30 - 766779931U;
                    if (1882859593U >= num31)
                    {
                      \u0031C561093.\u0037BC90C3B obj4 = obj1;
                      \u0031C561093.\u0037BC90C3B obj5 = obj3;
                      uint num32 = num31 % 2024349193U;
                      int num33 = obj4.\u00336BF4F0D(obj5);
                      num11 = 864367388U % num32;
                      int num34 = (int) num11 ^ 864367388;
                      if (num33 >= num34)
                      {
                        if ((int) num11 * 1282220641 != 0)
                        {
                          int num35 = num26;
                          int num36 = (int) num11 ^ 864367389;
                          uint num37 = 681187930U / num11;
                          num26 = num35 + num36;
                          num6 = num37 + 130U;
                        }
                        else
                          goto label_5;
                      }
                      else
                        break;
                    }
                    else
                      goto label_0;
                  }
                  else
                    goto label_26;
                }
                uint num38 = 1433355378U & num11;
                if (((int) num38 ^ 957829501) != 0)
                {
                  List<\u0031C561093.\u0037BC90C3B> objList = this.\u0033B070E12;
                  int index = num26;
                  uint num28 = num38 / 980487163U;
                  \u0031C561093.\u0037BC90C3B obj3 = obj1;
                  uint num29 = num28 & 719467782U;
                  objList.Insert(index, obj3);
                  int num30 = (int) num29 ^ 1;
                  num6 = num29 - 1778853637U;
                  flag = num30 != 0;
                  if ((1524857605 ^ (int) num6) == 0)
                    goto label_1;
                  else
                    goto label_27;
                }
                else
                  continue;
label_26:
                num6 = num27 + 2393954555U;
label_27:
                int num39 = flag ? 1 : 0;
                num18 = num6 ^ 2516113598U;
                if (num39 == 0)
                {
                  uint num28 = num18 | 709721494U;
                  List<\u0031C561093.\u0037BC90C3B> objList = this.\u0033B070E12;
                  uint num29 = num28 + 1207727784U;
                  \u0031C561093.\u0037BC90C3B obj3 = obj1;
                  uint num30 = 431967416U | num29;
                  objList.Add(obj3);
                  num18 = num30 + 2214593350U;
                }
              }
              else
                goto label_3;
            }
            else
              goto label_3;
          }
          uint num40 = 1761746302U / num18;
          \u0031C561093.\u0037BC90C3B obj6 = obj1;
          int num41 = (int) num5;
          uint num42 = num40 >> 17;
          int num43 = num14;
          int num44 = num10;
          num1 = 1944676862U * num42;
          obj6.\u0036AC208F8((byte) num41, num43, num44);
        }
      }
    }
    while (1375216667 * (int) num1 == 0);
  }

  private TypeCode \u0030F7E56C3(
    \u0031C561093.\u00304BE210E _param1,
    \u0031C561093.\u00304BE210E _param2)
  {
label_0:
    uint num1;
    TypeCode typeCode1;
    TypeCode typeCode2;
    uint num2;
    uint num3;
    uint num4;
    do
    {
      int num5 = (int) _param1.\u003363C3519();
      num1 = 661524136U;
      typeCode1 = (TypeCode) num5;
label_1:
      \u0031C561093.\u00304BE210E obj = _param2;
      uint num6 = num1 ^ 1750681172U;
      int num7 = (int) obj.\u003363C3519();
      uint num8 = 27546537U ^ num6;
      typeCode2 = (TypeCode) num7;
      num1 = 31421617U ^ num8;
      do
      {
        int num9 = (int) typeCode1;
        num1 = 2043030969U ^ num1;
        if (num9 != 0)
        {
          num1 &= 100167523U;
          if (2133002273 + (int) num1 != 0)
          {
            uint num10;
            do
            {
              int num11 = (int) typeCode1;
              int num12 = (int) num1 ^ 76038720;
              num1 = num1 + 308828639U + 530163261U;
              if (num11 != num12)
              {
                uint num13 = num1 | 784411449U;
                if ((int) num13 << 7 != 0)
                {
                  int num14 = (int) typeCode2;
                  num1 = num13 + 4156479200U;
                  if (num14 != 0)
                  {
                    if (1820074287U > num1)
                    {
                      int num15 = (int) typeCode2;
                      int num16 = (int) num1 - 915030620;
                      uint num17 = num1 << 7;
                      if (num15 == num16)
                      {
                        num1 = num17 ^ 1940614365U;
                        goto label_10;
                      }
                      else
                      {
                        int num18 = (int) typeCode1;
                        int num19 = (int) num17 - 1159802486;
                        num10 = 1615402491U >> (int) num17;
                        if (num18 == num19)
                          num1 = num10 | 1096772715U;
                        else
                          goto label_16;
                      }
                    }
                    else
                      goto label_0;
                  }
                  else
                    goto label_10;
                }
                else
                  goto label_0;
              }
              else
                goto label_10;
            }
            while (151416185U > num1);
            if (typeCode2 != (TypeCode) ((int) num1 - 1633648114))
              return (TypeCode) ((int) num1 ^ 1633648123);
            uint num20 = 1245216298U ^ num1;
            return typeCode1;
label_16:
            uint num21 = 2086629501U - num10;
            if (((int) num21 ^ 45950290) != 0)
            {
              if (typeCode2 == (TypeCode) ((int) num21 ^ 471227016))
              {
                num1 = num21 + 100499252U;
                if ((int) num1 + 1568567683 != 0)
                {
                  if (typeCode1 != (TypeCode) ((int) num1 - 571726253))
                    return (TypeCode) ((int) num1 - 571726262);
                  continue;
                }
                goto label_0;
              }
              else if (1878006170U >= num21)
              {
                int num11 = (int) typeCode1;
                uint num12 = 1166032008U << (int) num21;
                int num13 = (int) num12 ^ 369160748;
                num2 = num12 >> 7;
                if (num11 != num13)
                {
                  if (typeCode2 != (TypeCode) ((int) num2 - 2884056))
                  {
                    if (typeCode1 != (TypeCode) ((int) num2 ^ 2884074))
                    {
                      uint num14 = 1956526741U & num2;
                      int num15 = (int) typeCode2;
                      num3 = 1552619901U & num14;
                      int num16 = (int) num3 - 524278;
                      if (num15 != num16)
                      {
                        uint num17 = num3 | 2119312672U;
                        int num18 = (int) typeCode1;
                        int num19 = (int) num17 - 2119836951;
                        num4 = num17 << 12;
                        if (num18 != num19)
                        {
                          num1 = 501185691U / num4;
                          if (num1 != 1804493258U)
                          {
                            if (typeCode2 != (TypeCode) ((int) num1 ^ 13))
                            {
                              if (1438344475U != num1)
                              {
                                if (typeCode1 != (TypeCode) ((int) num1 ^ 11))
                                {
                                  if (num1 <= 1241925333U)
                                    goto label_49;
                                }
                                else
                                  goto label_51;
                              }
                              else
                                goto label_1;
                            }
                            else
                              goto label_44;
                          }
                          else
                            continue;
                        }
                        else
                          goto label_45;
                      }
                      else
                        goto label_39;
                    }
                    else
                      goto label_40;
                  }
                  else
                    goto label_32;
                }
                else
                  goto label_25;
              }
              else
                goto label_0;
            }
            else
              goto label_0;
          }
          else
            goto label_1;
        }
label_10:
        return (TypeCode) ((int) num1 ^ 915030621);
      }
      while (num1 >= 1678574683U);
      return typeCode2;
label_25:
      uint num22 = 390427500U << (int) num2;
      if (num22 >= 584859222U)
      {
        int num9 = (int) typeCode2;
        int num10 = (int) num22 - 1951872695;
        uint num11 = 689113443U ^ num22;
        if (num9 != num10)
        {
          int num12 = (int) typeCode2;
          int num13 = (int) num11 - 1564753816;
          num11 = num11 * 758859650U + 3244603869U;
          if (num12 != num13)
            return (TypeCode) ((int) (num11 >> 13) - 191009);
        }
        if (364537325U != num11)
          return typeCode1;
        continue;
      }
      continue;
label_32:
      if (typeCode1 != (TypeCode) ((int) num2 ^ 2884077))
      {
        uint num9 = num2 ^ 626155975U;
        int num10 = (int) typeCode1;
        uint num11 = 1849257613U >> (int) num9;
        int num12 = (int) num11 ^ 231157210;
        num2 = 124781715U & num11 ^ 90965365U;
        if (num10 != num12)
          return (TypeCode) ((int) (num2 & 2080440475U) - 128);
      }
    }
    while (955714612U >> (int) (num2 + 1880715753U) == 0U);
    return typeCode1;
label_39:
    num2 = num3 + 2359776U;
label_40:
    return (TypeCode) ((int) (216820943U & num2) - 2883766);
label_44:
    num4 = num1 + 2723299328U;
label_45:
    return (TypeCode) ((int) (1111711253U | num4) ^ -497852904);
label_49:
    int num23 = (int) typeCode2;
    uint num24 = 1669484047U << (int) num1;
    int num25 = (int) num24 - 1669484036;
    uint num26 = 971645123U + num24;
    if (num23 != num25)
      return (TypeCode) ((int) (num26 & 288360567U) ^ 287311963);
    num1 = num26 ^ 2641129170U;
label_51:
    return (TypeCode) ((int) num1 + 11);
  }

  private unsafe \u0031C561093.\u00304BE210E \u0031F2E04EC(
    \u0031C561093.\u00304BE210E _param1,
    \u0031C561093.\u00304BE210E _param2,
    bool _param3,
    bool _param4)
  {
    uint num1 = 817907428;
    if (9961763U >= num1)
      goto label_7;
label_1:
    TypeCode typeCode;
    do
    {
      \u0031C561093.\u00304BE210E obj1 = _param1;
      \u0031C561093.\u00304BE210E obj2 = _param2;
      uint num2 = 1405109939U / num1;
      int num3 = (int) this.\u0030F7E56C3(obj1, obj2);
      uint num4 = num2 << 18;
      typeCode = (TypeCode) num3;
      num1 = 1155677273U + num4;
    }
    while (num1 < 674046276U);
label_2:
    uint num5;
    int num6;
    uint num7;
    \u0031C561093.\u00369D911C6 obj3;
    IntPtr num8;
    do
    {
      int num2;
      ulong num3;
      ulong num4;
      do
      {
        int num9;
        double num10;
        do
        {
          do
          {
            int num11 = (int) typeCode;
            uint num12 = num1 & 1756439117U;
            int num13 = (int) num12 ^ 1084235840;
            int num14 = num11 - num13;
            num1 = 1401043548U % num12;
            switch (num14)
            {
              case 0:
                if (2132438763 - (int) num1 != 0)
                {
                  if (_param4)
                  {
                    num1 >>= 9;
                    if (836662125U < num1)
                      goto label_1;
                    else
                      break;
                  }
                  else
                    goto label_12;
                }
                else
                  goto label_8;
              case 1:
                if (_param4)
                {
                  num1 = 1886344746U | num1;
                  if (((int) num1 ^ 1597601570) != 0)
                  {
                    uint num15 = _param1.\u00377124934();
                    if (num1 != 612124307U)
                    {
                      \u0031C561093.\u00304BE210E obj1 = _param2;
                      uint num16 = num1 & 781614565U;
                      int num17 = (int) obj1.\u00377124934();
                      uint num18 = 655180043U * num16;
                      uint num19 = (uint) num17;
                      uint num20 = num18 - 1616197957U;
                      int num21 = _param3 ? 1 : 0;
                      num1 = 1220555288U + num20;
                      uint num22;
                      int num23;
                      if (num21 == 0)
                      {
                        num22 = 830955101U << (int) num1;
                        num23 = (int) num15 + (int) num19;
                      }
                      else if ((662661384 ^ (int) num1) != 0)
                      {
                        int num24 = (int) num15;
                        int num25 = (int) num19;
                        uint num26 = 211251720U / num1;
                        num23 = (int) checked (unchecked ((uint) num24) + unchecked ((uint) num25));
                        num22 = num26 ^ 1073741824U;
                      }
                      else
                        goto label_1;
                      num1 = num22 * 1789749624U;
                      num2 = num23;
                      if (((int) num1 ^ 1613324189) == 0)
                        goto case 0;
                    }
                    else
                      goto label_1;
                  }
                  else
                    continue;
                }
                else if (num1 >> 15 != 0U)
                {
                  \u0031C561093.\u00304BE210E obj1 = _param1;
                  uint num15 = 278756368U ^ num1;
                  int num16 = obj1.E2D6F630();
                  uint num17 = num15 & 1152605976U;
                  int num18 = num16;
                  \u0031C561093.\u00304BE210E obj2 = _param2;
                  num1 = num17 + 581648733U;
                  int num19 = obj2.E2D6F630();
                  if (num1 != 1897661974U)
                  {
                    int num20 = _param3 ? 1 : 0;
                    num1 = 1451249251U << (int) num1;
                    int num21;
                    if (num20 == 0)
                    {
                      if ((148380990 & (int) num1) == 0)
                        num21 = num18 + num19;
                      else
                        goto label_115;
                    }
                    else
                    {
                      int num22 = num18;
                      int num23 = num19;
                      uint num24 = 1445403833U >> (int) num1;
                      num21 = checked (num22 + num23);
                      num1 = num24 + 165208903U;
                    }
                    uint num25 = 502862125U & num1;
                    num2 = num21;
                    num1 = num25 ^ 0U;
                  }
                  else
                    continue;
                }
                else
                  goto label_1;
                num1 = 1242638117U & num1;
                if (1825468839U == num1)
                  break;
                goto label_84;
              case 2:
                if (203368463U >> (int) num1 == 0U)
                  break;
                goto label_22;
              case 3:
                if (_param4)
                {
                  if (num1 != 940510743U)
                  {
                    num3 = _param1.\u00353FB65C3();
                    if (631120954U % num1 != 0U)
                    {
                      \u0031C561093.\u00304BE210E obj1 = _param2;
                      num1 *= 545084291U;
                      num4 = obj1.\u00353FB65C3();
                      if (474703262 << (int) num1 != 0)
                      {
                        if (!_param3)
                        {
                          if (((int) num1 ^ 560338166) == 0)
                            goto case 0;
                          else
                            goto label_95;
                        }
                        else
                          goto label_96;
                      }
                      else
                        goto label_1;
                    }
                    else
                      continue;
                  }
                  else
                    goto label_1;
                }
                else
                  goto label_99;
              case 4:
                goto label_39;
              case 5:
                uint num27 = num1 * 870329354U;
                int num28 = _param4 ? 1 : 0;
                uint num29 = 320553197U >> (int) num27;
                uint num30;
                \u0031C561093.\u00304BE210E obj4;
                if (num28 == 0)
                {
                  num30 = 302983957U & num29;
                  obj4 = _param1;
                }
                else
                {
                  num1 = 173292171U | num29;
                  if (919682643U >> (int) num1 != 0U)
                  {
                    \u0031C561093.\u00304BE210E obj1 = _param1;
                    uint num15 = num1 * 636290548U;
                    obj4 = obj1.\u0030323FE8D();
                    num30 = num15 ^ 3340469116U;
                  }
                  else
                    goto case 0;
                }
                double num31 = obj4.\u00383BC968D();
                uint num32 = 2015056349U >> (int) num30;
                num10 = num31;
                num1 = num32 % 1311387761U;
                if (_param4)
                {
                  if ((7808638 ^ (int) num1) == 0)
                    goto case 0;
                  else
                    goto label_62;
                }
                else
                  goto label_59;
              default:
                goto label_115;
            }
            int num33 = (int) _param1.\u00377124934();
            num1 = 1108241638U / num1;
            num5 = (uint) num33;
          }
          while (((int) num1 ^ 1867523633) == 0);
          goto label_7;
label_12:
          if ((959579190 & (int) num1) != 0)
          {
            int num11 = _param1.E2D6F630();
            num1 *= 1622097733U;
            num9 = num11;
          }
          else
            goto label_1;
        }
        while (1226728129 - (int) num1 == 0);
        \u0031C561093.\u00304BE210E obj5 = _param2;
        uint num34 = 174946284U % num1;
        int num35 = obj5.E2D6F630();
        uint num36 = 1604006506U | num34;
        int num37 = num35;
        int num38 = _param3 ? 1 : 0;
        uint num39 = 2098546507U / num36;
        uint num40;
        int num41;
        if (num38 == 0)
        {
          num1 = 1674059029U << (int) num39;
          if (num1 > 1861712047U)
          {
            int num11 = num9;
            num40 = 2137273962U >> (int) num1;
            int num12 = num37;
            num41 = num11 + num12;
          }
          else
            goto label_1;
        }
        else
        {
          int num11 = num9;
          uint num12 = 304699905U * num39;
          int num13 = num37;
          num41 = checked (num11 + num13);
          num40 = num12 + 3992354572U;
        }
        num6 = num41;
        num1 = num40 + 213788403U;
        goto label_19;
label_22:
        long num42;
        if (_param4)
        {
          num1 = 1446725205U << (int) num1;
          if ((int) num1 - 1927415589 != 0)
          {
            \u0031C561093.\u00304BE210E obj1 = _param1;
            num1 ^= 702481191U;
            ulong num11 = obj1.\u00353FB65C3();
            if (1889493651U > num1)
            {
              ulong num12 = _param2.\u00353FB65C3();
              num1 = 1516514710U % num1;
              if (num1 % 1896680455U != 0U)
              {
                int num13 = _param3 ? 1 : 0;
                uint num14 = num1 >> 28;
                uint num15;
                long num16;
                if (num13 == 0)
                {
                  num1 = num14 % 1512899477U;
                  if ((int) num1 << 12 == 0)
                  {
                    long num17 = (long) num11;
                    long num18 = (long) num12;
                    num15 = num1 >> 11;
                    num16 = num17 + num18;
                  }
                  else
                    goto label_1;
                }
                else
                {
                  uint num17 = num14 * 1569291874U;
                  num16 = (long) checked (num11 + num12);
                  num15 = num17 + 0U;
                }
                num1 = num15 * 1585801152U;
                num42 = num16;
                if (709893945 << (int) num1 == 0)
                  goto label_1;
              }
              else
                continue;
            }
            else
              goto label_1;
          }
          else
            goto label_1;
        }
        else if (((int) num1 ^ 2098618697) != 0)
        {
          long num11 = _param1.D500CE01();
          num1 = 498077715U | num1;
          if (80808064U != num1)
          {
            long num12 = _param2.D500CE01();
            uint num13 = 281550715U * num1;
            long num14 = num12;
            int num15 = _param3 ? 1 : 0;
            num1 = num13 & 368143630U;
            uint num16;
            long num17;
            if (num15 == 0)
            {
              if ((int) num1 - 669663650 != 0)
              {
                long num18 = num11;
                long num19 = num14;
                num16 = num1 % 2045659604U;
                num17 = num18 + num19;
              }
              else
                continue;
            }
            else
            {
              uint num18 = num1 & 1937380798U;
              long num19 = num11;
              uint num20 = num18 / 795815202U;
              long num21 = num14;
              uint num22 = 1852184488U << (int) num20;
              num17 = checked (num19 + num21);
              num16 = num22 + 2733255768U;
            }
            num42 = num17;
            num7 = num16 ^ 290472960U;
          }
          else
            continue;
        }
        else
          goto label_1;
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num42);
label_39:
        if ((1506823550 ^ (int) num1) != 0)
        {
          \u0031C561093.\u00304BE210E obj1;
          if (!_param4)
          {
            if (2098414159U != num1)
              obj1 = _param1;
            else
              continue;
          }
          else
          {
            obj1 = _param1.\u0030323FE8D();
            num1 ^= 0U;
          }
          float num11 = obj1.BA2939E9();
          int num12 = _param4 ? 1 : 0;
          uint num13 = 1781158312U ^ num1;
          \u0031C561093.\u00304BE210E obj2;
          if (num12 == 0)
          {
            num1 = 1474523226U % num13;
            if (num1 <= 1775130827U)
              obj2 = _param2;
            else
              goto label_1;
          }
          else
          {
            \u0031C561093.\u00304BE210E obj4 = _param2;
            uint num14 = 776213983U % num13;
            obj2 = obj4.\u0030323FE8D();
            num1 = num14 ^ 2041013637U;
          }
          float num15 = obj2.BA2939E9();
          if (num1 / 136846437U != 0U)
          {
            int num14 = _param3 ? 1 : 0;
            uint num16 = 633084978U & num1;
            double num17;
            if (num14 == 0)
            {
              num1 = num16 % 698878451U;
              if (2052534423 << (int) num1 != 0)
              {
                double num18 = (double) num11;
                uint num19 = 1321803110U & num1;
                double num20 = (double) num15;
                num7 = num19 % 1787304068U;
                num17 = num18 + num20;
              }
              else
                continue;
            }
            else
            {
              uint num18 = 659821729U & num16;
              double num19 = (double) num11;
              uint num20 = num18 + 1317349346U;
              double num21 = (double) num15;
              uint num22 = 712782563U << (int) num20;
              num17 = num19 + num21;
              num7 = num22 ^ 2909854606U;
            }
            return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00341173E9D((float) num17);
          }
          goto label_1;
        }
        else
          goto label_1;
label_59:
        num1 = 1945787006U | num1;
        \u0031C561093.\u00304BE210E obj6;
        if (1644565736U < num1)
        {
          obj6 = _param2;
          goto label_63;
        }
        else
          continue;
label_62:
        obj6 = _param2.\u0030323FE8D();
        num1 ^= 1376410130U;
label_63:
        double num43 = obj6.\u00383BC968D();
        uint num44 = num1 & 297732910U;
        double num45 = num43;
        uint num46 = 1851727791U & num44;
        double num47;
        if (!_param3)
        {
          double num11 = num10;
          num7 = 398476272U >> (int) num46;
          double num12 = num45;
          num47 = num11 + num12;
        }
        else
        {
          num1 = num46 - 1965970639U;
          if (((int) num1 & 600266708) != 0)
          {
            num47 = num10 + num45;
            num7 = num1 ^ 2330782046U;
          }
          else
            goto label_1;
        }
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(num47);
label_84:
        \u0031C561093.\u00304BE210E obj7 = _param1;
        uint num48 = num1 * 496979454U;
        int num49 = (int) obj7.\u003363C3519();
        num1 = num48 >> 6;
        int num50 = (int) typeCode;
        if (num49 == num50)
          goto label_87;
      }
      while (531713236U < num1);
      \u0031C561093.\u00369D911C6 obj8 = (\u0031C561093.\u00369D911C6) _param2;
      goto label_88;
label_87:
      uint num51 = 787771535U + num1;
      \u0031C561093.\u00304BE210E obj9 = _param1;
      uint num52 = 542590445U / num51;
      obj8 = (\u0031C561093.\u00369D911C6) obj9;
      num1 = num52 + 0U;
label_88:
      \u0031C561093.\u00369D911C6 obj10 = obj8;
      void* pointer = new IntPtr(num2).ToPointer();
      \u0031C561093.\u00369D911C6 obj11 = obj10;
      uint num53 = num1 - 1893601222U;
      Type type1 = obj11.\u0030452B850();
      uint num54 = num53 - 580026087U;
      object obj12 = Pointer.Box(pointer, type1);
      uint num55 = num54 / 698034667U;
      \u0031C561093.\u00369D911C6 obj13 = obj10;
      uint num56 = num55 * 1386569042U;
      Type type2 = obj13.\u0030452B850();
      num7 = num56 >> 16;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00369D911C6(obj12, type2);
label_95:
      long num57 = (long) num3;
      uint num58 = 2054122870U - num1;
      long num59 = (long) num4;
      num1 = 1291066008U ^ num58;
      long num60 = num57 + num59;
      goto label_98;
label_96:
      if (1781798026U != num1)
      {
        num60 = (long) checked (num3 + num4);
        num1 ^= 949647004U;
      }
      else
        goto label_1;
label_98:
      long num61 = num60;
      if (num1 == 705721382U)
        goto label_1;
      else
        goto label_108;
label_99:
      if (1291457576U != num1)
      {
        long num9 = _param1.D500CE01();
        if (((int) num1 ^ 1213870599) != 0)
        {
          long num10 = _param2.D500CE01();
          uint num11 = num1 / 1785011638U;
          long num12 = num10;
          num1 = num11 / 1999897453U;
          if ((1690853911 ^ (int) num1) != 0)
          {
            int num13 = _param3 ? 1 : 0;
            num1 = 1237790218U | num1;
            long num14;
            if (num13 == 0)
            {
              if (1688217472 << (int) num1 != 0)
                num14 = num9 + num12;
              else
                goto label_1;
            }
            else
            {
              num1 = 847723762U - num1;
              if ((int) num1 + 893615573 != 0)
              {
                long num15 = num9;
                long num16 = num12;
                uint num17 = num1 | 1240688528U;
                num14 = checked (num15 + num16);
                num1 = num17 ^ 2687779314U;
              }
              else
                goto label_1;
            }
            uint num18 = 307169029U >> (int) num1;
            num61 = num14;
            num1 = num18 ^ 737175012U;
          }
          else
            goto label_1;
        }
        else
          goto label_1;
      }
      else
        goto label_115;
label_108:
      uint num62;
      \u0031C561093.\u00369D911C6 obj14;
      if (_param1.\u003363C3519() != typeCode)
      {
        uint num9 = 390742783U ^ num1;
        \u0031C561093.\u00304BE210E obj1 = _param2;
        num62 = 1513427044U * num9;
        obj14 = (\u0031C561093.\u00369D911C6) obj1;
      }
      else
      {
        num1 = 121983016U - num1;
        if (num1 >= 802688127U)
        {
          \u0031C561093.\u00304BE210E obj1 = _param1;
          uint num9 = 1819505690U >> (int) num1;
          obj14 = (\u0031C561093.\u00369D911C6) obj1;
          num62 = num9 + 2908739237U;
        }
        else
          continue;
      }
      uint num63 = 1124868655U & num62;
      obj3 = obj14;
      num1 = num63 ^ 524098881U;
      if (560486443U >= num1)
      {
        IntPtr num9 = new IntPtr(num61);
        num1 ^= 2102537291U;
        num8 = num9;
      }
      else
        goto label_1;
    }
    while (num1 <= 1111517931U);
    ref IntPtr local = ref num8;
    uint num64 = num1 << 20;
    void* pointer1 = local.ToPointer();
    \u0031C561093.\u00369D911C6 obj15 = obj3;
    uint num65 = 2045408300U ^ num64;
    Type type3 = obj15.\u0030452B850();
    object obj16 = Pointer.Box(pointer1, type3);
    Type type4 = obj3.\u0030452B850();
    num7 = num65 * 854794580U;
    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00369D911C6(obj16, type4);
label_115:
    num1 /= 1299480002U;
    if ((int) num1 << 8 == 0)
      throw new InvalidOperationException();
    goto label_1;
label_7:
    \u0031C561093.\u00304BE210E obj17 = _param2;
    uint num66 = 33693892U & num1;
    uint num67 = obj17.\u00377124934();
    num1 = 77167567U % num66;
label_8:
    int num68 = _param3 ? 1 : 0;
    uint num69 = num1 ^ 860444320U;
    uint num70;
    int num71;
    if (num68 == 0)
    {
      num70 = num69 << 16;
      num71 = (int) num5 + (int) num67;
    }
    else
    {
      uint num2 = num69 | 1806513652U;
      num71 = (int) checked (num5 + num67);
      num70 = num2 ^ 759330815U;
    }
    num1 = 1282832514U * num70;
    num6 = num71;
label_19:
    if (563167276U > num1)
    {
      int num2 = num6;
      num7 = num1 - 1437545475U;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num2);
    }
    goto label_2;
  }

  private unsafe \u0031C561093.\u00304BE210E \u00309A340DE(
    \u0031C561093.\u00304BE210E _param1,
    \u0031C561093.\u00304BE210E _param2,
    bool _param3,
    bool _param4)
  {
label_0:
    uint num1;
    \u0031C561093.\u00369D911C6 obj1;
    IntPtr num2;
    uint num3;
    do
    {
      TypeCode typeCode;
      uint num4;
      uint num5;
      uint num6;
      int num7;
      uint num8;
      int num9;
      int num10;
      long num11;
      uint num12;
      double num13;
      \u0031C561093.\u00369D911C6 obj2;
      IntPtr num14;
      ulong num15;
      do
      {
        do
        {
          uint num16 = 1008411427;
          \u0031C561093.\u00304BE210E obj3 = _param1;
          uint num17 = 155404216U % num16;
          \u0031C561093.\u00304BE210E obj4 = _param2;
          int num18 = (int) this.\u0030F7E56C3(obj3, obj4);
          uint num19 = 1800159713U >> (int) num17;
          typeCode = (TypeCode) num18;
          num4 = 810777042U >> (int) num19;
label_1:
          uint num20;
          uint num21;
          uint num22;
          long num23;
          long num24;
          int num25;
          int num26;
          do
          {
            int num27 = (int) typeCode;
            int num28 = (int) num4 - 395878;
            uint num29 = 1753229591U ^ num4;
            int num30 = num27 - num28;
            num4 = 88687992U | num29;
            switch (num30)
            {
              case 0:
                num4 = 1323907170U << (int) num4;
                if (num4 != 998315272U)
                {
                  if (_param4)
                  {
                    num5 = num4 - 800488525U;
                    if (199102562U > num5)
                      goto label_0;
                    else
                      break;
                  }
                  else
                    goto label_12;
                }
                else
                  continue;
              case 1:
                num4 -= 2146108446U;
                if (1801983673U % num4 != 0U)
                {
                  uint num31;
                  if (_param4)
                  {
                    if ((2041473920 & (int) num4) != 0)
                    {
                      \u0031C561093.\u00304BE210E obj5 = _param1;
                      uint num32 = num4 * 158680104U;
                      int num33 = (int) obj5.\u00377124934();
                      uint num34 = num32 & 1034439361U;
                      uint num35 = (uint) num33;
                      int num36 = (int) _param2.\u00377124934();
                      uint num37 = num34 << 31;
                      uint num38 = (uint) num36;
                      if (473047504 + (int) num37 != 0)
                      {
                        int num39 = _param3 ? 1 : 0;
                        uint num40 = 1615935480U - num37;
                        int num41;
                        if (num39 == 0)
                        {
                          num41 = (int) num35 - (int) num38;
                        }
                        else
                        {
                          num41 = (int) checked (num35 - num38);
                          num40 += 0U;
                        }
                        num31 = num40 & 1539118602U;
                        num25 = num41;
                        if ((1419253426 & (int) num31) == 0)
                          goto label_0;
                      }
                      else
                        goto label_0;
                    }
                    else
                      goto label_111;
                  }
                  else
                  {
                    uint num32 = 348717426U ^ num4;
                    \u0031C561093.\u00304BE210E obj5 = _param1;
                    uint num33 = num32 & 1668304791U;
                    int num34 = obj5.E2D6F630();
                    uint num35 = num33 * 1847603590U;
                    int num36 = num34;
                    if (492517241U != num35)
                    {
                      \u0031C561093.\u00304BE210E obj6 = _param2;
                      uint num37 = 1131873532U / num35;
                      int num38 = obj6.E2D6F630();
                      uint num39 = 156520416U ^ num37;
                      int num40 = num38;
                      int num41 = _param3 ? 1 : 0;
                      uint num42 = num39 % 55574530U;
                      uint num43;
                      int num44;
                      if (num41 == 0)
                      {
                        int num45 = num36;
                        int num46 = num40;
                        num43 = num42 % 1534592442U;
                        num44 = num45 - num46;
                      }
                      else
                      {
                        uint num45 = 526997478U - num42;
                        num44 = checked (num36 - num40);
                        num43 = num45 ^ 503400406U;
                      }
                      uint num47 = num43 >> 3;
                      num25 = num44;
                      num31 = num47 ^ 1078435827U;
                    }
                    else
                      goto label_0;
                  }
                  uint num48 = 1016019171U << (int) num31;
                  if (num48 > 1231045086U)
                  {
                    int num32 = (int) _param1.\u003363C3519();
                    int num33 = (int) typeCode;
                    num4 = 765340821U << (int) num48;
                    if (num32 == num33)
                    {
                      if (2127197770U <= num4)
                        goto case 0;
                      else
                        goto label_86;
                    }
                    else
                      goto label_83;
                  }
                  else
                    goto label_0;
                }
                else
                  continue;
              case 2:
                int num49 = _param4 ? 1 : 0;
                num22 = num4 & 1650681538U;
                if (num49 == 0)
                {
                  uint num31 = 1190024604U >> (int) num22;
                  if (613570004 * (int) num31 != 0)
                  {
                    \u0031C561093.\u00304BE210E obj5 = _param1;
                    uint num32 = 1441878490U % num31;
                    long num33 = obj5.D500CE01();
                    uint num34 = num32 >> 6;
                    num23 = num33;
                    num4 = num34 * 1685925735U;
                    if (1479674638U < num4)
                    {
                      num24 = _param2.D500CE01();
                      if (599017672U < num4)
                      {
                        if (_param3)
                        {
                          if ((1476667222 ^ (int) num4) == 0)
                            goto case 0;
                          else
                            goto label_35;
                        }
                        else
                          goto label_32;
                      }
                      else
                        goto label_0;
                    }
                    else
                      continue;
                  }
                  else
                    goto label_0;
                }
                else
                  goto label_21;
              case 3:
                if (_param4)
                {
                  uint num31 = 501425077U ^ num4;
                  \u0031C561093.\u00304BE210E obj5 = _param1;
                  uint num32 = 395724222U | num31;
                  long num33 = (long) obj5.\u00353FB65C3();
                  uint num34 = 1338451857U + num32;
                  num15 = (ulong) num33;
                  num4 = num34 << 1;
                  if (num4 >> 13 == 0U)
                    goto case 0;
                  else
                    goto label_92;
                }
                else
                  goto label_97;
              case 4:
                uint num50 = num4 ^ 1508992025U;
                int num51 = _param4 ? 1 : 0;
                num12 = 128853404U % num50;
                if (num51 == 0)
                {
                  num4 = 411258908U << (int) num12;
                  if (1748922315 * (int) num4 == 0)
                    goto case 0;
                  else
                    goto label_41;
                }
                else
                  goto label_42;
              case 5:
                uint num52 = 689401835U / num4;
                int num53 = _param4 ? 1 : 0;
                uint num54 = 862024066U & num52;
                \u0031C561093.\u00304BE210E obj7;
                if (num53 == 0)
                {
                  num4 = num54 % 1912813225U;
                  if (num4 / 839931176U == 0U)
                    obj7 = _param1;
                  else
                    continue;
                }
                else
                {
                  uint num31 = num54 << 24;
                  if (454653597 << (int) num31 != 0)
                  {
                    obj7 = _param1.\u0030323FE8D();
                    num4 = num31 + 0U;
                  }
                  else
                    goto label_0;
                }
                double num55 = obj7.\u00383BC968D();
                uint num56 = num4 << 1;
                num13 = num55;
                int num57 = _param4 ? 1 : 0;
                num5 = num56 - 838403862U;
                if (num57 == 0)
                {
                  if (1253385659 + (int) num5 == 0)
                    break;
                  goto label_59;
                }
                else
                  goto label_60;
              default:
                goto label_111;
            }
            \u0031C561093.\u00304BE210E obj8 = _param1;
            uint num58 = 2057265568U | num5;
            num20 = obj8.\u00377124934();
            int num59 = (int) _param2.\u00377124934();
            num4 = 534271770U + num58;
            num21 = (uint) num59;
            if (61308181U != num4)
            {
              if (!_param3)
              {
                num4 %= 262931638U;
                if (((int) num4 ^ 329123302) != 0)
                {
                  num26 = (int) num20 - (int) num21;
                  goto label_11;
                }
              }
            }
            else
              goto label_0;
          }
          while (((int) num4 ^ 1470572558) == 0);
          int num60 = (int) num20;
          uint num61 = num4 / 955670546U;
          int num62 = (int) num21;
          uint num63 = num61 % 2062839413U;
          num26 = (int) checked (unchecked ((uint) num60) - unchecked ((uint) num62));
          num4 = num63 + 229380197U;
label_11:
          num6 = num4 / 319778755U;
          num7 = num26;
          goto label_19;
label_12:
          continue;
label_21:
          uint num64;
          if (num22 != 932970632U)
          {
            \u0031C561093.\u00304BE210E obj5 = _param1;
            uint num27 = 625701533U % num22;
            long num28 = (long) obj5.\u00353FB65C3();
            uint num29 = num27 >> 26;
            ulong num30 = (ulong) num28;
            uint num31 = 760815050U * num29;
            if (991839062U <= num31)
            {
              \u0031C561093.\u00304BE210E obj6 = _param2;
              uint num32 = num31 / 1051226799U;
              ulong num33 = obj6.\u00353FB65C3();
              int num34 = _param3 ? 1 : 0;
              uint num35 = num32 & 2002475347U;
              uint num36;
              long num37;
              if (num34 == 0)
              {
                uint num38 = num35 * 556691322U;
                if (((int) num38 & 75453533) != 0)
                {
                  long num39 = (long) num30;
                  uint num40 = 379136075U ^ num38;
                  long num41 = (long) num33;
                  num36 = num40 ^ 2061960194U;
                  num37 = num39 - num41;
                }
                else
                  continue;
              }
              else
              {
                uint num38 = 550726678U - num35;
                num37 = (long) checked (num30 - num33);
                num36 = num38 ^ 250715817U;
              }
              num64 = 410407705U >> (int) num36;
              num11 = num37;
              if (num64 > 1593595552U)
                goto label_111;
              else
                goto label_37;
            }
            else
              continue;
          }
          else
            continue;
label_32:
          uint num65 = num4 * 115744756U;
          uint num66;
          long num67;
          if (((int) num65 ^ 146015064) != 0)
          {
            long num27 = num23;
            num66 = 426445890U - num65;
            long num28 = num24;
            num67 = num27 - num28;
            goto label_36;
          }
          else
            goto label_111;
label_35:
          long num68 = num23;
          uint num69 = num4 * 596803319U;
          long num70 = num24;
          num67 = checked (num68 - num70);
          num66 = num69 + 2728249618U;
label_36:
          uint num71 = num66 | 1902467406U;
          num11 = num67;
          num64 = num71 + 34635954U;
label_37:
          num4 = num64 >> 20;
          if ((1101816897 & (int) num4) != 0)
            goto label_1;
          else
            goto label_38;
label_83:
          uint num72 = 1577005673U & num4;
          \u0031C561093.\u00369D911C6 obj9;
          if ((1626082813 ^ (int) num72) != 0)
          {
            obj9 = (\u0031C561093.\u00369D911C6) _param2;
            goto label_87;
          }
          else
            continue;
label_86:
          obj9 = (\u0031C561093.\u00369D911C6) _param1;
          num72 = num4 + 3758093164U;
label_87:
          uint num73 = num72 % 2076926428U;
          obj2 = obj9;
          num4 = 282731350U >> (int) num73;
          if ((int) num4 << 24 != 0)
          {
            num14 = new IntPtr(num25);
            if ((int) num4 << 10 == 0)
              goto label_1;
            else
              goto label_89;
          }
          else
            goto label_1;
        }
        while ((471484400 & (int) num4) != 0);
        int num74 = _param1.E2D6F630();
        num8 = 2089617798U & num4;
        num9 = num74;
        num10 = _param2.E2D6F630();
      }
      while (((int) num8 & 1928550148) == 0);
      uint num75;
      int num76;
      if (!_param3)
      {
        uint num16 = num8 % 763562715U;
        int num17 = num9;
        uint num18 = num16 / 1373779257U;
        int num19 = num10;
        num75 = 541680995U * num18;
        num76 = num17 - num19;
      }
      else
      {
        uint num16 = num8 << 16;
        if (((int) num16 ^ 1594186604) != 0)
        {
          num76 = checked (num9 - num10);
          num75 = num16 ^ 0U;
        }
        else
          goto label_111;
      }
      num7 = num76;
      num6 = num75 + 0U;
label_19:
      uint num77 = 458106239U << (int) num6;
      int num78 = num7;
      num1 = 491748506U >> (int) num77;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num78);
label_38:
      long num79 = num11;
      num1 = num4 << 27;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num79);
label_41:
      \u0031C561093.\u00304BE210E obj10 = _param1;
      goto label_44;
label_42:
      uint num80 = 2061069254U ^ num12;
      if (((int) num80 ^ 2087139132) != 0)
      {
        \u0031C561093.\u00304BE210E obj3 = _param1;
        uint num16 = 168126861U * num80;
        obj10 = obj3.\u0030323FE8D();
        num4 = num16 + 2858741358U;
      }
      else
        continue;
label_44:
      float num81 = obj10.BA2939E9();
      uint num82 = num4 % 2066178494U;
      if (num82 != 292557246U)
      {
        int num16 = _param4 ? 1 : 0;
        uint num17 = num82 % 333538822U;
        \u0031C561093.\u00304BE210E obj3;
        if (num16 == 0)
        {
          obj3 = _param2;
        }
        else
        {
          \u0031C561093.\u00304BE210E obj4 = _param2;
          uint num18 = num17 >> 0;
          obj3 = obj4.\u0030323FE8D();
          num17 = num18 + 0U;
        }
        uint num19 = num17 >> 6;
        double num20 = (double) obj3.BA2939E9();
        uint num21 = 174852367U << (int) num19;
        float num22 = (float) num20;
        uint num23 = num21 + 809336268U;
        int num24 = _param3 ? 1 : 0;
        uint num25 = 2118870373U | num23;
        uint num26;
        double num27;
        if (num24 == 0)
        {
          uint num18 = 438927265U / num25;
          double num28 = (double) num81;
          uint num29 = 1037967087U - num18;
          double num30 = (double) num22;
          num26 = num29 % 1415729888U;
          num27 = num28 - num30;
        }
        else
        {
          uint num18 = num25 * 1358569374U;
          double num28 = (double) num81;
          double num29 = (double) num22;
          uint num30 = num18 & 1980522870U;
          num27 = num28 - num29;
          num26 = num30 ^ 165576617U;
        }
        num1 = num26 << 31;
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00341173E9D((float) num27);
      }
      continue;
label_59:
      \u0031C561093.\u00304BE210E obj11 = _param2;
      goto label_61;
label_60:
      obj11 = _param2.\u0030323FE8D();
      num5 ^= 0U;
label_61:
      double num83 = obj11.\u00383BC968D();
      uint num84 = 733887923U % num5;
      double num85 = num83;
      uint num86 = 293362968U & num84;
      if (num86 / 1939892842U == 0U)
      {
        double num16;
        if (!_param3)
        {
          if (num86 != 73794256U)
            num16 = num13 - num85;
          else
            continue;
        }
        else if (2005999111U > num86)
        {
          double num17 = num13;
          uint num18 = num86 / 1039160274U;
          double num19 = num85;
          num16 = num17 - num19;
          num1 = num18 + 20716816U;
        }
        else
          goto label_111;
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(num16);
      }
      goto label_111;
label_89:
      void* pointer = num14.ToPointer();
      \u0031C561093.\u00369D911C6 obj12 = obj2;
      uint num87 = num4 >> 7;
      Type type1 = obj12.\u0030452B850();
      uint num88 = num87 & 1374903545U;
      object obj13 = Pointer.Box(pointer, type1);
      Type type2 = obj2.\u0030452B850();
      num1 = 876890648U << (int) num88;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00369D911C6(obj13, type2);
label_92:
      \u0031C561093.\u00304BE210E obj14 = _param2;
      uint num89 = num4 >> 4;
      ulong num90 = obj14.\u00353FB65C3();
      int num91 = _param3 ? 1 : 0;
      uint num92 = 323255468U << (int) num89;
      uint num93;
      long num94;
      if (num91 == 0)
      {
        if (((int) num92 ^ 261816741) != 0)
        {
          long num16 = (long) num15;
          long num17 = (long) num90;
          num93 = 1579754293U / num92;
          num94 = num16 - num17;
        }
        else
          continue;
      }
      else
      {
        uint num16 = num92 + 272245592U;
        long num17 = (long) num15;
        uint num18 = 341528734U ^ num16;
        long num19 = (long) num90;
        num94 = (long) checked (unchecked ((ulong) num17) - unchecked ((ulong) num19));
        num93 = num18 + 3914239034U;
      }
      uint num95 = 1550867488U | num93;
      long num96 = num94;
      if (1391028396 << (int) num95 == 0)
        goto label_111;
      else
        goto label_105;
label_97:
      if (1948537596U > num4)
      {
        long num16 = _param1.D500CE01();
        long num17 = _param2.D500CE01();
        if ((635326876 ^ (int) num4) != 0)
        {
          int num18 = _param3 ? 1 : 0;
          uint num19 = 450312708U + num4;
          uint num20;
          long num21;
          if (num18 == 0)
          {
            uint num22 = num19 - 1769423255U;
            if (num22 / 1875779402U == 0U)
            {
              long num23 = num16;
              num20 = 421162273U << (int) num22;
              long num24 = num17;
              num21 = num23 - num24;
            }
            else
              continue;
          }
          else if (342323010U <= num19)
          {
            num21 = checked (num16 - num17);
            num20 = num19 ^ 2884306268U;
          }
          else
            continue;
          uint num25 = 659757175U >> (int) num20;
          num96 = num21;
          num95 = num25 ^ 2065908823U;
        }
        else
          goto label_111;
      }
      else
        goto label_111;
label_105:
      uint num97;
      \u0031C561093.\u00369D911C6 obj15;
      if (_param1.\u003363C3519() != typeCode)
      {
        num97 = 1744970012U / num95;
        obj15 = (\u0031C561093.\u00369D911C6) _param2;
      }
      else
      {
        uint num16 = 1851860039U >> (int) num95;
        if (1346765906 + (int) num16 != 0)
        {
          obj15 = (\u0031C561093.\u00369D911C6) _param1;
          num97 = num16 + 2443107258U;
        }
        else
          continue;
      }
      uint num98 = num97 >> 31;
      obj1 = obj15;
      long num99 = num96;
      uint num100 = num98 | 257326926U;
      IntPtr num101 = new IntPtr(num99);
      uint num102 = num100 * 755265858U;
      num2 = num101;
      num3 = 2037281129U * num102;
    }
    while (291662805U > num3);
    void* pointer1 = num2.ToPointer();
    \u0031C561093.\u00369D911C6 obj16 = obj1;
    uint num103 = num3 - 1064462868U;
    Type type3 = obj16.\u0030452B850();
    object obj17 = Pointer.Box(pointer1, type3);
    uint num104 = 1451581191U - num103;
    Type type4 = obj1.\u0030452B850();
    num1 = 204871978U | num104;
    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00369D911C6(obj17, type4);
label_111:
    throw new InvalidOperationException();
  }

  private \u0031C561093.\u00304BE210E \u003557C0962(
    \u0031C561093.\u00304BE210E _param1,
    \u0031C561093.\u00304BE210E _param2,
    bool _param3,
    bool _param4)
  {
    uint num1 = 1478691224;
label_1:
    uint num2;
    double num3;
    do
    {
      float num4;
      float num5;
      uint num6;
      double num7;
      do
      {
        long num8;
        long num9;
        long num10;
        uint num11;
        long num12;
        do
        {
          TypeCode typeCode;
          do
          {
            uint num13 = 380140214U / num1;
            \u0031C561093.\u00304BE210E obj1 = _param1;
            \u0031C561093.\u00304BE210E obj2 = _param2;
            uint num14 = 378081964U >> (int) num13;
            int num15 = (int) this.\u0030F7E56C3(obj1, obj2);
            uint num16 = num14 - 156119173U;
            typeCode = (TypeCode) num15;
            num1 = 1186210686U & num16;
          }
          while (((int) num1 ^ 776754024) == 0);
          do
          {
            uint num13;
            int num14;
            int num15;
            int num16;
            uint num17;
            ulong num18;
            ulong num19;
            do
            {
              do
              {
                int num20 = (int) typeCode;
                int num21 = (int) num1 ^ 70263343;
                uint num22 = 719810688U | num1;
                int num23 = num20 - num21;
                num1 = 267720747U & num22;
                switch (num23)
                {
                  case 0:
                    num1 = 1338846520U | num1;
                    continue;
                  case 1:
                  case 3:
                    goto label_66;
                  case 2:
                    num1 /= 2031371445U;
                    if (794042545U != num1)
                    {
                      int num24 = _param4 ? 1 : 0;
                      num17 = num1 >> 19;
                      if (num24 != 0)
                      {
                        \u0031C561093.\u00304BE210E obj1 = _param1;
                        uint num25 = num17 << 20;
                        long num26 = (long) obj1.\u00353FB65C3();
                        uint num27 = num25 + 1342405825U;
                        num18 = (ulong) num26;
                        if ((1198210192 ^ (int) num27) != 0)
                        {
                          \u0031C561093.\u00304BE210E obj2 = _param2;
                          num1 = 197945254U + num27;
                          num19 = obj2.\u00353FB65C3();
                          if (1774530568U != num1)
                          {
                            if (!_param3)
                            {
                              if (2143701928U == num1)
                                goto case 0;
                              else
                                goto label_25;
                            }
                            else
                              goto label_26;
                          }
                          else
                            goto case 0;
                        }
                        else
                          goto label_66;
                      }
                      else
                        goto label_28;
                    }
                    else
                      continue;
                  case 4:
                    uint num28 = 1754283491U ^ num1;
                    int num29 = _param4 ? 1 : 0;
                    uint num30 = 1024206510U & num28;
                    uint num31;
                    \u0031C561093.\u00304BE210E obj3;
                    if (num29 == 0)
                    {
                      num31 = num30 * 1010135509U;
                      obj3 = _param1;
                    }
                    else
                    {
                      \u0031C561093.\u00304BE210E obj1 = _param1;
                      uint num24 = 309072603U ^ num30;
                      obj3 = obj1.\u0030323FE8D();
                      num31 = num24 + 598124581U;
                    }
                    num4 = obj3.BA2939E9();
                    uint num32 = num31 << 30;
                    uint num33;
                    \u0031C561093.\u00304BE210E obj4;
                    if (!_param4)
                    {
                      num33 = 1297446264U << (int) num32;
                      if (2146202455U > num33)
                        obj4 = _param2;
                      else
                        goto label_66;
                    }
                    else
                    {
                      uint num24 = num32 + 1865100794U;
                      \u0031C561093.\u00304BE210E obj1 = _param2;
                      uint num25 = num24 * 387459945U;
                      obj4 = obj1.\u0030323FE8D();
                      num33 = num25 + 2927008750U;
                    }
                    double num34 = (double) obj4.BA2939E9();
                    uint num35 = 1307927335U & num33;
                    num5 = (float) num34;
                    num1 = num35 / 499340083U;
                    if (1854353945U % num1 != 0U)
                    {
                      if (!_param3)
                      {
                        if (1201998188 * (int) num1 == 0)
                          goto case 0;
                        else
                          goto label_47;
                      }
                      else
                        goto label_48;
                    }
                    else
                      continue;
                  case 5:
                    goto label_51;
                  default:
                    num2 = num1 + 0U;
                    goto label_66;
                }
              }
              while (((int) num1 ^ 342376974) == 0);
              if (_param4)
              {
                uint num20 = num1 >> 28;
                \u0031C561093.\u00304BE210E obj = _param1;
                uint num21 = 445069242U ^ num20;
                uint num22 = obj.\u00377124934();
                uint num23 = 182481910U & num21;
                uint num24 = _param2.\u00377124934();
                num1 = num23 ^ 1019707133U;
                if (((int) num1 ^ 2034314480) != 0)
                {
                  int num25 = _param3 ? 1 : 0;
                  uint num26 = 2069843315U >> (int) num1;
                  int num27;
                  if (num25 == 0)
                  {
                    int num28 = (int) num22;
                    uint num29 = 665260988U << (int) num26;
                    int num30 = (int) num24;
                    num13 = num29 + 1888881495U;
                    num27 = num28 * num30;
                  }
                  else
                  {
                    uint num28 = 1377634652U - num26;
                    int num29 = (int) num22;
                    uint num30 = 1482514961U * num28;
                    int num31 = (int) num24;
                    num27 = (int) checked (unchecked ((uint) num29) * unchecked ((uint) num31));
                    num13 = num30 ^ 3712612852U;
                  }
                  num14 = num27;
                  goto label_18;
                }
                else
                  goto label_1;
              }
              else if (640424958U < num1)
              {
                \u0031C561093.\u00304BE210E obj1 = _param1;
                uint num20 = 1612278621U << (int) num1;
                int num21 = obj1.E2D6F630();
                uint num22 = num20 + 664430860U;
                num15 = num21;
                \u0031C561093.\u00304BE210E obj2 = _param2;
                uint num23 = num22 ^ 787242436U;
                num16 = obj2.E2D6F630();
                uint num24 = 1557073122U / num23;
                int num25 = _param3 ? 1 : 0;
                num1 = 957487790U << (int) num24;
                if (num25 != 0)
                  goto label_15;
              }
              else
                goto label_1;
            }
            while (1176721289 + (int) num1 == 0);
            int num36 = num15;
            uint num37 = num1 << 8;
            int num38 = num16;
            int num39 = num36 * num38;
            goto label_17;
label_15:
            if (1473395205U != num1)
            {
              num39 = checked (num15 * num16);
              num37 = num1 + 3641217874U;
            }
            else
              goto label_66;
label_17:
            num14 = num39;
            num13 = num37 ^ 2896637271U;
label_18:
            num2 = num13 | 1262967134U;
            return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num14);
label_25:
            long num40 = (long) num18;
            uint num41 = 49441782U % num1;
            long num42 = (long) num19;
            num2 = 1624652374U * num41;
            long num43 = num40 * num42;
            goto label_27;
label_26:
            uint num44 = 1392588398U << (int) num1;
            num43 = (long) checked (num18 * num19);
            num2 = num44 ^ 3910219684U;
label_27:
            num8 = num43;
            goto label_36;
label_28:
            num1 = 1346661240U ^ num17;
            if (num1 != 2087458252U)
            {
              long num20 = _param1.D500CE01();
              uint num21 = 1886937934U / num1;
              num9 = num20;
              uint num22 = 1426588674U | num21;
              \u0031C561093.\u00304BE210E obj = _param2;
              uint num23 = num22 << 4;
              long num24 = obj.D500CE01();
              uint num25 = num23 ^ 634484636U;
              num10 = num24;
              num1 = num25 - 1148348487U;
              if ((516573748 & (int) num1) != 0)
              {
                if (_param3)
                  goto label_33;
              }
              else
                goto label_1;
            }
            else
              goto label_1;
          }
          while (((int) num1 & 1497117548) == 0);
          long num45 = num9;
          num11 = 1451688572U & num1;
          long num46 = num10;
          num12 = num45 * num46;
          goto label_35;
label_33:
          num1 >>= 3;
        }
        while (num1 >= 216096267U);
        long num47 = num9;
        uint num48 = 282536741U * num1;
        long num49 = num10;
        uint num50 = num48 ^ 1913929031U;
        num12 = checked (num47 * num49);
        num11 = num50 ^ 910629951U;
label_35:
        uint num51 = 533161528U >> (int) num11;
        num8 = num12;
        num2 = num51 + 1737329217U;
label_36:
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num8);
label_47:
        double num52 = (double) num4;
        num6 = 1371019758U & num1;
        double num53 = (double) num5;
        num7 = num52 * num53;
        goto label_50;
label_48:;
      }
      while (752489486U <= num1);
      double num54 = (double) num4;
      uint num55 = num1 * 2117681320U;
      double num56 = (double) num5;
      num7 = num54 * num56;
      num6 = num55 + 59604658U;
label_50:
      num2 = 679349643U % num6;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(num7);
label_51:
      uint num57 = num1 >> 10;
      \u0031C561093.\u00304BE210E obj5;
      if (!_param4)
      {
        num1 = num57 | 872558268U;
        if (837950549U >> (int) num1 != 0U)
          obj5 = _param1;
        else
          continue;
      }
      else
      {
        num1 = num57 / 628248528U;
        if (num1 < 1418528655U)
        {
          obj5 = _param1.\u0030323FE8D();
          num1 ^= 872660988U;
        }
        else
          continue;
      }
      num3 = obj5.\u00383BC968D();
      num1 *= 1870608403U;
    }
    while (514725840U > num1);
    int num58 = _param4 ? 1 : 0;
    uint num59 = num1 & 785275766U;
    uint num60;
    \u0031C561093.\u00304BE210E obj6;
    if (num58 == 0)
    {
      num60 = 1211912973U & num59;
      obj6 = _param2;
    }
    else
    {
      uint num4 = num59 >> 13;
      if (num4 / 529209163U == 0U)
      {
        obj6 = _param2.\u0030323FE8D();
        num60 = num4 ^ 610646U;
      }
      else
        goto label_66;
    }
    uint num61 = num60 * 673907204U;
    double num62 = obj6.\u00383BC968D();
    uint num63;
    double num64;
    if (!_param3)
    {
      double num4 = num3;
      num63 = 1031354009U & num61;
      double num5 = num62;
      num64 = num4 * num5;
    }
    else
    {
      uint num4 = 2091934627U >> (int) num61;
      if (2146435341 * (int) num4 != 0)
      {
        num64 = num3 * num62;
        num63 = num4 + 544249696U;
      }
      else
        goto label_66;
    }
    num2 = 1951555488U / num63;
    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(num64);
label_66:
    throw new InvalidOperationException();
  }

  private \u0031C561093.\u00304BE210E \u00376633B74(
    \u0031C561093.\u00304BE210E _param1,
    \u0031C561093.\u00304BE210E _param2,
    bool _param3)
  {
    uint num1 = 524159056;
label_1:
    uint num2;
    do
    {
      do
      {
        uint num3 = 448032966U - num1;
        \u0031C561093.\u00304BE210E obj1 = _param1;
        uint num4 = num3 & 1350202452U;
        \u0031C561093.\u00304BE210E obj2 = _param2;
        int num5 = (int) this.\u0030F7E56C3(obj1, obj2);
        uint num6 = num4 & 1611599070U;
        TypeCode typeCode = (TypeCode) num5;
        num1 = num6 | 1873573173U;
        int num7;
        if (num1 >= 1306402611U)
        {
          long num8;
          do
          {
            uint num9;
            do
            {
              int num10 = (int) (typeCode - ((int) num1 ^ 1873704316));
              num1 = 592468901U / num1;
              switch (num10)
              {
                case 0:
                  num9 = num1 / 1364026720U;
                  if (_param3)
                  {
                    uint num11 = num9 ^ 279074243U;
                    \u0031C561093.\u00304BE210E obj3 = _param1;
                    uint num12 = num11 - 82590944U;
                    int num13 = (int) obj3.\u00377124934();
                    \u0031C561093.\u00304BE210E obj4 = _param2;
                    uint num14 = 660480957U ^ num12;
                    uint num15 = obj4.\u00377124934();
                    num1 = 2055865886U * num14;
                    int num16 = (int) num15;
                    num7 = (int) ((uint) num13 / (uint) num16);
                    continue;
                  }
                  goto label_6;
                case 1:
                case 3:
                  goto label_33;
                case 2:
                  goto label_8;
                case 4:
                  int num17 = _param3 ? 1 : 0;
                  num1 = 1062295670U - num1;
                  if (num17 != 0)
                  {
                    if ((int) num1 * 1402339954 == 0)
                      goto case 0;
                    else
                      goto label_20;
                  }
                  else
                    goto label_17;
                case 5:
                  goto label_25;
                default:
                  num2 = num1 + 0U;
                  goto label_33;
              }
            }
            while ((int) num1 - 1984639233 == 0);
            goto label_7;
label_6:
            \u0031C561093.\u00304BE210E obj5 = _param1;
            uint num18 = 1400505074U - num9;
            int num19 = obj5.E2D6F630();
            \u0031C561093.\u00304BE210E obj6 = _param2;
            uint num20 = 1725652972U << (int) num18;
            int num21 = obj6.E2D6F630();
            uint num22 = num20 << 13;
            int num23 = num21;
            uint num24 = 137169460U - num22;
            int num25 = num19 / num23;
            uint num26 = num24 >> 4;
            num7 = num25;
            num1 = num26 + 2160351329U;
            goto label_7;
label_8:
            if ((660156949 ^ (int) num1) != 0)
            {
              if (_param3)
              {
                if ((int) num1 + 2065202162 != 0)
                {
                  \u0031C561093.\u00304BE210E obj3 = _param1;
                  uint num10 = num1 >> 31;
                  long num11 = (long) obj3.\u00353FB65C3();
                  uint num12 = num10 / 113273245U;
                  ulong num13 = _param2.\u00353FB65C3();
                  uint num14 = num12 | 1612982943U;
                  long num15 = (long) num13;
                  uint num16 = num14 | 1055196674U;
                  long num17 = (long) ((ulong) num11 / (ulong) num15);
                  num1 = num16 >> 23;
                  num8 = num17;
                  if (num1 > 415644035U)
                    goto label_1;
                }
                else
                  goto label_1;
              }
              else
              {
                num1 = 1089275192U | num1;
                if (140135521 * (int) num1 != 0)
                {
                  long num10 = _param1.D500CE01();
                  uint num11 = 1497197437U / num1;
                  long num12 = _param2.D500CE01();
                  uint num13 = num11 >> 31;
                  long num14 = num12;
                  uint num15 = 1866422136U + num13;
                  long num16 = num14;
                  uint num17 = 466646215U / num15;
                  num8 = num10 / num16;
                  num1 = num17 + 253U;
                }
              }
            }
            else
              goto label_1;
          }
          while (num1 > 475014667U);
          return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num8);
label_17:
          num1 /= 858287781U;
          continue;
        }
label_7:
        num2 = 783746622U & num1;
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num7);
      }
      while (93788163U == num1);
      \u0031C561093.\u00304BE210E obj7 = _param1;
      goto label_21;
label_20:
      \u0031C561093.\u00304BE210E obj8 = _param1;
      uint num27 = num1 / 1123505634U;
      obj7 = obj8.\u0030323FE8D();
      num1 = num27 + 1U;
label_21:
      double num28 = (double) obj7.BA2939E9();
      uint num29 = num1 >> 2;
      \u0031C561093.\u00304BE210E obj9;
      if (!_param3)
      {
        num2 = 1954116824U & num29;
        obj9 = _param2;
      }
      else
      {
        obj9 = _param2.\u0030323FE8D();
        num2 = num29 + 0U;
      }
      double num30 = (double) obj9.BA2939E9();
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00341173E9D((float) (num28 / num30));
label_25:
      if (_param3)
        goto label_28;
    }
    while (1038161127U <= num1);
    \u0031C561093.\u00304BE210E obj10 = _param1;
    goto label_29;
label_28:
    \u0031C561093.\u00304BE210E obj11 = _param1;
    uint num31 = 2011455404U >> (int) num1;
    obj10 = obj11.\u0030323FE8D();
    num1 = num31 ^ 2011455404U;
label_29:
    uint num32 = 484318129U << (int) num1;
    double num33 = obj10.\u00383BC968D();
    uint num34 = num32 % 2054297222U;
    \u0031C561093.\u00304BE210E obj12;
    if (!_param3)
    {
      obj12 = _param2;
    }
    else
    {
      obj12 = _param2.\u0030323FE8D();
      num34 ^= 0U;
    }
    double num35 = obj12.\u00383BC968D();
    uint num36 = num34 << 18;
    double num37 = num35;
    num2 = num36 + 1765765739U;
    double num38 = num37;
    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(num33 / num38);
label_33:
    throw new InvalidOperationException();
  }

  private \u0031C561093.\u00304BE210E \u0031575638B(
    \u0031C561093.\u00304BE210E _param1,
    \u0031C561093.\u00304BE210E _param2,
    bool _param3)
  {
    uint num1;
    uint num2;
    do
    {
      uint num3;
      do
      {
        uint num4;
        do
        {
          \u0031C561093.\u00304BE210E obj = _param1;
          uint num5 = 579743082;
          int num6 = (int) obj.\u003363C3519();
          uint num7 = num5 * 1393776977U;
          TypeCode typeCode = (TypeCode) num6;
          num1 = 2070819544U & num7;
label_1:
          if (typeCode != (TypeCode) ((int) num1 - 421802111))
          {
            uint num8 = 103039337U / num1;
            int num9 = (int) typeCode;
            uint num10 = num8 / 718348813U;
            int num11 = (int) num10 ^ 11;
            if (num9 == num11)
            {
              num1 = num10 | 116481634U;
              if (971252513 + (int) num1 != 0)
              {
                if (_param3)
                {
                  if ((1222659299 ^ (int) num1) == 0)
                    goto label_1;
                  else
                    goto label_11;
                }
                else
                  goto label_12;
              }
              else
                goto label_1;
            }
            else
              goto label_14;
          }
          else
            num4 = 568138457U & num1;
        }
        while (686245817U == num4);
        int num12 = _param3 ? 1 : 0;
        num3 = 343015763U % num4;
        if (num12 != 0)
        {
          uint num5 = num3 + 215750478U;
          int num6 = (int) _param1.\u00377124934();
          int num7 = (int) _param2.\u00377124934();
          num2 = num5 ^ 686634826U;
          int num8 = num7;
          return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81((int) ((uint) num6 % (uint) num8));
        }
      }
      while ((720527532 & (int) num3) == 0);
      int num13 = _param1.E2D6F630();
      uint num14 = num3 - 1504854297U;
      int num15 = _param2.E2D6F630();
      uint num16 = num14 - 1300641637U;
      int num17 = num15;
      num2 = num16 << 10;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num13 % num17);
label_11:
      \u0031C561093.\u00304BE210E obj1 = _param1;
      uint num18 = num1 - 2056286190U;
      long num19 = (long) obj1.\u00353FB65C3();
      long num20 = (long) _param2.\u00353FB65C3();
      uint num21 = num18 & 1264139923U;
      long num22 = num20;
      long num23 = (long) ((ulong) num19 % (ulong) num22);
      num2 = 2130673557U << (int) num21;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num23);
label_12:;
    }
    while ((619346978 ^ (int) num1) == 0);
    \u0031C561093.\u00304BE210E obj2 = _param1;
    uint num24 = num1 + 1220435311U;
    long num25 = obj2.D500CE01();
    uint num26 = num24 - 644245984U;
    long num27 = _param2.D500CE01();
    long num28 = num25 % num27;
    num2 = 240084532U - num26;
    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num28);
label_14:
    throw new InvalidOperationException();
  }

  private \u0031C561093.\u00304BE210E \u0031DEA1613(
    \u0031C561093.\u00304BE210E _param1,
    \u0031C561093.\u00304BE210E _param2)
  {
label_0:
    uint num1 = 1072371697;
    \u0031C561093.\u00304BE210E obj1 = _param1;
    uint num2 = 1134252103U + num1;
    \u0031C561093.\u00304BE210E obj2 = _param2;
    TypeCode typeCode = this.\u0030F7E56C3(obj1, obj2);
    do
    {
      uint num3;
      do
      {
        int num4 = (int) typeCode;
        uint num5 = num2 << 2;
        int num6 = (int) num5 - 236560599;
        num3 = 49893035U % num5;
        switch (num4 - num6)
        {
          case 0:
            num2 = 1707886538U ^ num3;
            continue;
          case 1:
          case 3:
            goto label_18;
          case 2:
            goto label_5;
          case 4:
            if (num3 < 1668886532U)
            {
              if (IntPtr.Size != (int) num3 - 49893031)
              {
                num3 = 466641568U >> (int) num3;
                if (num3 >> 16 == 0U)
                  goto case 0;
                else
                  goto label_9;
              }
              else
                goto label_10;
            }
            else
              goto case 0;
          case 5:
            if (((int) num3 ^ 795758713) != 0)
            {
              int size = IntPtr.Size;
              uint num7 = num3 + 1550066401U;
              int num8 = (int) num7 - 1599959432;
              if (size == num8)
              {
                num3 = 962683167U * num7;
                if (328692777 << (int) num3 == 0)
                  goto case 0;
                else
                  goto label_16;
              }
              else
                goto label_14;
            }
            else
              goto label_0;
          default:
            num3 ^= 0U;
            goto label_18;
        }
      }
      while ((int) num2 * 1017514341 == 0);
      \u0031C561093.\u00304BE210E obj3 = _param1;
      uint num9 = 1035169560U << (int) num2;
      int num10 = obj3.E2D6F630();
      uint num11 = 250762486U + num9;
      \u0031C561093.\u00304BE210E obj4 = _param2;
      uint num12 = 1760055860U + num11;
      int num13 = obj4.E2D6F630();
      uint num14 = 1014590120U ^ num12;
      int num15 = num13;
      uint num16 = num14 / 810423863U;
      int num17 = num10 ^ num15;
      uint num18 = 596644795U + num16;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num17);
label_5:
      uint num19 = num3 >> 21;
      long num20 = _param1.D500CE01();
      long num21 = _param2.D500CE01();
      uint num22 = num19 | 444474716U;
      long num23 = num21;
      uint num24 = num22 & 1745308644U;
      long num25 = num23;
      uint num26 = 1823474160U & num24;
      long num27 = num20 ^ num25;
      num18 = 1003249673U << (int) num26;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num27);
label_9:
      double num28 = 0.0;
      goto label_11;
label_10:
      num28 = double.NaN;
      num18 = num3 ^ 49951911U;
label_11:
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00341173E9D((float) num28);
label_14:
      double num29 = 0.0;
      goto label_17;
label_16:
      num29 = double.NaN;
      num18 = num3 + 955950488U;
label_17:
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(num29);
label_18:
      num2 = 1446274898U / num3;
    }
    while (1974362773U == num2);
    throw new InvalidOperationException();
  }

  private \u0031C561093.\u00304BE210E \u00338397096(
    \u0031C561093.\u00304BE210E _param1,
    \u0031C561093.\u00304BE210E _param2)
  {
    uint num1;
    uint num2;
    do
    {
      uint num3;
      uint num4;
      uint num5;
      uint num6;
      do
      {
        uint num7 = 1912168006;
        TypeCode typeCode = this.\u0030F7E56C3(_param1, _param2);
        num3 = num7 | 1853518120U;
label_1:
        int num8 = (int) typeCode;
        uint num9 = 309270510U - num3;
        int num10 = (int) num9 - -1837918089;
        int num11 = num8 - num10;
        num4 = 936651087U | num9;
        switch (num11)
        {
          case 0:
            num5 = 1263493003U - num4;
            continue;
          case 1:
          case 3:
            goto label_17;
          case 2:
            goto label_5;
          case 4:
            uint num12 = num4 + 29642487U;
            int size = IntPtr.Size;
            num6 = num12 | 164456043U;
            int num13 = (int) num6 ^ -1174573333;
            if (size != num13)
            {
              num3 = num6 << 19;
              if (1566014128U >= num3)
                goto label_1;
              else
                goto label_8;
            }
            else
              goto label_9;
          case 5:
            num3 = num4 / 467865772U;
            if (1121125884 + (int) num3 == 0)
              goto label_1;
            else
              goto label_12;
          default:
            num1 = num4 ^ 0U;
            goto label_17;
        }
      }
      while (num5 == 900533190U);
      \u0031C561093.\u00304BE210E obj1 = _param1;
      uint num14 = 1903126684U << (int) num5;
      int num15 = obj1.E2D6F630();
      int num16 = _param2.E2D6F630();
      num1 = num14 | 1330197280U;
      int num17 = num16;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num15 | num17);
label_5:
      long num18 = _param1.D500CE01();
      \u0031C561093.\u00304BE210E obj2 = _param2;
      uint num19 = 250547005U & num4;
      long num20 = obj2.D500CE01();
      uint num21 = num19 << 8;
      long num22 = num18 | num20;
      num1 = num21 + 16146767U;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num22);
label_8:
      double num23 = 0.0;
      goto label_10;
label_9:
      uint num24 = num6 << 1;
      num23 = double.NaN;
      num3 = num24 + 58532386U;
label_10:
      num1 = num3 | 1227230577U;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00341173E9D((float) num23);
label_12:
      int size1 = IntPtr.Size;
      int num25 = (int) num3 - 2;
      num2 = num3 & 1315380295U;
      if (size1 == num25)
        goto label_15;
    }
    while (num2 > 1626221226U);
    double num26 = 0.0;
    goto label_16;
label_15:
    num26 = double.NaN;
    num2 += 0U;
label_16:
    num1 = num2 | 1067265430U;
    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(num26);
label_17:
    throw new InvalidOperationException();
  }

  private \u0031C561093.\u00304BE210E \u0036F003174(
    \u0031C561093.\u00304BE210E _param1,
    \u0031C561093.\u00304BE210E _param2)
  {
    uint num1;
    uint num2;
    do
    {
      uint num3 = 1327105106;
      \u0031C561093.\u00304BE210E obj1 = _param1;
      uint num4 = num3 & 1399154583U;
      \u0031C561093.\u00304BE210E obj2 = _param2;
      int num5 = (int) this.\u0030F7E56C3(obj1, obj2);
      uint num6 = num4 + 1187675803U;
      TypeCode typeCode = (TypeCode) num5;
      uint num7 = num6 << 8;
      if (((int) num7 ^ 143920994) != 0)
      {
        int num8 = (int) typeCode;
        uint num9 = num7 % 1284209809U;
        int num10 = (int) num9 ^ 829141975;
        switch (num8 - num10)
        {
          case 0:
            uint num11 = num9 + 778514968U;
            int num12 = _param1.E2D6F630();
            \u0031C561093.\u00304BE210E obj3 = _param2;
            uint num13 = num11 ^ 31551211U;
            int num14 = obj3.E2D6F630();
            uint num15 = num13 ^ 328876717U;
            int num16 = num14;
            uint num17 = num15 % 1473453169U;
            int num18 = num12 & num16;
            num1 = 1681607824U % num17;
            return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num18);
          case 1:
          case 3:
            goto label_17;
          case 2:
            if (1386951438U != num9)
            {
              \u0031C561093.\u00304BE210E obj4 = _param1;
              uint num19 = 928480930U & num9;
              long num20 = obj4.D500CE01();
              uint num21 = 380120927U << (int) num19;
              long num22 = _param2.D500CE01();
              uint num23 = 1791367809U >> (int) num21;
              long num24 = num22;
              long num25 = num20 & num24;
              num1 = num23 | 2094560299U;
              return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num25);
            }
            goto case 0;
          case 4:
            uint num26 = 1607609850U >> (int) num9;
            if (925765880U / num26 != 0U)
            {
              double num19;
              if (IntPtr.Size != (int) num26 - -3)
              {
                num19 = 0.0;
              }
              else
              {
                num19 = double.NaN;
                num1 = num26 + 0U;
              }
              return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00341173E9D((float) num19);
            }
            goto label_17;
          case 5:
            num2 = num9 | 1874138407U;
            continue;
          default:
            if (num9 % 1667243676U != 0U)
            {
              num1 = num9 + 0U;
              goto label_17;
            }
            else
              continue;
        }
      }
      else
        goto label_17;
    }
    while (num2 == 2057911161U);
    double num27;
    if (IntPtr.Size != (int) num2 - 2147465211)
    {
      num1 = num2 + 656047669U;
      num27 = 0.0;
    }
    else
    {
      num27 = double.NaN;
      num1 = num2 ^ 3638919627U;
    }
    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(num27);
label_17:
    throw new InvalidOperationException();
  }

  private int \u00354720219(
    \u0031C561093.\u00304BE210E _param1,
    \u0031C561093.\u00304BE210E _param2,
    bool _param3,
    int _param4)
  {
    uint num1 = 736633503;
    if (num1 == 784349724U)
      goto label_2;
label_1:
    int num2 = _param4;
label_2:
    uint num3;
    uint num4;
    ulong num5;
    uint num6;
    int num7;
    do
    {
      int num8 = (int) _param1.\u003363C3519();
      num3 = num1 % 912358729U;
      TypeCode typeCode1 = (TypeCode) num8;
label_3:
      \u0031C561093.\u00304BE210E obj1 = _param2;
      uint num9 = num3 ^ 1174824235U;
      TypeCode typeCode2 = obj1.\u003363C3519();
      num1 = 1236236076U * num9;
      if ((1348154017 & (int) num1) != 0)
      {
label_4:
        int num10 = (int) typeCode1;
        num1 /= 1498220101U;
        int num11 = (int) num1 - -1;
        if (num10 != num11)
        {
          num1 = 668294436U + num1;
          if (num1 < 1132214461U)
          {
            if (typeCode2 == (TypeCode) ((int) num1 ^ 668294437))
            {
              num1 ^= 668294436U;
            }
            else
            {
              uint num12 = num1 | 1614414298U;
              if (typeCode1 != (TypeCode) ((int) num12 ^ 1744788976))
              {
                int num13 = (int) typeCode2;
                uint num14 = num12 >> 14;
                int num15 = (int) num14 - 106479;
                num1 = 1463904128U << (int) num14;
                if (num13 == num15)
                  num12 = num1 ^ 1744788990U;
                else if (num1 >> 31 == 0U)
                {
                  int num16 = (int) typeCode1;
                  int num17 = (int) num1 + 13;
                  uint num18 = num1 / 1879919744U;
                  if (num16 != num17)
                  {
                    int num19 = (int) typeCode2;
                    int num20 = (int) num18 ^ 13;
                    uint num21 = num18 >> 19;
                    if (num19 == num20)
                    {
                      num18 = num21 ^ 0U;
                    }
                    else
                    {
                      uint num22 = 1333291171U >> (int) num21;
                      int num23 = (int) typeCode1;
                      int num24 = (int) num22 - 1333291160;
                      uint num25 = num22 & 900818919U;
                      if (num23 != num24)
                      {
                        num1 = num25 << 7;
                        if (518658703U < num1)
                        {
                          int num26 = (int) typeCode2;
                          uint num27 = num1 & 1596668086U;
                          int num28 = (int) num27 - 404754549;
                          uint num29 = 1780095285U * num27;
                          if (num26 == num28)
                          {
                            num25 = num29 ^ 3356461603U;
                          }
                          else
                          {
                            num1 = 944601671U % num29;
                            if ((int) num1 - 1542218276 != 0)
                            {
                              int num30 = (int) typeCode1;
                              int num31 = (int) num1 - 944601662;
                              num1 |= 893267978U;
                              if (num30 != num31)
                              {
                                uint num32 = num1 ^ 773867165U;
                                int num33 = (int) typeCode2;
                                int num34 = (int) num32 ^ 325008603;
                                num1 = 1697872188U / num32 ^ 49821046U;
                                if (num33 == num34)
                                  num1 += 981943516U;
                                else
                                  goto label_49;
                              }
                              if (num1 >= 196032579U)
                              {
                                int num32 = _param3 ? 1 : 0;
                                num6 = num1 * 821001872U;
                                if (num32 == 0)
                                {
                                  num7 = _param1.E2D6F630();
                                  num1 = 1914052047U * num6;
                                  if ((int) num1 + 1528183033 == 0)
                                    goto label_4;
                                  else
                                    goto label_45;
                                }
                                else
                                  goto label_46;
                              }
                              else
                                continue;
                            }
                            else
                              goto label_1;
                          }
                        }
                        else
                          goto label_1;
                      }
                      num1 = num25 << 7;
                      if (1526886362U != num1)
                      {
                        int num26 = _param3 ? 1 : 0;
                        num4 = num1 << 7;
                        if (num26 != 0)
                        {
                          uint num27 = num4 << 22;
                          long num28 = (long) _param1.\u00353FB65C3();
                          uint num29 = 127470052U | num27;
                          num5 = (ulong) num28;
                          num3 = num29 << 24;
                          if (2118722064U == num3)
                            goto label_3;
                          else
                            goto label_36;
                        }
                        else
                          goto label_33;
                      }
                      else
                        continue;
                    }
                  }
                  uint num35 = num18 | 2135887235U;
                  \u0031C561093.\u00304BE210E obj2 = _param1;
                  num1 = 1315055517U >> (int) num35;
                  float num36 = obj2.BA2939E9();
                  if (1660575178U > num1)
                  {
                    ref float local = ref num36;
                    uint num19 = 1007104974U << (int) num1;
                    \u0031C561093.\u00304BE210E obj3 = _param2;
                    uint num20 = num19 ^ 830213848U;
                    double num21 = (double) obj3.BA2939E9();
                    num1 = 1822506852U + num20;
                    num2 = local.CompareTo((float) num21);
                    continue;
                  }
                  goto label_1;
                }
                else
                  goto label_1;
              }
              num1 = num12 / 1138302452U;
              if (num1 <= 1097088789U)
              {
                double num13 = _param1.\u00383BC968D();
                num1 |= 49821042U;
                double num14 = num13;
                if ((1253184337 ^ (int) num1) != 0)
                {
                  num2 = num14.CompareTo(_param2.\u00383BC968D());
                  if (num1 >= 347815231U)
                    goto label_1;
                  else
                    goto label_49;
                }
                else
                  goto label_1;
              }
              else
                goto label_1;
            }
          }
          else
            goto label_1;
        }
        if ((int) num1 << 27 == 0)
        {
          object obj2 = _param1.\u0035F319DE0();
          uint num12 = 1050047616U ^ num1;
          object obj3 = _param2.\u0035F319DE0();
          object obj4 = obj3;
          if (obj2 == obj4)
            return (int) num12 - 1050047616;
          uint num13 = 2020429068U - num12;
          object obj5 = obj3;
          uint num14 = num13 * 354958030U;
          return obj5 != null ? (int) (939555309U / num14) - 1 : (int) num14 ^ -1982728023;
        }
        goto label_1;
      }
    }
    while (num1 <= 205659465U);
    num1 ^= 425032527U;
    goto label_49;
label_33:
    num1 = num4 + 1634230266U;
    uint num37;
    int num38;
    if (2090887647U >= num1)
    {
      \u0031C561093.\u00304BE210E obj = _param1;
      uint num8 = 1078601141U + num1;
      long num9 = obj.D500CE01();
      uint num10 = num8 >> 7;
      ref long local = ref num9;
      uint num11 = num10 + 137959318U;
      long num12 = _param2.D500CE01();
      num37 = 1940865462U / num11;
      num38 = local.CompareTo(num12);
      goto label_37;
    }
    else
      goto label_1;
label_36:
    ref ulong local1 = ref num5;
    \u0031C561093.\u00304BE210E obj6 = _param2;
    uint num39 = 39388716U * num3;
    long num40 = (long) obj6.\u00353FB65C3();
    uint num41 = 343611772U >> (int) num39;
    num38 = local1.CompareTo((ulong) num40);
    num37 = num41 ^ 343611767U;
label_37:
    num2 = num38;
    num1 = num37 ^ 49821048U;
    goto label_49;
label_45:
    ref int local2 = ref num7;
    uint num42 = num1 * 1614226584U;
    \u0031C561093.\u00304BE210E obj7 = _param2;
    uint num43 = num42 + 1551905561U;
    int num44 = obj7.E2D6F630();
    uint num45 = num43 / 745805438U;
    int num46 = local2.CompareTo(num44);
    goto label_48;
label_46:
    num1 = num6 + 308955879U;
    if (152006333U <= num1)
    {
      \u0031C561093.\u00304BE210E obj1 = _param1;
      uint num8 = 302843850U >> (int) num1;
      int num9 = (int) obj1.\u00377124934();
      uint num10 = 1472029321U & num8;
      uint num11 = (uint) num9;
      ref uint local3 = ref num11;
      uint num12 = num10 | 428684318U;
      \u0031C561093.\u00304BE210E obj2 = _param2;
      uint num13 = num12 + 1569732631U;
      int num14 = (int) obj2.\u00377124934();
      uint num15 = 2003518717U & num13;
      num46 = local3.CompareTo((uint) num14);
      num45 = num15 + 2297871307U;
    }
    else
      goto label_1;
label_48:
    uint num47 = num45 | 1845971104U;
    num2 = num46;
    num1 = num47 + 2498817235U;
label_49:
    if (792678037U >= num1)
    {
      int num8 = num2;
      int num9 = (int) num1 ^ 49821043;
      uint num10 = 1883118533U ^ num1;
      if (num8 < num9)
      {
        num1 = 1639272209U >> (int) num10;
        num2 = (int) num1 - 391;
        if (((int) num1 ^ 536941716) == 0)
          goto label_1;
      }
      else
      {
        num1 = num10 << 1;
        if (num1 != 119938302U)
        {
          int num11 = num2;
          uint num12 = num1 * 1451841717U;
          int num13 = (int) num12 ^ -752407204;
          uint num14 = num12 ^ 250181526U ^ 3721288524U;
          if (num11 > num13)
          {
            int num15 = (int) num14 - 389;
            uint num16 = 1486111876U >> (int) num14;
            num2 = num15;
            uint num17 = num16 ^ 23220372U;
          }
        }
        else
          goto label_1;
      }
      return num2;
    }
    goto label_1;
  }

  private \u0031C561093.\u00304BE210E \u003742D300A(\u0031C561093.\u00304BE210E _param1)
  {
    uint num1 = 32645866;
    \u0031C561093.\u00304BE210E obj1 = _param1;
    uint num2 = 1759273703U ^ num1;
    TypeCode typeCode = obj1.\u003363C3519();
    uint num3 = 676361787U * num2;
    uint num4;
    do
    {
      int num5 = (int) typeCode;
      uint num6 = num3 ^ 1353076129U;
      int num7 = (int) num6 ^ -879194793;
      uint num8 = 1387552369U - num6;
      if (num5 != num7)
      {
        num3 = 1971676173U >> (int) num8;
        if (typeCode == (TypeCode) ((int) num3 ^ 3771))
          continue;
        num8 = 918832750U << (int) num3;
        if (669792860U / num8 == 0U)
          goto label_7;
      }
      int num9 = _param1.E2D6F630();
      num4 = 1363946294U | num8;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(~num9);
    }
    while (num3 >= 960850717U);
    \u0031C561093.\u00304BE210E obj2 = _param1;
    uint num10 = 998798564U ^ num3;
    long num11 = ~obj2.D500CE01();
    num4 = num10 >> 16;
    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num11);
label_7:
    throw new InvalidOperationException();
  }

  private \u0031C561093.\u00304BE210E \u0037C93334A(\u0031C561093.\u00304BE210E _param1)
  {
label_0:
    uint num1;
    do
    {
      int num2 = (int) _param1.\u003363C3519();
      uint num3 = 697775272;
      TypeCode typeCode = (TypeCode) num2;
      uint num4;
      do
      {
        int num5 = (int) typeCode;
        int num6 = (int) num3 ^ 697775265;
        uint num7 = 820604062U - num3;
        int num8 = num5 - num6;
        num1 = num7 - 1657632385U;
        switch (num8)
        {
          case 0:
            if (num1 >= 2034527657U)
              return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(-_param1.E2D6F630());
            goto case 2;
          case 1:
          case 3:
            goto label_11;
          case 2:
            num4 = 992173810U >> (int) num1;
            return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(-_param1.D500CE01());
          case 4:
            uint num9 = num1 - 125511841U;
            if (1404592021U <= num9)
            {
              \u0031C561093.\u00304BE210E obj = _param1;
              uint num10 = num9 + 485822822U;
              double num11 = -(double) obj.BA2939E9();
              num4 = num10 - 404382861U;
              return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00341173E9D((float) num11);
            }
            goto label_0;
          case 5:
            num3 = num1 / 166927428U;
            continue;
          default:
            if (num1 != 8264551U)
            {
              num1 += 0U;
              goto label_11;
            }
            else
              goto case 0;
        }
      }
      while (num3 % 880163548U == 0U);
      double num12 = _param1.\u00383BC968D();
      uint num13 = 627140647U - num3;
      double num14 = -num12;
      num4 = 2012957210U - num13;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(num14);
label_11:;
    }
    while (num1 <= 118293006U);
    throw new InvalidOperationException();
  }

  private \u0031C561093.\u00304BE210E \u003242114DB(
    \u0031C561093.\u00304BE210E _param1,
    \u0031C561093.\u00304BE210E _param2,
    bool _param3)
  {
    uint num1 = 695946311;
label_1:
    do
    {
      TypeCode typeCode = _param1.\u003363C3519();
      uint num2;
      do
      {
        while (typeCode == (TypeCode) ((int) num1 ^ 695946318))
        {
          uint num3 = 2096780564U * num1;
          int num4 = _param3 ? 1 : 0;
          num1 = 812406526U | num3;
          if (num4 != 0)
          {
            if (num1 <= 1522412811U)
            {
              \u0031C561093.\u00304BE210E obj = _param1;
              uint num5 = 191912260U % num1;
              return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81((int) (obj.\u00377124934() >> (_param2.E2D6F630() & ((int) num5 ^ 191912283))));
            }
          }
          else
          {
            int num5 = _param1.E2D6F630();
            uint num6 = num1 | 968905190U;
            int num7 = _param2.E2D6F630();
            uint num8 = 1328576501U / num6;
            int num9 = num7;
            int num10 = (int) num8 - -30;
            num2 = 454297635U + num8;
            int num11 = num9 & num10;
            return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num5 >> num11);
          }
        }
        num1 %= 1247422734U;
        if (num1 % 737940722U != 0U)
        {
          int num3 = (int) typeCode;
          num1 -= 1662279120U;
          int num4 = (int) num1 ^ -966332804;
          if (num3 == num4)
          {
            int num5 = _param3 ? 1 : 0;
            num1 *= 1911695559U;
            if (num5 != 0)
            {
              uint num6 = num1 >> 10;
              long num7 = (long) _param1.\u00353FB65C3();
              uint num8 = 1897867430U & num6;
              int num9 = _param2.E2D6F630() & ((int) (num8 ^ 1378097229U) ^ 1379154134);
              return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F((long) ((ulong) num7 >> num9));
            }
          }
          else
            goto label_13;
        }
        else
          goto label_1;
      }
      while (1157906759U == num1);
      \u0031C561093.\u00304BE210E obj1 = _param1;
      uint num12 = 580856629U % num1;
      long num13 = obj1.D500CE01();
      uint num14 = 1330192877U ^ num12;
      \u0031C561093.\u00304BE210E obj2 = _param2;
      uint num15 = 80150625U ^ num14;
      int num16 = obj2.E2D6F630();
      uint num17 = 264918262U >> (int) num15;
      int num18 = num16;
      int num19 = (int) num17 + 56;
      uint num20 = num17 ^ 551176278U;
      int num21 = num18 & num19;
      num2 = 2061849816U % num20;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num13 >> num21);
label_13:;
    }
    while (1427313747 + (int) num1 == 0);
    throw new InvalidOperationException();
  }

  private \u0031C561093.\u00304BE210E \u003325E1E71(
    \u0031C561093.\u00304BE210E _param1,
    \u0031C561093.\u00304BE210E _param2)
  {
    TypeCode typeCode;
    uint num1;
    uint num2;
    do
    {
      \u0031C561093.\u00304BE210E obj = _param1;
      uint num3 = 571171304;
      int num4 = (int) obj.\u003363C3519();
      uint num5 = num3 - 1181122208U;
      typeCode = (TypeCode) num4;
      int num6 = (int) typeCode;
      uint num7 = num5 % 394483742U;
      int num8 = (int) num7 - 134662705;
      num1 = num7 % 1537095744U;
      if (num6 != num8)
        num2 = num1 * 957022242U;
      else
        goto label_3;
    }
    while ((517490455 ^ (int) num2) == 0);
    int num9 = (int) typeCode;
    uint num10 = num2 >> 2;
    int num11 = (int) num10 ^ 718878438;
    uint num12;
    if (num9 == num11)
    {
      \u0031C561093.\u00304BE210E obj = _param1;
      uint num3 = num10 - 1549814640U;
      long num4 = obj.D500CE01();
      int num5 = _param2.E2D6F630();
      uint num6 = 415708661U >> (int) num3;
      int num7 = num5;
      int num8 = (int) num6 + 63;
      num12 = 447311360U * num6;
      int num13 = num7 & num8;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num4 << num13);
    }
    num12 = num10 + 569587496U;
    throw new InvalidOperationException();
label_3:
    uint num14 = num1 / 507604618U;
    \u0031C561093.\u00304BE210E obj1 = _param1;
    uint num15 = num14 & 1486295516U;
    int num16 = obj1.E2D6F630();
    uint num17 = num15 | 616766514U;
    \u0031C561093.\u00304BE210E obj2 = _param2;
    uint num18 = num17 * 1604267385U;
    int num19 = obj2.E2D6F630() & (int) (524556459U % num18 % 1822230658U) - 524556428;
    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num16 << num19);
  }

  private unsafe \u0031C561093.\u00304BE210E \u0031152448F(
    object _param1,
    Type _param2)
  {
    uint num1 = 656294491;
label_1:
    \u0031C561093.\u00304BE210E obj1;
    uint num2;
    object obj2;
    do
    {
      uint num3;
      uint num4;
      double num5;
      do
      {
        long num6;
        do
        {
          do
          {
            uint num7;
            int num8;
            do
            {
              do
              {
                do
                {
                  uint num9;
                  int num10;
                  do
                  {
                    uint num11;
                    int num12;
                    do
                    {
                      obj1 = _param1 as \u0031C561093.\u00304BE210E;
                      num1 ^= 1580940691U;
                      if (num1 % 835588623U == 0U)
                        goto label_5;
label_2:
                      do
                      {
                        Type type = _param2;
                        uint num13 = 651955564U / num1;
                        int num14 = type.IsEnum ? 1 : 0;
                        num1 = 50863970U >> (int) num13;
                        if (num14 != 0)
                        {
                          if (num1 >= 2088455191U)
                            goto label_1;
                        }
                        else
                          goto label_15;
label_4:
                        if (obj1 == null)
                          goto label_6;
                        else
                          goto label_5;
label_15:
                        uint num15 = 1974803035U + num1;
                        int typeCode1 = (int) Type.GetTypeCode(_param2);
                        num1 = 1216705239U + num15;
                        TypeCode typeCode2 = (TypeCode) typeCode1;
                        if (num1 > 1118534501U)
                        {
                          switch (typeCode2 - ((int) num1 ^ -1052595049))
                          {
                            case TypeCode.Empty:
                              num1 /= 807737824U;
                              if (1783392405U > num1)
                              {
                                if (obj1 == null)
                                  continue;
                                goto label_23;
                              }
                              else
                                goto label_1;
                            case TypeCode.Object:
                              goto label_26;
                            case TypeCode.DBNull:
                              goto label_32;
                            case TypeCode.Boolean:
                              goto label_37;
                            case TypeCode.Char:
                              goto label_43;
                            case TypeCode.SByte:
                              goto label_48;
                            case TypeCode.Byte:
                              goto label_54;
                            case TypeCode.Int16:
                              goto label_59;
                            case TypeCode.UInt16:
                              goto label_64;
                            case TypeCode.Int32:
                              goto label_70;
                            case TypeCode.UInt32:
                              goto label_74;
                            case TypeCode.Int64:
                              if (num1 / 768960062U == 0U)
                                goto label_4;
                              else
                                goto label_81;
                            case TypeCode.UInt64:
                            case TypeCode.Single:
                            case TypeCode.Double:
                              if ((object) _param2 == (object) typeof (IntPtr))
                              {
                                num1 -= 1421570883U;
                                if (num1 <= 313721742U)
                                  goto label_4;
                                else
                                  goto label_94;
                              }
                              else if (1387953995U % num1 == 0U)
                                goto label_4;
                              else
                                goto label_103;
                            case TypeCode.Decimal:
                              if (1499102103U >= num1)
                                goto label_4;
                              else
                                goto label_87;
                            default:
                              if (num1 != 579822226U)
                              {
                                num1 ^= 0U;
                                goto case TypeCode.UInt64;
                              }
                              else
                                goto label_1;
                          }
                        }
                        else
                          goto label_1;
                      }
                      while (677249981U < num1);
                      num12 = Convert.ToBoolean(_param1) ? 1 : 0;
                      goto label_25;
label_23:
                      num1 = 920352256U & num1;
                      continue;
label_26:
                      uint num16 = 921006385U & num1;
                      \u0031C561093.\u00304BE210E obj3 = obj1;
                      num1 = 651642101U >> (int) num16;
                      if (obj3 == null)
                      {
                        num1 ^= 436673023U;
                        if (num1 == 2085762081U)
                          goto label_2;
                        else
                          goto label_28;
                      }
                      else if (num1 == 545482105U)
                        goto label_2;
                      else
                        goto label_30;
label_32:
                      num11 = num1 % 1747321025U;
                      if (obj1 == null)
                      {
                        num1 = num11 >> 23;
                        if ((int) num1 << 29 == 0)
                          goto label_6;
                        else
                          goto label_34;
                      }
                      else
                        goto label_35;
label_37:
                      \u0031C561093.\u00304BE210E obj4 = obj1;
                      num1 = 1016622442U >> (int) num1;
                      if (obj4 == null)
                      {
                        if ((1907572103 ^ (int) num1) == 0)
                          goto label_5;
                        else
                          goto label_39;
                      }
                      else
                        goto label_40;
label_43:
                      if (obj1 != null)
                      {
                        if (num1 < 1434267736U)
                          goto label_2;
                        else
                          goto label_46;
                      }
                      else
                        goto label_44;
label_64:
                      num1 = 478546391U & num1;
                      if (obj1 == null)
                      {
                        if (num1 > 735850447U)
                          goto label_5;
                        else
                          goto label_66;
                      }
                      else
                        goto label_67;
label_74:
                      num1 = 1317947293U >> (int) num1;
                      if (257114168U >= num1)
                      {
                        \u0031C561093.\u00304BE210E obj5 = obj1;
                        num1 += 2136895767U;
                        if (obj5 == null)
                        {
                          if (619061040U >= num1)
                            goto label_2;
                          else
                            goto label_77;
                        }
                        else
                          goto label_78;
                      }
                      else
                        continue;
label_87:
                      \u0031C561093.\u00304BE210E obj6 = obj1;
                      num3 = num1 & 1054287601U;
                      if (obj6 != null)
                      {
                        num1 = num3 / 84434235U;
                        if (num1 > 471608200U)
                          goto label_2;
                        else
                          goto label_90;
                      }
                      else
                        goto label_88;
label_103:
                      Type type1 = _param2;
                      Type type2 = typeof (UIntPtr);
                      num4 = num1 & 1408712533U;
                      if ((object) type1 != (object) type2)
                      {
                        Type type3 = _param2;
                        num1 = 481124389U | num4;
                        if (type3.IsValueType)
                        {
                          if ((int) num1 + 397490566 != 0)
                          {
                            if (obj1 == null)
                            {
                              num1 = 1259871475U ^ num1;
                              if (393766846U < num1)
                                goto label_2;
                              else
                                goto label_115;
                            }
                            else
                              goto label_113;
                          }
                          else
                            continue;
                        }
                        else
                        {
                          uint num13 = 1902469658U - num1;
                          Type type4 = _param2;
                          uint num14 = 681147431U & num13;
                          int num15 = type4.IsArray ? 1 : 0;
                          num1 = 1172852549U << (int) num14;
                          if (num15 == 0)
                          {
                            if ((int) num1 - 553610896 != 0)
                              goto label_126;
                          }
                          else
                            goto label_120;
                        }
                      }
                      else
                        goto label_104;
label_5:
                      _param1 = obj1.\u0035F319DE0();
                      num1 ^= 0U;
label_6:
                      num1 %= 1633382036U;
                      if (_param1 != null)
                      {
                        Enum @enum = _param1 as Enum;
                        num1 += 0U;
                        if (@enum == null)
                        {
                          if (num1 != 906651944U)
                          {
                            _param1 = Enum.ToObject(_param2, _param1);
                            num1 ^= 0U;
                          }
                          else
                            goto label_2;
                        }
                      }
                      num1 *= 1384016818U;
                      uint num17;
                      Enum enum1;
                      if (_param1 != null)
                      {
                        uint num13 = num1 * 598433634U;
                        object obj5 = _param1;
                        num17 = 1356954447U + num13;
                        enum1 = (Enum) obj5;
                      }
                      else if (1711290026U > num1)
                      {
                        Type type3 = _param2;
                        uint num13 = 880419080U & num1;
                        enum1 = (Enum) Activator.CreateInstance(type3);
                        num17 = num13 ^ 845640983U;
                      }
                      else
                        continue;
                      num2 = num17 / 465973313U;
                      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0036152782D(enum1);
                    }
                    while (76628505U < num1);
                    num12 = obj1.\u0039CB63F4A() ? 1 : 0;
                    num1 ^= 4U;
label_25:
                    num2 = num1 << 14;
                    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u003459C67EE(num12 != 0);
label_28:
                    int num18 = (int) Convert.ToChar(_param1);
                    goto label_31;
label_30:
                    num18 = (int) obj1.FCB291BE();
                    num1 ^= 436673023U;
label_31:
                    num2 = num1 * 2043677115U;
                    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00343192462((char) num18);
label_34:
                    int num19 = (int) Convert.ToSByte(_param1);
                    goto label_36;
label_35:
                    uint num20 = 845629653U + num11;
                    num19 = (int) obj1.\u00309729E51();
                    num1 = num20 ^ 2340680730U;
label_36:
                    num2 = num1 ^ 37095670U;
                    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u003707D1DC6((sbyte) num19);
label_39:
                    object obj7 = _param1;
                    num9 = num1 ^ 1112681023U;
                    num10 = (int) Convert.ToByte(obj7);
                    goto label_42;
label_40:;
                  }
                  while (num1 == 520573772U);
                  \u0031C561093.\u00304BE210E obj8 = obj1;
                  uint num21 = num1 * 856230714U;
                  num10 = (int) obj8.\u00342E17D34();
                  num9 = num21 + 353807212U;
label_42:
                  num2 = num9 - 1879908558U;
                  return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0034C6A3A6D((byte) num10);
label_44:
                  uint num22 = 1285976630U >> (int) num1;
                  object obj9 = _param1;
                  num2 = 1371684157U - num22;
                  int num23 = (int) Convert.ToInt16(obj9);
                  goto label_47;
label_46:
                  \u0031C561093.\u00304BE210E obj10 = obj1;
                  uint num24 = num1 / 1845112876U;
                  num23 = (int) obj10.E66DE219();
                  num2 = num24 + 1371682930U;
label_47:
                  return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u003292A58A9((short) num23);
label_48:
                  num1 = 1004875547U << (int) num1;
                }
                while (num1 == 730560401U);
                if (obj1 == null)
                  num1 = 1269788661U | num1;
                else
                  goto label_52;
              }
              while (((int) num1 & 1734484979) == 0);
              object obj11 = _param1;
              num2 = 1722621100U / num1;
              int num25 = (int) Convert.ToUInt16(obj11);
              goto label_53;
label_52:
              num25 = (int) obj1.DD7230A3();
              num2 = num1 ^ 4054843392U;
label_53:
              return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u003727958FF((ushort) num25);
label_54:
              uint num26 = 549716285U << (int) num1;
              \u0031C561093.\u00304BE210E obj12 = obj1;
              num1 = num26 << 16;
              if (obj12 == null)
              {
                uint num9 = 382823242U & num1;
                object obj3 = _param1;
                num7 = 1078750343U - num9;
                num8 = Convert.ToInt32(obj3);
                goto label_58;
              }
            }
            while (839536953 - (int) num1 == 0);
            num8 = obj1.E2D6F630();
            num7 = num1 + 1078750343U;
label_58:
            num2 = 1040657821U + num7;
            return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num8);
label_59:
            if (obj1 == null)
              num1 <<= 7;
            else
              goto label_62;
          }
          while (18489535 << (int) num1 == 0);
          int num27 = (int) Convert.ToUInt32(_param1);
          goto label_63;
label_62:
          num27 = (int) obj1.\u00377124934();
          num2 = num1 ^ 1611982484U;
label_63:
          return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00328355445((uint) num27);
label_66:
          num6 = Convert.ToInt64(_param1);
          goto label_69;
label_67:;
        }
        while (775888215U < num1);
        num6 = obj1.D500CE01();
        num1 += 0U;
label_69:
        num2 = 1281842538U * num1;
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num6);
label_70:
        uint num28 = num1 ^ 1527533749U;
        long num29;
        if (obj1 == null)
        {
          num29 = (long) Convert.ToUInt64(_param1);
        }
        else
        {
          uint num7 = 699617079U % num28;
          \u0031C561093.\u00304BE210E obj3 = obj1;
          uint num8 = 1283726687U >> (int) num7;
          num29 = (long) obj3.\u00353FB65C3();
          num28 = num8 + 2588867464U;
        }
        num2 = num28 ^ 1944071107U;
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00362E85068((ulong) num29);
label_77:
        double num30 = (double) Convert.ToSingle(_param1);
        goto label_79;
label_78:
        uint num31 = num1 | 1701543629U;
        num30 = (double) obj1.BA2939E9();
        num2 = num31 ^ 2165248U;
label_79:
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00341173E9D((float) num30);
label_81:
        if (obj1 == null)
        {
          num2 = 1388848840U / num1;
          num5 = Convert.ToDouble(_param1);
          goto label_85;
        }
        else
          num1 = 660545875U * num1;
      }
      while (num1 == 1527343235U);
      num5 = obj1.\u00383BC968D();
      num2 = num1 + 674691076U;
label_85:
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(num5);
label_88:
      object obj13 = _param1;
      uint num32 = num3 * 274469372U;
      string str = (string) obj13;
      goto label_91;
label_90:
      str = obj1.ToString();
      num32 = num1 ^ 3377040832U;
label_91:
      num2 = 616195615U >> (int) num32;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0036D9D2AA1(str);
label_94:
      \u0031C561093.\u00304BE210E obj14 = obj1;
      num1 >>= 12;
      if (obj14 != null)
      {
        num1 = 1777339631U + num1;
        if (1080303646U <= num1)
        {
          \u0031C561093.\u00304BE210E obj3 = obj1;
          uint num6 = num1 & 216142718U;
          IntPtr num7 = obj3.B8342F7A();
          num2 = 1573473702U - num6;
          return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0033E8F1420(num7);
        }
        continue;
      }
      IntPtr num33;
      if (_param1 == null)
      {
        if (num1 < 1034041745U)
          num33 = IntPtr.Zero;
        else
          continue;
      }
      else
      {
        object obj3 = _param1;
        uint num6 = num1 + 367754556U;
        num33 = (IntPtr) obj3;
        num1 = num6 + 3927212740U;
      }
      num2 = 1096756276U % num1;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0033E8F1420(num33);
label_104:
      \u0031C561093.\u00304BE210E obj15 = obj1;
      uint num34 = num4 / 406599281U;
      if (obj15 != null)
      {
        uint num6 = 1631198893U % num34;
        UIntPtr num7 = obj1.\u0032452299F();
        num2 = 1373401748U + num6;
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0035D455BDE(num7);
      }
      IntPtr num35;
      if (_param1 == null)
      {
        num2 = 1095252283U ^ num34;
        num35 = (IntPtr) UIntPtr.Zero;
      }
      else
      {
        num35 = (IntPtr) _param1;
        num2 = num34 ^ 1095252283U;
      }
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0035D455BDE((UIntPtr) num35);
label_113:
      \u0031C561093.\u00304BE210E obj16 = obj1;
      uint num36 = 1694318923U / num1;
      object obj17 = obj16.\u0035F319DE0();
      num2 = num36 ^ 1578303728U;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u003475922BE(obj17);
label_115:
      object obj18 = _param1;
      uint num37 = num1 / 1558591040U;
      object obj19;
      if (obj18 != null)
      {
        obj19 = _param1;
      }
      else
      {
        Type type = _param2;
        uint num6 = num37 / 5059128U;
        obj19 = Activator.CreateInstance(type);
        num2 = num6 ^ 0U;
      }
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u003475922BE(obj19);
label_120:
      uint num38 = num1 * 277440593U;
      \u0031C561093.\u00304BE210E obj20 = obj1;
      uint num39 = num38 >> 27;
      Array array;
      if (obj20 == null)
      {
        array = (Array) _param1;
      }
      else
      {
        num1 = num39 << 12;
        if (1288963095U >= num1)
        {
          array = (Array) obj1.\u0035F319DE0();
          num39 = num1 + 4294926346U;
        }
        else
          continue;
      }
      num2 = 1062623602U * num39;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0033745431B(array);
label_126:
      Type type5 = _param2;
      uint num40 = num1 & 1439909022U;
      if (type5.IsPointer)
      {
        num1 = num40 << 24;
        if (76303807U <= num1)
        {
          \u0031C561093.\u00304BE210E obj3 = obj1;
          num1 |= 1144277616U;
          if (obj3 != null)
          {
            if (1349473908U < num1)
            {
              void* ptr = obj1.\u003480545A0();
              Type type1 = _param2;
              num2 = num1 ^ 578562500U;
              return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00369D911C6(Pointer.Box(ptr, type1), _param2);
            }
          }
          else if (1282235353U < num1)
          {
            uint num6;
            IntPtr num7;
            if (_param1 == null)
            {
              int num8 = (int) num1 - -1003206032;
              num6 = num1 << 31;
              num7 = (IntPtr) (uint) num8;
            }
            else if ((1856702014 ^ (int) num1) != 0)
            {
              object ptr = _param1;
              uint num8 = 68759563U << (int) num1;
              num7 = (IntPtr) Pointer.Unbox(ptr);
              num6 = num8 + 3488940032U;
            }
            else
              continue;
            uint num9 = num6 << 30;
            Type type1 = _param2;
            uint num10 = num9 - 726098069U;
            object obj4 = Pointer.Box((void*) num7, type1);
            uint num11 = num10 << 8;
            Type type2 = _param2;
            num2 = num11 / 1829254285U;
            return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00369D911C6(obj4, type2);
          }
        }
      }
      else
      {
        \u0031C561093.\u00304BE210E obj3 = obj1;
        uint num6 = num40 * 1810890905U;
        if (obj3 == null)
        {
          num1 = num6 * 1622951725U;
          if ((int) num1 * 2110852057 != 0)
          {
            obj2 = _param1;
            goto label_142;
          }
        }
        else
          num1 = 577789274U / num6;
      }
    }
    while ((1185828849 & (int) num1) != 0);
    obj2 = obj1.\u0035F319DE0();
    num2 = num1 + 3500356224U;
label_142:
    return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00362DF5BD2(obj2);
  }

  private string \u00333A9069D(int _param1)
  {
    uint num1 = 410520962;
    Dictionary<int, object> dictionary1;
    if (1779596735U != num1)
    {
      do
      {
        dictionary1 = \u0031C561093.\u0031ACB10FF;
      }
      while (((int) num1 & 1732117899) == 0);
    }
    Dictionary<int, object> dictionary2 = dictionary1;
    uint num2 = num1 ^ 904215065U;
    Monitor.Enter((object) dictionary2);
    string str1;
    uint num3;
    try
    {
      uint num4 = 1071403823U >> (int) num2;
      object obj;
      if ((545871273 & (int) num4) != 0)
      {
        do
        {
          Dictionary<int, object> dictionary3 = \u0031C561093.\u0031ACB10FF;
          int key1 = _param1;
          uint num5 = num4 * 842793513U;
          ref object local = ref obj;
          if (dictionary3.TryGetValue(key1, out local))
          {
            if (num5 > 1687387129U)
              break;
            goto label_6;
          }
          else
          {
            Module module = this.\u00318CB0DB9;
            num4 = 1579375726U / num5;
            int metadataToken = _param1;
            string str2 = module.ResolveString(metadataToken);
            if (num4 < 470174829U)
            {
              Dictionary<int, object> dictionary4 = \u0031C561093.\u0031ACB10FF;
              int key2 = _param1;
              string str3 = str2;
              uint num6 = 2129997365U ^ num4;
              dictionary4.Add(key2, (object) str3);
              num4 = 1248489974U >> (int) num6;
              if (856623497U == num4)
                goto label_6;
            }
            str1 = str2;
          }
        }
        while (num4 >= 995387253U);
        goto label_11;
      }
label_6:
      str1 = (string) obj;
    }
    finally
    {
      num3 = 770445343U;
      Monitor.Exit((object) dictionary1);
    }
label_11:
    num3 = 1735352095U;
    return str1;
  }

  private Type \u0033CE71CC6(int _param1)
  {
    uint num1 = 1535199003;
    Dictionary<int, object> dictionary1;
    do
    {
      dictionary1 = \u0031C561093.\u0031ACB10FF;
      num1 >>= 12;
    }
    while (363281945U < num1);
    Dictionary<int, object> dictionary2 = dictionary1;
    uint num2 = 1203182197U >> (int) num1;
    Monitor.Enter((object) dictionary2);
    Type type1;
    try
    {
      uint num3 = 509477972U * num2;
      Type type2;
      do
      {
        Dictionary<int, object> dictionary3 = \u0031C561093.\u0031ACB10FF;
        int key = _param1;
        object obj1;
        ref object local = ref obj1;
        num3 &= 2116364672U;
        if (dictionary3.TryGetValue(key, out local))
        {
          if (num3 < 943130568U)
          {
            object obj2 = obj1;
            uint num4 = 1951743019U & num3;
            Type type3 = (Type) obj2;
            uint num5 = num4 + 43789062U;
            type1 = type3;
            if (75005254U >= num5)
              goto label_9;
            else
              goto label_11;
          }
        }
        else
        {
          uint num4 = num3 * 1114996463U;
          Module module = this.\u00318CB0DB9;
          num3 = num4 << 13;
          int metadataToken = _param1;
          type2 = module.ResolveType(metadataToken);
        }
      }
      while ((int) num3 - 822760769 == 0);
      Dictionary<int, object> dictionary4 = \u0031C561093.\u0031ACB10FF;
      uint num6 = num3 ^ 1740845395U;
      int key1 = _param1;
      Type type4 = type2;
      dictionary4.Add(key1, (object) type4);
label_9:
      type1 = type2;
    }
    finally
    {
      Monitor.Exit((object) dictionary1);
    }
label_11:
    return type1;
  }

  private MethodBase \u00304614996(int _param1)
  {
    uint num1 = 1179858549;
    Dictionary<int, object> dictionary1;
    if (81008789U != num1)
    {
      Dictionary<int, object> dictionary2 = \u0031C561093.\u0031ACB10FF;
      num1 = 1236416448U ^ num1;
      dictionary1 = dictionary2;
    }
    Dictionary<int, object> dictionary3 = dictionary1;
    uint num2 = 10566955U ^ num1;
    Monitor.Enter((object) dictionary3);
    uint num3;
    MethodBase methodBase1;
    try
    {
      if (num2 >= 1399266717U)
        goto label_6;
label_4:
      Dictionary<int, object> dictionary2 = \u0031C561093.\u0031ACB10FF;
      uint num4 = num2 >> 14;
      int key1 = _param1;
      object obj;
      ref object local = ref obj;
      uint num5 = num4 * 2103923257U;
      int num6 = dictionary2.TryGetValue(key1, out local) ? 1 : 0;
      num2 = 571302107U - num5;
      if (num6 == 0 || (int) num2 - 365760917 == 0)
        goto label_6;
label_5:
      MethodBase methodBase2 = (MethodBase) obj;
      num3 = 703077891U & num2;
      methodBase1 = methodBase2;
      goto label_12;
label_6:
      num2 = 1903778511U % num2;
      if (num2 > 479487365U)
      {
        MethodBase methodBase3 = this.\u00318CB0DB9.ResolveMethod(_param1);
        num2 >>= 26;
        if (num2 <= 1564820510U)
        {
          Dictionary<int, object> dictionary4 = \u0031C561093.\u0031ACB10FF;
          int key2 = _param1;
          MethodBase methodBase4 = methodBase3;
          uint num7 = 361374071U & num2;
          dictionary4.Add(key2, (object) methodBase4);
          num2 = 442841970U % num7;
          if (num2 < 1240276580U)
          {
            methodBase1 = methodBase3;
            if (452404766 << (int) num2 == 0)
              goto label_5;
          }
          else
            goto label_5;
        }
        else
          goto label_4;
      }
      else
        goto label_4;
    }
    finally
    {
      uint num4;
      do
      {
        uint num5 = 2033343157;
        Dictionary<int, object> dictionary2 = dictionary1;
        num4 = 1917602236U - num5;
        Monitor.Exit((object) dictionary2);
      }
      while (952320311U > num4);
    }
label_12:
    num3 = 523843698U;
    return methodBase1;
  }

  private FieldInfo \u00310D515AF(int _param1)
  {
    uint num1 = 1151612411;
    Dictionary<int, object> dictionary1;
    do
    {
      Dictionary<int, object> dictionary2 = \u0031C561093.\u0031ACB10FF;
      uint num2 = num1 - 1593271601U;
      dictionary1 = dictionary2;
      num1 = 1571765476U / num2;
    }
    while ((int) num1 * 221594946 != 0);
    Dictionary<int, object> dictionary3 = dictionary1;
    uint num3 = 715084807U >> (int) num1;
    Monitor.Enter((object) dictionary3);
    uint num4;
    FieldInfo fieldInfo1;
    try
    {
      uint num2 = num3 * 685406140U;
      do
      {
        do
        {
          Dictionary<int, object> dictionary2 = \u0031C561093.\u0031ACB10FF;
          int key = _param1;
          uint num5 = num2 / 394921272U;
          object obj;
          ref object local = ref obj;
          uint num6 = num5 & 1114902589U;
          int num7 = dictionary2.TryGetValue(key, out local) ? 1 : 0;
          num2 = num6 >> 25;
          if (num7 != 0)
          {
            if ((1087123710 ^ (int) num2) != 0)
            {
              FieldInfo fieldInfo2 = (FieldInfo) obj;
              num4 = 994186428U * num2;
              fieldInfo1 = fieldInfo2;
              goto label_11;
            }
          }
        }
        while (((int) num2 ^ 1541021635) == 0);
        uint num8 = 1783569047U + num2;
        FieldInfo fieldInfo3 = this.\u00318CB0DB9.ResolveField(_param1);
        uint num9 = 868883925U % num8;
        FieldInfo fieldInfo4 = fieldInfo3;
        Dictionary<int, object> dictionary4 = \u0031C561093.\u0031ACB10FF;
        num2 = num9 >> 21;
        int key1 = _param1;
        FieldInfo fieldInfo5 = fieldInfo4;
        dictionary4.Add(key1, (object) fieldInfo5);
        fieldInfo1 = fieldInfo4;
      }
      while ((int) num2 * 1159670638 == 0);
    }
    finally
    {
      uint num2;
      do
      {
        Dictionary<int, object> dictionary2 = dictionary1;
        num2 = 840453725U;
        Monitor.Exit((object) dictionary2);
      }
      while (num2 % 1233473981U == 0U);
    }
label_11:
    num4 = 1083654850U;
    return fieldInfo1;
  }

  private \u0031C561093.\u00304BE210E \u00359CF2E14(MethodBase _param1)
  {
    uint num1 = 1894915480;
    if (num1 < 746813893U)
      goto label_2;
label_1:
    MethodBase methodBase1 = _param1;
    uint num2 = num1 << 16;
    ParameterInfo[] parameters1 = methodBase1.GetParameters();
    num1 = num2 - 176117978U;
label_2:
    Dictionary<int, \u0031C561093.\u00304BE210E> dictionary1 = new Dictionary<int, \u0031C561093.\u00304BE210E>();
    object[] objArray1 = new object[parameters1.Length];
    num1 = 1161039195U >> (int) num1;
    if (6428479U >> (int) num1 != 0U)
    {
      int length = parameters1.Length;
      uint num3 = num1 << 5;
      int num4 = length - ((int) num3 - 580519583);
      num1 = 2014924960U & num3;
      int num5 = num4;
      if (607198125 + (int) num1 != 0)
        goto label_9;
label_7:
      \u0031C561093.\u00304BE210E obj1;
      if ((int) num1 << 27 != 0)
      {
        object[] objArray2 = objArray1;
        int index1 = num5;
        uint num6 = num1 | 1755593769U;
        \u0031C561093.\u00304BE210E obj2 = obj1;
        ParameterInfo[] parameterInfoArray = parameters1;
        int index2 = num5;
        uint num7 = num6 ^ 2105415033U;
        Type parameterType = parameterInfoArray[index2].ParameterType;
        uint num8 = num7 + 246176990U;
        \u0031C561093.\u00304BE210E obj3 = this.\u0031152448F((object) obj2, parameterType);
        uint num9 = 1717904269U ^ num8;
        object obj4 = obj3.\u0035F319DE0();
        uint num10 = num9 % 466497813U;
        objArray2[index1] = obj4;
        int num11 = num5;
        uint num12 = num10 - 1879145078U;
        int num13 = (int) num12 ^ -1777440808;
        uint num14 = num12 - 1353871381U;
        int num15 = num11 - num13;
        uint num16 = num14 | 300043433U;
        num5 = num15;
        num1 = num16 ^ 1977876301U;
      }
      else
        goto label_1;
label_9:
      if (1796365793U >= num1)
      {
        int num6 = num5;
        num1 = 1316687111U | num1;
        int num7 = (int) num1 - 1853558183;
        if (num6 >= num7)
        {
          \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
          uint num8 = 2125999646;
          obj1 = obj2;
          uint num9 = 1975528698U >> (int) num8;
          \u0031C561093.\u00304BE210E obj3 = obj1;
          num1 = 851331601U >> (int) num9;
          if (obj3.\u0036736EEEA())
          {
            if (num1 <= 1931639495U)
            {
              Dictionary<int, \u0031C561093.\u00304BE210E> dictionary2 = dictionary1;
              int key = num5;
              uint num10 = 930443263U >> (int) num1;
              \u0031C561093.\u00304BE210E obj4 = obj1;
              uint num11 = num10 | 638601932U;
              dictionary2[key] = obj4;
              num1 = num11 ^ 1063803623U;
              goto label_7;
            }
            else
              goto label_1;
          }
          else
            goto label_7;
        }
        else if ((int) num1 * 200880108 != 0)
        {
          MethodBase methodBase2 = _param1;
          uint num8 = num1 >> 6;
          ConstructorInfo constructorInfo = (ConstructorInfo) methodBase2;
          object[] parameters2 = objArray1;
          uint num9 = 406945053U + num8;
          object obj2 = constructorInfo.Invoke(parameters2);
          num1 = num9 >> 20;
          if (686244925U != num1)
          {
            Dictionary<int, \u0031C561093.\u00304BE210E> dictionary2 = dictionary1;
            uint num10 = num1 * 1053780749U;
            Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator enumerator = dictionary2.GetEnumerator();
            uint num11;
            try
            {
              while (true)
              {
                uint num12 = 603981123U << (int) num10;
                ref Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator local1 = ref enumerator;
                uint num13 = num12 | 680727171U;
                int num14 = local1.MoveNext() ? 1 : 0;
                num11 = 608509497U | num13;
                if (num14 != 0)
                {
                  KeyValuePair<int, \u0031C561093.\u00304BE210E> keyValuePair;
                  uint num15;
                  do
                  {
                    ref Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator local2 = ref enumerator;
                    uint num16 = 1381571082;
                    KeyValuePair<int, \u0031C561093.\u00304BE210E> current = local2.Current;
                    uint num17 = 1002178020U | num16;
                    keyValuePair = current;
                    num15 = 429147481U % num17;
                  }
                  while (868300982U % num15 == 0U);
                  \u0031C561093.\u00304BE210E obj3 = keyValuePair.Value;
                  object[] objArray2 = objArray1;
                  int key = keyValuePair.Key;
                  uint num18 = num15 * 1785929449U;
                  object obj4 = objArray2[key];
                  obj3.\u0036DCE2291(obj4);
                  num10 = num18 ^ 2066744850U;
                }
                else
                  break;
              }
            }
            finally
            {
              uint num12 = 218069152;
              ref Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator local = ref enumerator;
              num11 = num12 * 518654304U;
              local.Dispose();
            }
            uint num19 = 1244156105;
            object obj5 = obj2;
            uint num20 = num19 | 88299310U;
            MethodBase methodBase3 = _param1;
            uint num21 = num20 + 1782394989U;
            Type declaringType = methodBase3.DeclaringType;
            num11 = num21 << 5;
            return this.\u0031152448F(obj5, declaringType);
          }
          goto label_1;
        }
        else
          goto label_1;
      }
      else
        goto label_2;
    }
    else
      goto label_1;
  }

  private bool \u003454821D7(
    MethodBase _param1,
    object _param2,
    ref object _param3,
    object[] _param4)
  {
    uint num1 = 453852328;
label_1:
    Type type1;
    do
    {
      MethodBase methodBase = _param1;
      uint num2 = num1 / 11736231U;
      Type declaringType = methodBase.DeclaringType;
      uint num3 = num2 ^ 660037112U;
      type1 = declaringType;
      num1 = 1151031535U | num3;
    }
    while (1543590271U / num1 != 0U);
    while ((object) type1 != null)
    {
      num1 *= 616452486U;
      if (((int) num1 & 386231599) != 0)
      {
        int num2 = type1.IsGenericType ? 1 : 0;
        uint num3 = num1 % 1095310711U;
        if (num2 != 0)
        {
          num1 = num3 ^ 1311637715U;
          if (924528678U >> (int) num1 == 0U)
          {
            Type genericTypeDefinition = type1.GetGenericTypeDefinition();
            uint num4 = 1032065181U | num1;
            Type type2 = typeof (Nullable<>);
            num3 = 1495546985U / num4 + 676898700U;
            if ((object) genericTypeDefinition == (object) type2)
            {
              uint num5 = num3 % 264967193U;
              string name1 = _param1.Name;
              uint num6 = 233202754U & num5;
              int num7 = (int) num6 - 146957374;
              uint num8;
              if (string.Equals(name1, "get_HasValue", (StringComparison) num7))
              {
                num1 = 1150841347U * num6;
                if (num1 != 1992690268U)
                {
                  ref object local1 = ref _param3;
                  uint num9 = num1 / 389496125U;
                  object obj = _param2;
                  uint num10 = 1882065191U / num9;
                  int num11 = obj > null ? 1 : 0;
                  num8 = 543827907U ^ num10;
                  // ISSUE: variable of a boxed type
                  __Boxed<bool> local2 = (ValueType) (bool) num11;
                  local1 = (object) local2;
                }
                else
                  goto label_1;
              }
              else
              {
                uint num9 = 613027766U % num6;
                MethodBase methodBase1 = _param1;
                uint num10 = num9 | 552670983U;
                string name2 = methodBase1.Name;
                uint num11 = 920481678U >> (int) num10;
                int num12 = (int) num11 ^ 28094;
                num1 = 1333402517U * num11;
                if (string.Equals(name2, "get_Value", (StringComparison) num12))
                {
                  if (496243426 * (int) num1 != 0)
                  {
                    object obj1 = _param2;
                    num1 = 1125646503U << (int) num1;
                    if (obj1 == null)
                    {
                      if (((int) num1 ^ 2126015916) != 0)
                        throw new InvalidOperationException();
                      goto label_1;
                    }
                    else
                    {
                      uint num13 = num1 / 293031652U;
                      ref object local = ref _param3;
                      object obj2 = _param2;
                      num1 = 464921429U << (int) num13;
                      local = obj2;
                      if (590495384U > num1)
                        num8 = num1 + 314164114U;
                      else
                        goto label_1;
                    }
                  }
                  else
                    goto label_1;
                }
                else
                {
                  num1 ^= 2043575870U;
                  if (2142187268 - (int) num1 != 0)
                  {
                    MethodBase methodBase2 = _param1;
                    uint num13 = num1 * 768423609U;
                    string name3 = methodBase2.Name;
                    uint num14 = 2133272519U << (int) (1314731989U + num13);
                    int num15 = (int) num14 ^ 1334706180;
                    int num16 = name3.Equals("GetValueOrDefault", (StringComparison) num15) ? 1 : 0;
                    num8 = num14 ^ 1642194663U;
                    if (num16 != 0)
                    {
                      uint num17 = 1301677724U >> (int) num8;
                      if (_param2 == null)
                      {
                        MethodBase methodBase3 = _param1;
                        uint num18 = 375934980U ^ num17;
                        Type underlyingType = Nullable.GetUnderlyingType(methodBase3.DeclaringType);
                        uint num19 = 1784417785U & num18;
                        _param2 = Activator.CreateInstance(underlyingType);
                        num17 = num19 + 4266336260U;
                      }
                      _param3 = _param2;
                      num8 = num17 + 768916186U;
                    }
                  }
                  else
                    goto label_1;
                }
              }
              return (int) (num8 | 69563324U) - 779089918 != 0;
            }
          }
          else
            continue;
        }
        return ((int) num3 ^ 676898700) != 0;
      }
      goto label_1;
    }
    return (int) (num1 / 821236602U) - 2 != 0;
  }

  private \u0031C561093.\u00304BE210E \u0034B1A622E(MethodBase _param1, bool _param2)
  {
label_0:
    MethodInfo methodInfo1 = _param1 as MethodInfo;
label_1:
    MethodBase methodBase1 = _param1;
    uint num1 = 2013362550;
    ParameterInfo[] parameters1 = methodBase1.GetParameters();
    uint num2 = 1829989218U - num1;
    if (((int) num2 & 1928531530) != 0)
    {
label_2:
      Dictionary<int, \u0031C561093.\u00304BE210E> dictionary1;
      object[] objArray1;
      \u0031C561093.\u00304BE210E obj1;
      object obj2;
      object obj3;
      uint num3;
      do
      {
        Dictionary<int, \u0031C561093.\u00304BE210E> dictionary2 = new Dictionary<int, \u0031C561093.\u00304BE210E>();
        uint num4 = 262411733U | num2;
        dictionary1 = dictionary2;
        if (num4 >= 875106988U)
        {
label_3:
          ParameterInfo[] parameterInfoArray1 = parameters1;
          uint num5 = num4 | 779570215U;
          int length = parameterInfoArray1.Length;
          uint num6 = num5 & 1405943867U;
          objArray1 = new object[length];
          if (num6 >= 960102400U)
          {
            ParameterInfo[] parameterInfoArray2 = parameters1;
            uint num7 = num6 ^ 1726354420U;
            uint num8;
            for (int index1 = parameterInfoArray2.Length - ((int) num7 - 891491278); index1 >= (int) num7 - 891491279; num7 = num8 ^ 891491279U)
            {
              uint num9 = 953767699;
              \u0031C561093.\u00304BE210E obj4 = this.\u003253508E5();
              \u0031C561093.\u00304BE210E obj5 = obj4;
              uint num10 = num9 - 1781285672U;
              int num11 = obj5.\u0036736EEEA() ? 1 : 0;
              num4 = 416503060U << (int) num10;
              if (num11 != 0)
              {
                uint num12 = num4 & 1914133103U;
                if (num12 < 923618292U)
                {
                  Dictionary<int, \u0031C561093.\u00304BE210E> dictionary3 = dictionary1;
                  int key = index1;
                  uint num13 = num12 >> 18;
                  \u0031C561093.\u00304BE210E obj6 = obj4;
                  uint num14 = num13 & 1240277373U;
                  dictionary3[key] = obj6;
                  num4 = num14 + 2594742272U;
                }
                else
                  goto label_1;
              }
              if (num4 > 2111771525U)
              {
                object[] objArray2 = objArray1;
                int index2 = index1;
                \u0031C561093.\u00304BE210E obj6 = obj4;
                uint num12 = num4 * 581140042U;
                ParameterInfo[] parameterInfoArray3 = parameters1;
                int index3 = index1;
                uint num13 = 624649875U * num12;
                ParameterInfo parameterInfo = parameterInfoArray3[index3];
                uint num14 = 1585325097U / num13;
                Type parameterType = parameterInfo.ParameterType;
                object obj7 = this.\u0031152448F((object) obj6, parameterType).\u0035F319DE0();
                uint num15 = 728836851U | num14;
                objArray2[index2] = obj7;
                uint num16 = num15 >> 27;
                int num17 = index1;
                num8 = num16 / 1530875189U;
                int num18 = (int) num8 ^ 1;
                index1 = num17 - num18;
              }
              else
                goto label_3;
            }
            uint num19 = 396649679U / num7;
            int num20 = _param1.IsStatic ? 1 : 0;
            uint num21 = 1353148314U >> (int) num19;
            \u0031C561093.\u00304BE210E obj8;
            if (num20 == 0)
            {
              if (num21 <= 1726110702U)
                obj8 = this.\u003253508E5();
              else
                goto label_0;
            }
            else
            {
              obj8 = (\u0031C561093.\u00304BE210E) null;
              num21 ^= 0U;
            }
            obj1 = obj8;
            uint num22 = num21 + 1087322968U;
            uint num23;
            object obj9;
            if (obj1 == null)
            {
              num23 = 155461358U / num22;
              obj9 = (object) null;
            }
            else
            {
              obj9 = obj1.\u0035F319DE0();
              num23 = num22 ^ 2440471282U;
            }
            if (obj9 == null)
            {
              uint num9 = num23 % 1110727314U;
              if ((293012717 & (int) num9) == 0)
              {
                num23 = num9 + 0U;
                obj9 = (object) null;
              }
              else
                goto label_0;
            }
            obj2 = obj9;
            uint num24 = num23 ^ 136711252U;
            if (_param2)
            {
              if ((int) num24 - 1260342079 != 0)
              {
                object obj4 = obj2;
                num24 += 0U;
                if (obj4 == null)
                  throw new NullReferenceException();
              }
              else
                goto label_0;
            }
            uint num25 = 619713271U ^ num24;
            obj3 = (object) null;
            uint num26 = 639132395U & num25;
            int num27 = _param1.IsConstructor ? 1 : 0;
            uint num28 = num26 & 1871657113U;
            if (num27 != 0)
            {
              uint num9 = num28 | 184899488U;
              Type declaringType1 = _param1.DeclaringType;
              uint num10 = num9 ^ 1329819967U;
              int num11 = declaringType1.IsValueType ? 1 : 0;
              num28 = num10 << 12 ^ 1181343873U;
              if (num11 != 0)
              {
                uint num12 = num28 | 292378979U;
                if (num12 < 2141942155U)
                {
                  MethodBase methodBase2 = _param1;
                  uint num13 = num12 + 788823705U;
                  Type declaringType2 = methodBase2.DeclaringType;
                  uint num14 = 75046651U | num13;
                  object[] objArray2 = objArray1;
                  uint num15 = num14 | 627327651U;
                  object instance = Activator.CreateInstance(declaringType2, objArray2);
                  if ((588646046 ^ (int) num15) != 0)
                  {
                    \u0031C561093.\u00304BE210E obj4 = obj1;
                    num3 = 955986659U + num15;
                    if (obj4 != null)
                    {
                      uint num16 = 1940939720U - num3;
                      if (395410365 << (int) num16 != 0)
                      {
                        \u0031C561093.\u00304BE210E obj5 = obj1;
                        uint num17 = num16 | 357331076U;
                        int num18 = obj5.\u0036736EEEA() ? 1 : 0;
                        num3 = num17 + 2145403591U ^ 3408307535U;
                        if (num18 != 0)
                        {
                          if ((683623117 ^ (int) num3) != 0)
                          {
                            \u0031C561093.\u00304BE210E obj6 = obj1;
                            uint num29 = 1839945787U & num3;
                            object obj7 = instance;
                            uint num30 = num29 + 1931351417U;
                            Type declaringType3 = _param1.DeclaringType;
                            uint num31 = num30 | 1552372909U;
                            \u0031C561093.\u00304BE210E obj10 = this.\u0031152448F(obj7, declaringType3);
                            uint num32 = num31 & 1031423914U;
                            object obj11 = obj10.\u0035F319DE0();
                            uint num33 = 1993681623U / num32;
                            obj6.\u0036DCE2291(obj11);
                            if (362574040U > num33)
                            {
                              num3 = num33 + 2658734561U;
                              goto label_91;
                            }
                            else
                              goto label_1;
                          }
                          else
                            goto label_0;
                        }
                        else
                          goto label_91;
                      }
                      else
                        goto label_1;
                    }
                    else
                      goto label_91;
                  }
                  else
                    goto label_1;
                }
                else
                  goto label_1;
              }
            }
            uint num34 = (1053561878U << (int) num28) - 1319066433U;
            MethodBase methodBase3 = _param1;
            uint num35 = 1400922567U * num34;
            object obj12 = obj2;
            uint num36 = num35 >> 5;
            ref object local = ref obj3;
            object[] objArray3 = objArray1;
            uint num37 = 2045073238U + num36;
            int num38 = this.\u003454821D7(methodBase3, obj12, ref local, objArray3) ? 1 : 0;
            num3 = num37 + 555177951U;
            if (num38 == 0)
            {
              if (!_param2)
                num2 = 1807578220U | num3;
              else
                goto label_90;
            }
            else
              goto label_91;
          }
          else
            goto label_0;
        }
        else
          goto label_1;
      }
      while (2048852171U == num2);
      int num39 = _param1.IsVirtual ? 1 : 0;
      num3 = num2 + 2658900980U;
      if (num39 != 0)
      {
        if (340354036U < num3)
        {
          MethodBase methodBase2 = _param1;
          uint num4 = num3 + 1275863942U;
          int num5 = methodBase2.IsFinal ? 1 : 0;
          num3 = 1059609078U - num4 + 1238756692U;
          if (num5 == 0)
          {
            ParameterInfo[] parameterInfoArray1 = parameters1;
            uint num6 = num3 ^ 516238272U;
            int length1 = parameterInfoArray1.Length;
            int num7 = (int) num6 ^ -2135147997;
            uint num8 = 885523475U ^ num6;
            int length2 = length1 + num7;
            uint num9 = 284043990U - num8;
            object[] objArray2 = new object[length2];
            uint num10 = num9 + 858154169U;
            object[] parameters2 = objArray2;
            object[] objArray3 = parameters2;
            uint num11 = num10 >> 20;
            int index1 = (int) num11 ^ 2298;
            object obj4 = obj2;
            uint num12 = num11 / 567875413U;
            objArray3[index1] = obj4;
            uint num13 = num12 >> 22;
            int num14 = (int) num13 ^ 0;
            if (num13 < 1210850578U)
            {
              uint num15;
              while (true)
              {
                uint num16 = num13 * 560299196U;
                int num17 = num14;
                int length3 = parameters1.Length;
                uint num18 = num16 >> 30;
                int num19 = length3;
                num15 = num18 & 1432640891U;
                if (num17 < num19)
                {
                  uint num20 = 1756569374;
                  if (num20 >= 139397165U)
                  {
                    object[] objArray4 = parameters2;
                    int num21 = num14;
                    uint num22 = 1911822688U << (int) num20;
                    int num23 = (int) num22 + 1;
                    uint num24 = 1857041076U ^ num22;
                    int index2 = num21 + num23;
                    object[] objArray5 = objArray1;
                    int index3 = num14;
                    uint num25 = num24 << 10;
                    object obj5 = objArray5[index3];
                    uint num26 = num25 << 2;
                    objArray4[index2] = obj5;
                    num2 = num26 << 13;
                    if (1392010438 - (int) num2 != 0)
                    {
                      int num27 = num14;
                      uint num28 = 213474433U | num2;
                      int num29 = (int) num28 - 1824087168;
                      uint num30 = num28 - 449249597U;
                      int num31 = num27 + num29;
                      uint num32 = 2013490133U << (int) num30;
                      num14 = num31;
                      num13 = num32 + 2143896240U;
                    }
                    else
                      goto label_2;
                  }
                  else
                    goto label_1;
                }
                else
                  break;
              }
              uint num33 = 1635987038U + num15;
              Dictionary<MethodBase, DynamicMethod> dictionary2 = \u0031C561093.\u003696E132D;
              Dictionary<MethodBase, DynamicMethod> dictionary3 = dictionary2;
              uint num34 = num33 ^ 367791786U;
              Monitor.Enter((object) dictionary3);
              DynamicMethod dynamicMethod1;
              try
              {
                uint num16 = num34 % 2099538500U;
                if (828320145U == num16)
                  goto label_51;
label_48:
                Dictionary<MethodBase, DynamicMethod> dictionary4 = \u0031C561093.\u003696E132D;
                MethodBase key1 = _param1;
                uint num17 = 1622546704U << (int) num16;
                ref DynamicMethod local = ref dynamicMethod1;
                num16 = num17 ^ 924989894U;
                if (!dictionary4.TryGetValue(key1, out local))
                {
                  if (1937186010U > num16)
                    goto label_51;
                }
                else
                  goto label_77;
label_50:
                int length3 = parameters2.Length;
                num16 = 975338469U % num16;
                Type[] typeArray1 = new Type[length3];
                if (1612663271U == num16)
                  goto label_52;
label_51:
                Type[] typeArray2 = typeArray1;
                int index2 = (int) num16 ^ 975338469;
                MethodBase methodBase3 = _param1;
                uint num18 = 1717859524U | num16;
                Type declaringType = methodBase3.DeclaringType;
                num16 = 633493071U >> (int) num18;
                typeArray2[index2] = declaringType;
label_52:
                uint num19 = 521229639U & num16;
                int num20 = (int) num19 ^ 16781314;
                num16 = 2085364289U - num19;
                int num21 = num20;
                while (217985770 << (int) num16 == 0)
                {
                  int num22 = num21;
                  ParameterInfo[] parameterInfoArray2 = parameters1;
                  uint num23 = num16 - 201926733U;
                  int length4 = parameterInfoArray2.Length;
                  uint num24 = 956638071U / num23;
                  if (num22 < length4)
                  {
                    num16 = 110239870U;
                    if (258544489U >= num16)
                    {
                      Type[] typeArray3 = typeArray1;
                      int num25 = num21;
                      uint num26 = num16 - 769556109U;
                      int num27 = (int) num26 + 659316240;
                      int index3 = num25 + num27;
                      uint num28 = num26 % 1373781021U;
                      ParameterInfo[] parameterInfoArray3 = parameters1;
                      int index4 = num21;
                      num16 = num28 + 1213539131U;
                      Type parameterType = parameterInfoArray3[index4].ParameterType;
                      typeArray3[index3] = parameterType;
                      if (1945588723U < num16)
                      {
                        num21 += (int) num16 ^ 2101628147;
                        num16 ^= 101211853U;
                      }
                      else
                        goto label_48;
                    }
                    else
                      break;
                  }
                  else
                  {
                    Type returnType1;
                    if ((object) methodInfo1 != null)
                    {
                      Type returnType2 = methodInfo1.ReturnType;
                      uint num25 = 300307517U ^ num24;
                      // ISSUE: type reference
                      RuntimeTypeHandle handle = __typeref (void);
                      uint num26 = num25 ^ 1857753836U;
                      Type typeFromHandle = Type.GetTypeFromHandle(handle);
                      if ((object) returnType2 == (object) typeFromHandle)
                      {
                        num24 = num26 ^ 2136819409U;
                      }
                      else
                      {
                        MethodInfo methodInfo2 = methodInfo1;
                        uint num27 = 126617631U & num26;
                        Type returnType3 = methodInfo2.ReturnType;
                        num24 = num27 ^ 118226961U;
                        returnType1 = returnType3;
                        goto label_63;
                      }
                    }
                    returnType1 = (Type) null;
label_63:
                    uint num28 = 1728146434U + num24;
                    Type[] parameterTypes = typeArray1;
                    // ISSUE: type reference
                    RuntimeTypeHandle handle1 = __typeref (\u0031C561093);
                    uint num29 = 767250257U + num28;
                    Type typeFromHandle1 = Type.GetTypeFromHandle(handle1);
                    uint num30 = num29 * 1085427123U;
                    Module module = typeFromHandle1.Module;
                    uint num31 = num30 << 17;
                    int num32 = (int) num31 + 468582401;
                    num16 = num31 + 1797602483U;
                    dynamicMethod1 = new DynamicMethod("", returnType1, parameterTypes, module, num32 != 0);
                    if (((int) num16 ^ 1029517270) != 0)
                    {
                      DynamicMethod dynamicMethod2 = dynamicMethod1;
                      uint num25 = num16 ^ 664559917U;
                      ILGenerator ilGenerator1 = dynamicMethod2.GetILGenerator();
                      uint num26 = num25 | 1186270311U;
                      ILGenerator ilGenerator2 = ilGenerator1;
                      uint num27 = 1832921248U & num26;
                      ILGenerator ilGenerator3 = ilGenerator2;
                      int num35 = obj1.\u0036736EEEA() ? 1 : 0;
                      uint num36 = 158672236U - num27;
                      OpCode opcode1;
                      if (num35 == 0)
                      {
                        opcode1 = OpCodes.Ldarg;
                      }
                      else
                      {
                        uint num37 = num36 / 2032077448U;
                        opcode1 = OpCodes.Ldarga;
                        num36 = num37 + 2641697995U;
                      }
                      uint num38 = 1899692662U & num36;
                      int num40 = (int) num38 ^ 288424004;
                      ilGenerator3.Emit(opcode1, num40);
                      uint num41 = 1982988629U ^ num38;
                      int num42 = (int) num41 ^ 1728250128;
                      num16 = 944375680U / num41;
                      int num43 = num42;
                      if (1630733633U > num16)
                      {
                        uint num37;
                        for (; num16 < 974352924U; num16 = num37 ^ 0U)
                        {
                          int num44 = num43;
                          uint num45 = num16 << 25;
                          Type[] typeArray3 = typeArray1;
                          uint num46 = 2108505365U + num45;
                          int length5 = typeArray3.Length;
                          uint num47 = num46 % 1621653577U;
                          int num48 = length5;
                          num16 = num47 << 10;
                          if (num44 < num48)
                          {
                            ILGenerator ilGenerator4 = ilGenerator2;
                            Dictionary<int, \u0031C561093.\u00304BE210E> dictionary5 = dictionary1;
                            uint num49 = 2049974783;
                            int key2 = num43 - ((int) num49 ^ 2049974782);
                            OpCode opcode2;
                            if (!dictionary5.ContainsKey(key2))
                            {
                              opcode2 = OpCodes.Ldarg;
                            }
                            else
                            {
                              opcode2 = OpCodes.Ldarga;
                              num49 ^= 0U;
                            }
                            num37 = 1307645763U / num49;
                            int num50 = num43;
                            ilGenerator4.Emit(opcode2, num50);
                            num43 += (int) num37 - -1;
                          }
                          else if (1176244253U > num16)
                          {
                            ILGenerator ilGenerator4 = ilGenerator2;
                            uint num49 = num16 - 79974591U;
                            OpCode call = OpCodes.Call;
                            uint num50 = num49 - 1143633138U;
                            MethodInfo meth = methodInfo1;
                            uint num51 = 1515530283U & num50;
                            ilGenerator4.Emit(call, meth);
                            num16 = num51 | 77429473U;
                            ilGenerator2.Emit(OpCodes.Ret);
                            if (370619227U != num16)
                            {
                              Dictionary<MethodBase, DynamicMethod> dictionary5 = \u0031C561093.\u003696E132D;
                              uint num52 = 1509771679U & num16;
                              MethodBase key2 = _param1;
                              DynamicMethod dynamicMethod3 = dynamicMethod1;
                              dictionary5[key2] = dynamicMethod3;
                              num16 = num52 + 1568993595U;
                              goto label_77;
                            }
                            else
                              goto label_48;
                          }
                          else
                            goto label_48;
                        }
                        break;
                      }
                      break;
                    }
                  }
                }
                goto label_50;
label_77:
                if (num16 < 1459177081U)
                  goto label_48;
              }
              finally
              {
                Monitor.Exit((object) dictionary2);
              }
              uint num53 = 948505807;
              if (num53 != 1000108527U)
              {
                object obj5 = dynamicMethod1.Invoke((object) null, parameters2);
                uint num16 = 1010517405U ^ num53;
                obj3 = obj5;
                num53 = 1443067443U - num16;
              }
              Dictionary<int, \u0031C561093.\u00304BE210E> dictionary6 = dictionary1;
              uint num54 = 1224622579U & num53;
              Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator enumerator1 = dictionary6.GetEnumerator();
              uint num55 = 697453103U ^ num54;
              Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator enumerator2 = enumerator1;
              try
              {
                uint num16;
                do
                {
                  for (; num55 <= 1100231861U || enumerator2.MoveNext(); num55 = num16 ^ 1767985862U)
                  {
                    uint num17 = 12728792;
                    ref Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator local1 = ref enumerator2;
                    uint num18 = 273564597U % num17;
                    KeyValuePair<int, \u0031C561093.\u00304BE210E> current = local1.Current;
                    uint num19 = 703924098U / num18;
                    KeyValuePair<int, \u0031C561093.\u00304BE210E> keyValuePair = current;
                    uint num20 = num19 + 1026784719U;
                    \u0031C561093.\u00304BE210E obj5 = keyValuePair.Value;
                    uint num21 = num20 ^ 2036032826U;
                    object[] objArray4 = parameters2;
                    uint num22 = 26755192U % num21;
                    ref KeyValuePair<int, \u0031C561093.\u00304BE210E> local2 = ref keyValuePair;
                    uint num23 = num22 + 538211916U;
                    int index2 = local2.Key + ((int) num23 - 564967107);
                    uint num24 = num23 + 687277316U;
                    object obj6 = objArray4[index2];
                    num16 = num24 & 548101132U;
                    obj5.\u0036DCE2291(obj6);
                  }
                }
                while (num55 >> 27 == 0U);
              }
              finally
              {
                uint num16;
                do
                {
                  num16 = 748255018U;
                  if (num16 <= 2046364239U)
                    enumerator2.Dispose();
                  else
                    break;
                }
                while (num16 > 1891197493U);
              }
              dictionary1.Clear();
              num3 = 2658734562U;
              goto label_91;
            }
            else
              goto label_0;
          }
        }
        else
          goto label_0;
      }
label_90:
      MethodBase methodBase4 = _param1;
      uint num56 = 1133599177U & num3;
      object obj13 = obj2;
      uint num57 = 1456815445U * num56;
      object[] parameters3 = objArray1;
      uint num58 = num57 << 24;
      obj3 = methodBase4.Invoke(obj13, parameters3);
      num3 = num58 ^ 1584992738U;
label_91:
      uint num59 = num3 | 481364045U;
      Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator enumerator = dictionary1.GetEnumerator();
      uint num60;
      try
      {
        while (true)
        {
          do
          {
            uint num4 = num59 - 980707367U;
            ref Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator local = ref enumerator;
            num60 = 1295149668U + num4;
            if (local.MoveNext())
              num59 = 647917295U;
            else
              goto label_99;
          }
          while (num59 == 1114203546U);
          ref Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator local1 = ref enumerator;
          uint num5 = 1527671460U + num59;
          KeyValuePair<int, \u0031C561093.\u00304BE210E> current = local1.Current;
          \u0031C561093.\u00304BE210E obj4 = current.Value;
          uint num6 = 540084853U / num5;
          object[] objArray2 = objArray1;
          uint num7 = num6 + 2130672472U;
          int key = current.Key;
          uint num8 = num7 / 1408965784U;
          object obj5 = objArray2[key];
          obj4.\u0036DCE2291(obj5);
          num59 = num8 ^ 2667125230U;
        }
      }
      finally
      {
        uint num4 = 43979124;
        if (1153838068U != num4)
        {
          ref Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator local = ref enumerator;
          num60 = num4 & 1637095516U;
          local.Dispose();
        }
      }
label_99:
      uint num61;
      do
      {
        MethodInfo methodInfo2 = methodInfo1;
        num61 = 44064127U;
        if ((object) methodInfo2 != null)
        {
          MethodInfo methodInfo3 = methodInfo1;
          uint num4 = 896749544U + num61;
          Type returnType = methodInfo3.ReturnType;
          uint num5 = num4 * 2075614267U;
          // ISSUE: type reference
          RuntimeTypeHandle handle = __typeref (void);
          uint num6 = num5 - 2048948241U;
          Type typeFromHandle = Type.GetTypeFromHandle(handle);
          if ((object) returnType == (object) typeFromHandle)
          {
            num61 = num6 ^ 4110082003U;
          }
          else
          {
            num61 = num6 << 28;
            if (1134957552U < num61)
              goto label_105;
          }
        }
      }
      while (434707932U <= num61);
      return (\u0031C561093.\u00304BE210E) null;
label_105:
      object obj14 = obj3;
      MethodInfo methodInfo4 = methodInfo1;
      uint num62 = 831327709U * num61;
      Type returnType4 = methodInfo4.ReturnType;
      num60 = num62 ^ 2083420958U;
      return this.\u0031152448F(obj14, returnType4);
    }
    goto label_0;
  }

  private \u0031C561093.\u00304BE210E \u0033544403E(int _param1, bool _param2)
  {
label_0:
    Dictionary<int, \u0031C561093.\u00304BE210E> dictionary1;
    object[] objArray1;
    int num1;
    uint num2;
    do
    {
      uint num3 = 1809659322;
      int num4 = this.\u0035E5D486B;
      if (847140593U % num3 == 0U)
        goto label_2;
label_1:
      this.\u0035E5D486B = _param1;
      num3 = 361700889U - num3;
label_2:
      uint num5 = 1039361256U >> (int) num3;
      int num6 = (int) this.\u003514C63E6();
      uint num7 = num5 >> 20;
      int num8 = (int) (ushort) num6;
      uint num9 = 1599737106U & num7;
      ushort num10 = (ushort) num8;
      num3 = 1154682382U << (int) num9;
      if (num3 < 1847817408U)
      {
label_3:
        dictionary1 = new Dictionary<int, \u0031C561093.\u00304BE210E>();
        objArray1 = (object[]) null;
        uint num11 = num3 | 384173788U;
        int num12 = (int) num10;
        uint num13 = num11 & 2135039679U;
        int num14 = (int) num13 ^ 1447169694;
        uint num15 = 1668635966U << (int) num13;
        if (num12 > num14)
        {
          num3 = 2077651930U >> (int) num15;
          if ((570824274 & (int) num3) != 0)
          {
            int length = (int) num10;
            uint num16 = num3 * 797192246U;
            objArray1 = new object[length];
            if ((int) num16 * 525735784 != 0)
            {
label_6:
              int num17 = (int) num10;
              int num18 = (int) num16 - 391991291;
              num3 = num16 << 3;
              int num19 = num17 - num18;
              if (((int) num3 ^ 1772428085) != 0)
              {
                while (true)
                {
                  if (num3 > 1655051362U)
                  {
                    if (num19 >= (int) num3 - -1159036960)
                    {
                      num3 = 227151404U;
                      if ((1552888321 ^ (int) num3) != 0)
                      {
                        uint num20 = 1313037982U / num3;
                        \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
                        \u0031C561093.\u00304BE210E obj2 = obj1;
                        uint num21 = 255530008U ^ num20;
                        if (obj2.\u0036736EEEA())
                        {
                          uint num22 = 1276800547U - num21;
                          Dictionary<int, \u0031C561093.\u00304BE210E> dictionary2 = dictionary1;
                          uint num23 = 639728433U - num22;
                          int key = num19;
                          \u0031C561093.\u00304BE210E obj3 = obj1;
                          uint num24 = num23 ^ 946627469U;
                          dictionary2[key] = obj3;
                          num21 = num24 + 1041027447U;
                        }
                        num3 = 786318336U ^ num21;
                        if (280915897U != num3)
                        {
                          object[] objArray2 = objArray1;
                          uint num22 = num3 - 1944480754U;
                          int index = num19;
                          uint num23 = (850611901U + num22) % 1212900762U;
                          \u0031C561093.\u00304BE210E obj3 = obj1;
                          uint num24 = 1556894897U - num23 - 957554584U;
                          int num25 = this.\u0033D5821EF();
                          uint num26 = num24 << 1;
                          Type type = this.\u0033CE71CC6(num25);
                          uint num27 = 908423349U * num26;
                          object obj4 = this.\u0031152448F((object) obj3, type).\u0035F319DE0();
                          uint num28 = num27 * 764693564U;
                          objArray2[index] = obj4;
                          num16 = 105583008U % num28;
                          if (num16 < 1390503050U)
                          {
                            int num29 = num19;
                            int num30 = (int) num16 - 105583007;
                            uint num31 = 1887323805U / num16;
                            num19 = num29 - num30;
                            num3 = num31 ^ 3135930353U;
                          }
                          else
                            goto label_6;
                        }
                        else
                          goto label_2;
                      }
                      else
                        goto label_3;
                    }
                    else
                      break;
                  }
                  else
                    goto label_0;
                }
                num15 = num3 ^ 988446688U;
              }
              else
                goto label_1;
            }
            else
              continue;
          }
          else
            goto label_2;
        }
        uint num32 = 866676557U % num15;
        int num33 = this.\u0033D5821EF();
        uint num34 = 1203592009U / num32;
        num1 = num33;
        uint num35 = 1150831841U >> (int) num34 ^ 1665891031U;
        int num36 = this.\u0035E5D486B;
        num3 = 1458585181U - num35;
        _param1 = num36;
        if (num3 <= 1995445791U)
        {
          int num16 = num4;
          uint num17 = num3 * 2097421289U;
          this.\u0035E5D486B = num16;
          int num18 = _param2 ? 1 : 0;
          num2 = 1758883939U & num17;
          if (num18 != 0)
          {
            if (1776643017U % num2 != 0U)
            {
              object[] objArray2 = objArray1;
              uint num19 = num2 & 21972069U;
              if (objArray2 != null)
              {
                object[] objArray3 = objArray1;
                uint num20 = 1083379330U >> (int) num19;
                int index = (int) num20 - 1083379330;
                uint num21 = num20 ^ 1855651874U;
                object obj = objArray3[index];
                num2 = num21 ^ 1318727298U;
                if (obj == null)
                  num19 = num2 ^ 1620058114U;
                else
                  goto label_24;
              }
              if (num19 != 1270903048U)
                throw new NullReferenceException();
              continue;
            }
            continue;
          }
label_24:;
        }
        else
          goto label_1;
      }
      else
        goto label_1;
    }
    while (423257668U == num2);
    \u0031C561093 obj5 = new \u0031C561093();
    object[] objArray4 = objArray1;
    int num37 = _param1;
    uint num38 = 196870436U - num2;
    object obj6 = obj5.\u00335B818BE(objArray4, num37);
    uint num39 = num38 - 1423066288U;
    Dictionary<int, \u0031C561093.\u00304BE210E> dictionary3 = dictionary1;
    uint num40 = 13056655U + num39;
    Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator enumerator1 = dictionary3.GetEnumerator();
    uint num41 = num40 % 1878278028U;
    Dictionary<int, \u0031C561093.\u00304BE210E>.Enumerator enumerator2 = enumerator1;
    try
    {
      if (num41 < 1754730460U)
      {
        while (true)
        {
          do
          {
            num41 >>= 7;
          }
          while (((int) num41 ^ 112739530) == 0);
          if (enumerator2.MoveNext())
          {
            KeyValuePair<int, \u0031C561093.\u00304BE210E> current = enumerator2.Current;
            uint num3 = 1025906202;
            KeyValuePair<int, \u0031C561093.\u00304BE210E> keyValuePair = current;
            uint num4 = 1870033531U >> (int) num3;
            \u0031C561093.\u00304BE210E obj1 = keyValuePair.Value;
            uint num5 = 1561734582U / num4;
            object[] objArray2 = objArray1;
            ref KeyValuePair<int, \u0031C561093.\u00304BE210E> local = ref keyValuePair;
            uint num6 = num5 << 24;
            int key = local.Key;
            object obj2 = objArray2[key];
            obj1.\u0036DCE2291(obj2);
            num41 = num6 + 4062107361U;
          }
          else
            break;
        }
      }
    }
    finally
    {
      uint num3;
      do
      {
        num3 = 1965974427U;
        enumerator2.Dispose();
      }
      while (1316489171U >= num3);
    }
    uint num42;
    do
    {
      num42 = 1673216809U;
      Type type1;
      if (num42 != 58348596U)
      {
        if (num1 != 0)
        {
          int num3 = num1;
          uint num4 = 1741437255U | num42;
          type1 = this.\u0033CE71CC6(num3);
          num42 = num4 - 1401704212U;
        }
        else
          goto label_37;
      }
      Type type2 = type1;
      uint num5 = 1999856617U / num42;
      // ISSUE: type reference
      RuntimeTypeHandle handle = __typeref (void);
      uint num6 = num5 | 219704904U;
      Type typeFromHandle = Type.GetTypeFromHandle(handle);
      num42 = 152985866U / num6 + 1673216809U;
      if ((object) type2 != (object) typeFromHandle)
      {
        object obj1 = obj6;
        uint num3 = num42 >> 2;
        Type type3 = type1;
        return this.\u0031152448F(obj1, type3);
      }
label_37:;
    }
    while (173678518U >> (int) num42 >= 1459320200U);
    return (\u0031C561093.\u00304BE210E) null;
  }

  private bool \u0036B0E3E15(object _param1, Type _param2)
  {
    object obj1 = _param1;
    uint num1 = 1606432100;
    if (obj1 == null)
      return ((int) (1902068630U + num1) ^ -786466565) != 0;
    uint num2;
    Type type1;
    do
    {
      uint num3 = 1357779682U * num1;
      object obj2 = _param1;
      num2 = num3 * 117054704U;
      type1 = obj2.GetType();
      if ((object) type1 != (object) _param2)
        num1 = 1279856819U | num2;
      else
        goto label_6;
    }
    while ((int) num1 + 1314013736 == 0);
    Type type2 = _param2;
    uint num4 = 1581271028U << (int) num1;
    Type c = type1;
    int num5 = type2.IsAssignableFrom(c) ? 1 : 0;
    uint num6 = num4 * 2119833941U;
    if (num5 == 0)
      return (int) num6 + 1071644672 != 0;
    num2 = num6 ^ 548897664U;
label_6:
    return (int) num2 + 526941313 != 0;
  }

  private void \u003668C74B0(Exception _param1)
  {
label_0:
    \u0031C561093.\u0037B071B97 obj1;
    uint num1;
    uint num2;
    do
    {
      uint num3;
      do
      {
        uint num4 = 2086685923;
        this.\u0032B654A18.Clear();
        num3 = num4 * 1520581556U;
      }
      while (702709082U >> (int) num3 == 0U);
label_1:
      uint num5;
      uint num6;
      do
      {
        num5 = num3 >> 17;
        this.\u00370214200.Clear();
        if (1072265196U > num5)
        {
label_2:
          do
          {
            \u0031C561093.\u0037B071B97 obj2 = this.\u00319B82813;
            num5 = 331165282U | num5;
            if (obj2 != null)
              goto label_46;
          }
          while (1992248614U == num5);
label_4:
          uint num4 = 868181343U + num5;
          Exception exception = _param1;
          uint num7 = num4 >> 16;
          this.\u0034B807558 = exception;
          num5 = num7 + 331147374U;
label_46:
          int count1;
          do
          {
            uint num8 = num5 ^ 1890597363U;
            Stack<\u0031C561093.\u0037BC90C3B> objStack1 = this.\u0035EBC5C0D;
            uint num9 = 1792348349U >> (int) num8;
            int count2 = objStack1.Count;
            num6 = num9 << 14;
            if (count2 != 0)
            {
              uint num10 = 621697754;
              if (num10 != 1778347248U)
              {
                Stack<\u0031C561093.\u0037BC90C3B> objStack2 = this.\u0035EBC5C0D;
                uint num11 = 1311842827U / num10;
                List<\u0031C561093.\u0037B071B97> objList1 = objStack2.Peek().\u0033CC40EC4();
                num5 = 2118780074U >> (int) num11;
                uint num12;
                int num13;
                if (this.\u00319B82813 != null)
                {
                  if (num5 != 1590898625U)
                  {
                    List<\u0031C561093.\u0037B071B97> objList2 = objList1;
                    uint num14 = (2103383441U + num5) * 842480541U;
                    \u0031C561093.\u0037B071B97 obj2 = this.\u00319B82813;
                    int num15 = objList2.IndexOf(obj2);
                    num12 = 919807450U << (int) num14;
                    int num16 = (int) num12 - -1829961729;
                    num13 = num15 + num16;
                  }
                  else
                    goto label_2;
                }
                else
                {
                  uint num14 = num5 + 1191011933U;
                  num13 = (int) num14 ^ 1720706951;
                  num12 = num14 + 744298617U;
                }
                uint num17 = num12 | 2109287681U;
                this.\u00319B82813 = (\u0031C561093.\u0037B071B97) null;
                int num18 = num13;
                uint num19;
                while (true)
                {
                  uint num14 = 517948449U ^ num17;
                  if (935814856U / num14 == 0U)
                  {
                    int num15 = num18;
                    List<\u0031C561093.\u0037B071B97> objList2 = objList1;
                    num19 = num14 ^ 999839158U;
                    int count3 = objList2.Count;
                    if (num15 < count3)
                    {
                      uint num16 = 1444615230;
                      List<\u0031C561093.\u0037B071B97> objList3 = objList1;
                      uint num20 = num16 << 7;
                      int index = num18;
                      uint num21 = 1850553925U | num20;
                      obj1 = objList3[index];
                      if ((int) num21 * 28335731 != 0)
                      {
                        \u0031C561093.\u0037B071B97 obj2 = obj1;
                        num3 = num21 - 227162946U;
                        byte num22 = obj2.\u0036ADB41E8();
                        if ((495921449 ^ (int) num3) != 0)
                        {
                          int num23 = (int) num22;
                          uint num24 = 981491650U ^ num3;
                          if (num23 != 0)
                          {
                            uint num25 = num24 | 289946672U;
                            if ((744387752 & (int) num25) != 0)
                            {
                              int num26 = (int) num22;
                              num1 = num25 % 1277584720U;
                              int num27 = (int) num1 - 229055136;
                              if (num26 == num27)
                                goto label_26;
                            }
                            else
                              goto label_0;
                          }
                          else
                          {
                            Type type1 = _param1.GetType();
                            uint num25 = 1785098234U / num24;
                            Type type2 = type1;
                            num3 = num25 % 2125472764U;
                            if (num3 < 1359768572U)
                            {
                              int num26 = obj1.\u00358DF7A35();
                              uint num27 = 832386159U & num3;
                              Type type3 = this.\u0033CE71CC6(num26);
                              uint num28 = 789257205U << (int) num27;
                              Type c = type3;
                              num5 = 232022590U - num28;
                              if (466430947U <= num5)
                              {
                                Type type4 = type2;
                                uint num29 = 693119508U + num5;
                                Type type5 = c;
                                num5 = num29 << 29;
                                if ((object) type4 != (object) type5)
                                {
                                  if (1929324377 << (int) num5 != 0)
                                  {
                                    int num30 = type2.IsSubclassOf(c) ? 1 : 0;
                                    num1 = num5 / 964494740U ^ 229055137U;
                                    if (num30 != 0)
                                      goto label_22;
                                  }
                                  else
                                    goto label_2;
                                }
                                else
                                  goto label_23;
                              }
                              else
                                goto label_4;
                            }
                            else
                              goto label_1;
                          }
                          uint num31 = num1 * 1905553801U;
                          if (((int) num31 ^ 1126980036) != 0)
                          {
                            int num25 = num18;
                            uint num26 = 464538493U ^ num31;
                            int num27 = (int) num26 ^ -1661855147;
                            uint num28 = 982788269U / num26;
                            int num29 = num25 + num27;
                            uint num30 = 672359293U << (int) num28;
                            num18 = num29;
                            num17 = num30 ^ 3622719100U;
                          }
                          else
                            goto label_0;
                        }
                        else
                          goto label_1;
                      }
                      else
                        goto label_0;
                    }
                    else
                      break;
                  }
                  else
                    goto label_0;
                }
                num3 = 1206135280U >> (int) num19;
                if (num3 < 1675305042U)
                {
                  uint num14 = num3 | 60837350U;
                  this.\u0035EBC5C0D.Pop();
                  uint num15 = num14 << 0;
                  if (1438284631U != num15)
                  {
                    int count3 = objList1.Count;
                    uint num16 = 1277698987U + num15;
                    int num20 = count3;
                    uint num21;
                    while (true)
                    {
                      uint num22 = 630488519U % num16;
                      int num23 = num20;
                      int num24 = (int) num22 - 630488519;
                      num21 = 145178780U + num22;
                      if (num23 > num24)
                      {
                        List<\u0031C561093.\u0037B071B97> objList2 = objList1;
                        uint num25 = 2105412985;
                        int index = num20 - ((int) num25 - 2105412984);
                        \u0031C561093.\u0037B071B97 obj2 = objList2[index];
                        uint num26 = 921840766U + num25;
                        \u0031C561093.\u0037B071B97 obj3 = obj2;
                        \u0031C561093.\u0037B071B97 obj4 = obj3;
                        uint num27 = 605881172U / num26;
                        int num28 = (int) obj4.\u0036ADB41E8();
                        int num29 = (int) num27 ^ 2;
                        uint num30 = 2073841379U + num27;
                        uint num31;
                        if (num28 != num29)
                        {
                          int num32 = (int) obj3.\u0036ADB41E8();
                          int num33 = (int) num30 - 2073841375;
                          num31 = 1281646002U - num30;
                          if (num32 == num33)
                            num30 = num31 + 2866036756U;
                          else
                            goto label_39;
                        }
                        if (1189243986 - (int) num30 != 0)
                        {
                          uint num32 = 5331844U * num30;
                          Stack<int> intStack = this.\u00370214200;
                          \u0031C561093.\u0037B071B97 obj5 = obj3;
                          uint num33 = 1167546673U | num32;
                          int num34 = obj5.\u00327244D76();
                          intStack.Push(num34);
                          num31 = num33 ^ 2537509362U;
                        }
                        else
                          goto label_0;
label_39:
                        num3 = num31 + 1722701306U;
                        if ((1184196644 ^ (int) num3) != 0)
                        {
                          int num32 = num20;
                          uint num33 = num3 & 1658544414U;
                          int num34 = (int) num33 ^ 575823881;
                          uint num35 = num33 | 422409128U;
                          int num36 = num32 - num34;
                          uint num37 = 428879669U + num35;
                          num20 = num36;
                          num16 = num37 + 4206415565U;
                        }
                        else
                          goto label_1;
                      }
                      else
                        break;
                    }
                    uint num38 = 1953635733U >> (int) num21;
                    if (574426626U != num38)
                    {
                      uint num22 = 2087738669U | num38;
                      Stack<int> intStack = this.\u00370214200;
                      uint num23 = 1175201574U >> (int) num22;
                      count1 = intStack.Count;
                      num5 = 1775460082U + num23 ^ 2054058264U;
                    }
                    else
                      goto label_0;
                  }
                  else
                    goto label_0;
                }
                else
                  goto label_1;
              }
              else
                goto label_0;
            }
            else
              goto label_47;
          }
          while (count1 == 0);
          goto label_44;
label_22:
          num5 = num1 + 4065912159U;
label_23:
          num3 = num5 >> 31;
        }
        else
          goto label_0;
      }
      while (13648909U >> (int) num3 == 0U);
      this.\u0035EBC5C0D.Pop();
      uint num39 = 1924008333U - (1844994929U - num3);
      Stack<\u0031C561093.\u0033AF92E6D> objStack = this.\u0032B654A18;
      Exception exception1 = this.\u0034B807558;
      uint num40 = num39 * 605114546U;
      \u0031C561093.\u00362DF5BD2 obj6 = new \u0031C561093.\u00362DF5BD2((object) exception1);
      num2 = 1941443428U % num40;
      objStack.Push((\u0031C561093.\u0033AF92E6D) obj6);
      continue;
label_44:
      uint num41 = 680536761U / num5;
      if (num41 != 1650809312U)
      {
        uint num4 = num41 % 85013215U;
        Stack<int> intStack = this.\u00370214200;
        num3 = 583689134U + num4;
        this.\u0035E5D486B = intStack.Pop();
        if (776229706U >> (int) num3 == 0U)
          goto label_1;
        else
          goto label_16;
      }
      else
        continue;
label_47:
      num3 = 2017724920U << (int) num6;
      if (833048992U > num3)
        goto label_1;
      else
        goto label_48;
    }
    while ((2007826969 ^ (int) num2) == 0);
    uint num42 = 1016146393U & num2;
    this.\u0035E5D486B = obj1.\u00327244D76();
    return;
label_26:
    \u0031C561093.\u0037B071B97 obj7 = obj1;
    uint num43 = num1 % 1536440656U;
    this.\u00319B82813 = obj7;
    uint num44 = 104102195U * (num43 * 30410363U);
    Stack<\u0031C561093.\u0033AF92E6D> objStack3 = this.\u0032B654A18;
    uint num45 = 657267791U / num44;
    Exception exception2 = this.\u0034B807558;
    uint num46 = 1268399635U * num45;
    \u0031C561093.\u00362DF5BD2 obj8 = new \u0031C561093.\u00362DF5BD2((object) exception2);
    objStack3.Push((\u0031C561093.\u0033AF92E6D) obj8);
    uint num47 = 747319782U - num46 - 15802448U;
    \u0031C561093.\u0037B071B97 obj9 = obj1;
    num42 = 1002181488U << (int) num47;
    this.\u0035E5D486B = obj9.\u00358DF7A35();
    return;
label_16:
    return;
label_48:
    throw _param1;
  }

  private void \u0032F1B1F02()
  {
    uint num1 = 1570070894;
    \u0031C561093.\u00304BE210E obj1;
    \u0031C561093.\u00304BE210E obj2;
    do
    {
      Type type1;
      do
      {
        int num2 = this.\u003253508E5().E2D6F630();
        num1 = 2109423310U * num1;
        type1 = this.\u0033CE71CC6(num2);
      }
      while (1996049173U / num1 == 0U);
      uint num3 = num1 | 451050053U;
      \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
      uint num4 = 81462637U % num3;
      obj1 = obj3;
      uint num5 = 2109932810U - num4;
      object obj4 = this.\u003253508E5().\u0035F319DE0();
      uint num6 = num5 & 1623594941U;
      Type type2 = type1;
      obj2 = this.\u0031152448F(obj4, type2);
      num1 = 1265987484U & num6;
    }
    while (num1 / 361052723U == 0U);
    int num7 = obj1.\u0036736EEEA() ? 1 : 0;
    uint num8 = 349045893U & num1;
    if (num7 != 0)
    {
      uint num2 = num8 + 1588662289U;
      \u0031C561093.\u00304BE210E obj3 = obj2;
      \u0031C561093.\u00304BE210E obj4 = obj1;
      uint num3 = num2 ^ 1963739340U;
      obj2 = (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00371A06EE8(obj3, obj4);
      num8 = num3 + 3561662507U;
    }
    if ((28062220 & (int) num8) == 0)
      return;
    uint num9 = 1771779887U - num8;
    List<\u0031C561093.\u00304BE210E> objList = this.\u00310372FF8;
    uint num10 = 115157024U / num9;
    \u0031C561093.\u00304BE210E obj5 = obj2;
    uint num11 = 1351426745U & num10;
    objList.Add(obj5);
  }

  private void \u00348C31A52()
  {
    uint num1;
    int num2;
    do
    {
      \u0031C561093.\u00304BE210E obj = this.\u003253508E5();
      uint num3 = 1016338278;
      int num4 = obj.E2D6F630();
      num1 = num3 | 553394308U;
      num2 = num4;
    }
    while (1526549895 - (int) num1 == 0);
    List<\u0031C561093.\u0037BC90C3B> objList = this.\u0033B070E12;
    uint num5 = 225342486U + num1;
    List<\u0031C561093.\u0037BC90C3B>.Enumerator enumerator1 = objList.GetEnumerator();
    uint num6 = 1649506183U - num5;
    List<\u0031C561093.\u0037BC90C3B>.Enumerator enumerator2 = enumerator1;
    try
    {
      if (205615604U <= num6)
        goto label_6;
label_3:
      uint num3 = 136120911;
      ref List<\u0031C561093.\u0037BC90C3B>.Enumerator local = ref enumerator2;
      uint num4 = 361528295U + num3;
      \u0031C561093.\u0037BC90C3B current = local.Current;
      uint num7 = num4 + 490085137U;
      \u0031C561093.\u0037BC90C3B obj1 = current;
      num6 = 87060861U * num7;
      if (num6 < 2048863682U)
      {
        \u0031C561093.\u0037BC90C3B obj2 = obj1;
        uint num8 = 1053768759U | num6;
        int num9 = obj2.\u00307744ACD();
        uint num10 = 1141469576U ^ num8;
        int num11 = num2;
        num6 = (138241918U << (int) num10) + 1491520395U;
        if (num9 == num11)
        {
          Stack<\u0031C561093.\u0037BC90C3B> objStack = this.\u0035EBC5C0D;
          uint num12 = num6 | 62550929U;
          \u0031C561093.\u0037BC90C3B obj3 = obj1;
          objStack.Push(obj3);
          num6 = num12 + 4293382128U;
        }
      }
label_6:
      uint num13 = num6 / 412962245U;
      int num14 = enumerator2.MoveNext() ? 1 : 0;
      uint num15 = num13 + 1977175694U;
      if (num14 != 0)
        goto label_3;
    }
    finally
    {
      uint num3;
      do
      {
        ref List<\u0031C561093.\u0037BC90C3B>.Enumerator local = ref enumerator2;
        num3 = 155208993U;
        local.Dispose();
      }
      while ((int) num3 + 1852261200 == 0);
    }
  }

  private void \u00347A16E6D()
  {
    int num1 = this.\u0033D5821EF();
    uint num2 = 1687967076;
    \u0031C561093.\u00348553D81 obj = new \u0031C561093.\u00348553D81(num1);
    uint num3 = num2 + 291199188U;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj);
  }

  private void \u0036FD1447C()
  {
    uint num;
    do
    {
      num = 480214726U;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(this.\u00373564BCC()));
    }
    while (1560552904U <= num);
  }

  private void \u0034D6B2980() => this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u00341173E9D(this.\u0033DDD1100()));

  private void \u0034D8821C6()
  {
    uint num1 = 2136177994;
    if (num1 == 1049952555U)
      return;
    do
    {
      uint num2 = 695999991U / (num1 << 5);
      double num3 = this.\u00308834866();
      uint num4 = num2 << 1;
      \u0031C561093.\u0030A983227 obj = new \u0031C561093.\u0030A983227(num3);
      num1 = num4 - 1032925289U;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj);
    }
    while (((int) num1 ^ 247885887) == 0);
  }

  private void \u00368797CCB()
  {
    uint num1 = 810949348U & (uint) (1277655310 | 1960249755);
    \u0031C561093.\u00362DF5BD2 obj = new \u0031C561093.\u00362DF5BD2((object) null);
    uint num2 = num1 % 1665414896U;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj);
  }

  private void \u0032E881566()
  {
    uint num1 = 1681218165;
    do
    {
      uint num2 = num1 ^ 820391187U;
      int num3 = this.\u003253508E5().E2D6F630();
      uint num4 = 2137869324U ^ num2;
      string str = this.\u00333A9069D(num3);
      uint num5 = num4 - 1489858206U;
      \u0031C561093.\u0036D9D2AA1 obj = new \u0031C561093.\u0036D9D2AA1(str);
      num1 = num5 ^ 1379089601U;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj);
    }
    while (num1 <= 523587356U);
  }

  private void \u00354024839()
  {
    uint num1 = 433731427;
    do
    {
      uint num2 = 1631016885U - num1;
      \u0031C561093.\u00304BE210E obj = this.\u003764760FF();
      num1 = 299109392U + num2;
      this.\u0035FD24B62(obj.\u00321939EB5());
    }
    while (num1 >> 31 != 0U);
  }

  private void \u0037E5F7AB9()
  {
    \u0031C561093.\u00304BE210E obj1;
    uint num1;
    \u0031C561093.\u00304BE210E obj2;
    do
    {
      uint num2 = 1512460862;
      \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
      uint num3 = 1492201158U * num2;
      obj1 = obj3;
      uint num4 = num3 << 17;
      \u0031C561093.\u00304BE210E obj4 = this.\u003253508E5();
      num1 = num4 - 709107081U;
      obj2 = obj4;
    }
    while ((int) num1 * 577718297 == 0);
    do
    {
      \u0031C561093.\u00304BE210E obj3 = obj1;
      uint num2 = 251863730U >> (int) num1;
      \u0031C561093.\u00304BE210E obj4 = obj2;
      uint num3 = 1930446984U & num2;
      int num4 = (int) num3 ^ 8;
      uint num5 = 698097974U % num3;
      int num6 = (int) num5 ^ 6;
      uint num7 = num5 >> 13;
      \u0031C561093.\u00304BE210E obj5 = this.\u0031F2E04EC(obj3, obj4, num4 != 0, num6 != 0);
      num1 = num7 | 1210265407U;
      this.\u0035FD24B62(obj5);
    }
    while (902652587U >= num1);
  }

  private void \u00363B91F43()
  {
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num1 = 913328064;
    \u0031C561093.\u00304BE210E obj2 = obj1;
    uint num2 = num1 + 1119098218U;
    if ((435835089 ^ (int) num2) == 0)
      return;
    uint num3 = num2 | 1924553213U;
    \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
    uint num4 = num3 / 897994504U;
    \u0031C561093.\u00304BE210E obj4 = obj3;
    uint num5 = 1325075920U % ((num4 | 299508984U) << 30);
    \u0031C561093.\u00304BE210E obj5 = obj2;
    uint num6 = num5 % 1351362404U;
    \u0031C561093.\u00304BE210E obj6 = obj4;
    uint num7 = num6 * 237964345U;
    int num8 = (int) num7 - 1136382799;
    int num9 = (int) num7 ^ 1136382800;
    this.\u0035FD24B62(this.\u0031F2E04EC(obj5, obj6, num8 != 0, num9 != 0));
  }

  private void \u00316F5471F()
  {
    uint num1 = 396450020;
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num2 = 152069306U - num1;
    \u0031C561093.\u00304BE210E obj2 = obj1;
    \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
    uint num3 = 1801065839U >> (int) num2;
    \u0031C561093.\u00304BE210E obj4 = obj3;
    uint num4 = 768349120U / num3 | 405685587U;
    \u0031C561093.\u00304BE210E obj5 = obj2;
    \u0031C561093.\u00304BE210E obj6 = obj4;
    int num5 = (int) num4 - 406803838;
    int num6 = (int) num4 ^ 406803838;
    uint num7 = num4 - 1702246785U;
    this.\u0035FD24B62(this.\u0031F2E04EC(obj5, obj6, num5 != 0, num6 != 0));
  }

  private void \u0036E501963()
  {
    uint num1;
    do
    {
      \u0031C561093.\u00304BE210E obj1;
      uint num2;
      do
      {
        obj1 = this.\u003253508E5();
        num2 = 781390177U;
      }
      while (1199389052U <= num2);
      uint num3 = num2 & 927101730U;
      \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
      uint num4 = num3 | 268726563U;
      \u0031C561093.\u00304BE210E obj3 = obj2;
      uint num5 = num4 << 2;
      \u0031C561093.\u00304BE210E obj4 = obj1;
      int num6 = (int) num5 - -669399924;
      num1 = 1194328333U / num5;
      int num7 = (int) num1 ^ 0;
      this.\u0035FD24B62(this.\u00309A340DE(obj3, obj4, num6 != 0, num7 != 0));
    }
    while (num1 == 64965493U);
  }

  private void \u0031F287E0C()
  {
    \u0031C561093.\u00304BE210E obj1;
    uint num1;
    do
    {
      obj1 = this.\u003253508E5();
      num1 = 1651996797U;
    }
    while (num1 % 139612573U == 0U);
    uint num2 = 1712735201U % num1;
    \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
    uint num3 = num2 * 353109773U;
    \u0031C561093.\u00304BE210E obj3 = obj2;
    uint num4 = num3 ^ 499275708U;
    do
    {
      uint num5 = (1371414496U >> (int) num4) % 111758585U;
      \u0031C561093.\u00304BE210E obj4 = obj3;
      uint num6 = 819003553U + num5;
      \u0031C561093.\u00304BE210E obj5 = obj1;
      uint num7 = 229052673U * num6;
      int num8 = (int) num7 - -1358070081;
      int num9 = (int) num7 - -1358070080;
      \u0031C561093.\u00304BE210E obj6 = this.\u00309A340DE(obj4, obj5, num8 != 0, num9 != 0);
      num4 = 1184113186U % num7;
      this.\u0035FD24B62(obj6);
    }
    while (num4 <= 937317834U);
  }

  private void \u003413A06CC()
  {
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num1 = 846471668;
    do
    {
      \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
      uint num2 = 108559859U | num1;
      \u0031C561093.\u00304BE210E obj3 = obj2;
      uint num3 = 1751347280U / (727913345U << (int) num2);
      \u0031C561093.\u00304BE210E obj4 = obj3;
      \u0031C561093.\u00304BE210E obj5 = obj1;
      uint num4 = num3 / 1606644774U;
      int num5 = (int) num4 + 1;
      num1 = 528235097U + num4;
      int num6 = (int) num1 - 528235096;
      this.\u0035FD24B62(this.\u00309A340DE(obj4, obj5, num5 != 0, num6 != 0));
    }
    while (969553675 - (int) num1 == 0);
  }

  private void \u0033CB32B5C()
  {
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num1 = 1252342488;
    \u0031C561093.\u00304BE210E obj2 = obj1;
    uint num2 = num1 & 1400450611U;
    \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
    uint num3 = num2 | 1639742809U;
    \u0031C561093.\u00304BE210E obj4 = obj3;
    uint num4 = 1389837823U - num3;
    do
    {
      uint num5 = num4 + 852888272U;
      \u0031C561093.\u00304BE210E obj5 = obj4;
      uint num6 = num5 / 1248344436U;
      \u0031C561093.\u00304BE210E obj6 = obj2;
      int num7 = (int) num6 ^ 0;
      int num8 = (int) num6 ^ 0;
      uint num9 = num6 | 276373845U;
      \u0031C561093.\u00304BE210E obj7 = this.\u003557C0962(obj5, obj6, num7 != 0, num8 != 0);
      num4 = num9 * 906433680U;
      this.\u0035FD24B62(obj7);
    }
    while (342052456 + (int) num4 == 0);
  }

  private void \u00301B65D58()
  {
    \u0031C561093.\u00304BE210E obj1;
    \u0031C561093.\u00304BE210E obj2;
    uint num1;
    do
    {
      obj1 = this.\u003253508E5();
      uint num2 = 335886463U >> 19;
      obj2 = this.\u003253508E5();
      num1 = 854076070U << (int) num2;
    }
    while (1025196161U < num1);
    uint num3 = 446788361U + (num1 << 27);
    \u0031C561093.\u00304BE210E obj3 = obj2;
    \u0031C561093.\u00304BE210E obj4 = obj1;
    int num4 = (int) num3 - 1252094728;
    uint num5 = num3 << 18;
    int num6 = (int) num5 - -870055936;
    uint num7 = num5 / 991169326U;
    this.\u0035FD24B62(this.\u003557C0962(obj3, obj4, num4 != 0, num6 != 0));
  }

  private void \u0031D5457E7()
  {
    uint num1 = (uint) (681407261 + 2036343940);
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num2 = 1373577010U - num1;
    do
    {
      \u0031C561093.\u00304BE210E obj2 = this.\u003557C0962(this.\u003253508E5(), obj1, ((int) num2 ^ -1344174192) != 0, ((int) num2 ^ -1344174192) != 0);
      num2 |= 1032877182U;
      this.\u0035FD24B62(obj2);
    }
    while (1162217820U == num2);
  }

  private void \u0031F0971C2()
  {
    uint num1 = 380316279;
    if (1922445708U <= num1)
      goto label_3;
label_1:
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    num1 = 1341332933U ^ num1;
    \u0031C561093.\u00304BE210E obj2;
    do
    {
      \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
      uint num2 = 741029457U & num1;
      obj2 = obj3;
      num1 = num2 ^ 2016942772U;
    }
    while (1551055739U / num1 != 0U);
label_3:
    \u0031C561093.\u00304BE210E obj4 = obj2;
    \u0031C561093.\u00304BE210E obj5 = obj1;
    uint num3 = num1 + 1476160897U;
    int num4 = (int) num3 + 936601051;
    \u0031C561093.\u00304BE210E obj6 = this.\u00376633B74(obj4, obj5, num4 != 0);
    num1 = num3 * 1126438408U;
    this.\u0035FD24B62(obj6);
    if (126828196U / num1 != 0U)
      goto label_1;
  }

  private void \u0031B2E2C56()
  {
    uint num1 = (uint) (1612076663 | 1217620396);
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
    \u0031C561093.\u00304BE210E obj3 = obj1;
    uint num2 = 66458984U ^ num1;
    int num3 = (int) num2 - 1801546390;
    uint num4 = 1513178054U * num2;
    this.\u0035FD24B62(this.\u00376633B74(obj2, obj3, num3 != 0));
  }

  private void \u0033A0A5115()
  {
    \u0031C561093.\u00304BE210E obj1;
    uint num1;
    \u0031C561093.\u00304BE210E obj2;
    do
    {
      uint num2;
      do
      {
        uint num3 = 699289134;
        \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
        uint num4 = num3 - 1630218414U;
        obj1 = obj3;
        num2 = num4 ^ 840399125U;
      }
      while (num2 <= 922052909U);
      num1 = num2 - 113658940U;
      obj2 = this.\u003253508E5();
    }
    while (num1 == 1799053693U);
    uint num5 = (num1 & 822612432U) / 1929668769U;
    this.\u0035FD24B62(this.\u0031575638B(obj2, obj1, ((int) (1296513806U >> (int) num5) ^ 1296513806) != 0));
  }

  private void \u003006C3635()
  {
    uint num1 = 595198151;
    \u0031C561093.\u00304BE210E obj1;
    \u0031C561093.\u00304BE210E obj2;
    if ((1553730541 ^ (int) num1) != 0)
    {
      do
      {
        do
        {
          \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
          uint num2 = num1 - 862535711U;
          obj1 = obj3;
          num1 = 1315054230U / num2;
        }
        while (190657081 << (int) num1 == 0);
        \u0031C561093.\u00304BE210E obj4 = this.\u003253508E5();
        num1 = 1211381511U - num1;
        obj2 = obj4;
      }
      while (num1 >> 13 == 0U);
    }
    uint num3 = 315905476U - num1;
    this.\u0035FD24B62(this.\u0031575638B(obj2, obj1, (int) num3 - -895476036 != 0));
  }

  private void \u00325E44E64()
  {
    uint num1 = 176888324;
    if ((int) num1 + 453797664 == 0)
      goto label_2;
label_1:
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    num1 %= 1552619906U;
    \u0031C561093.\u00304BE210E obj2 = obj1;
    if ((int) num1 - 1376913116 == 0)
      return;
label_2:
    \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
    uint num2 = (num1 & 813919649U) + 569133092U;
    \u0031C561093.\u00304BE210E obj4 = obj3;
    uint num3 = num2 - 937822858U;
    \u0031C561093.\u00304BE210E obj5 = obj2;
    \u0031C561093.\u00304BE210E obj6 = this.\u0036F003174(obj4, obj5);
    num1 = 814942870U ^ num3;
    this.\u0035FD24B62(obj6);
    if (num1 / 1238832432U == 0U)
      goto label_1;
  }

  private void \u0032E270349()
  {
    uint num1 = 2035183443;
    if (932989825 + (int) num1 == 0)
      goto label_2;
label_1:
    uint num2 = num1 * 301139394U;
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    num1 = num2 << 6;
    \u0031C561093.\u00304BE210E obj2 = obj1;
label_2:
    \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
    uint num3 = 2139950829U & num1;
    \u0031C561093.\u00304BE210E obj4 = obj3;
    num1 = 1087376605U ^ num3;
    if (num1 < 1723816910U)
    {
      uint num4 = 1663966462U * (1419397044U | num1);
      \u0031C561093.\u00304BE210E obj5 = obj4;
      \u0031C561093.\u00304BE210E obj6 = obj2;
      num1 = num4 + 898564611U;
      this.\u0035FD24B62(this.\u00338397096(obj5, obj6));
      if (num1 < 627662781U)
        goto label_1;
    }
    else
      goto label_1;
  }

  private void \u003661818BC()
  {
    uint num1 = 330132305;
    if (528504735U < num1)
      return;
    uint num2 = 1677686457U % num1;
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num3 = 527064888U << (int) num2;
    \u0031C561093.\u00304BE210E obj2 = obj1;
    uint num4 = 2113479921U + num3;
    \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
    uint num5 = num4 + 1388997490U;
    \u0031C561093.\u00304BE210E obj4 = obj3;
    \u0031C561093.\u00304BE210E obj5 = obj2;
    uint num6 = 1532324121U / num5;
    \u0031C561093.\u00304BE210E obj6 = this.\u0031DEA1613(obj4, obj5);
    uint num7 = 1638533180U * num6;
    this.\u0035FD24B62(obj6);
  }

  private void \u0032A890723()
  {
    uint num1 = 1766149616;
    \u0031C561093.\u00304BE210E obj1;
    do
    {
      uint num2 = num1 ^ 110122411U;
      obj1 = this.\u003253508E5();
      num1 = 842542983U % num2;
    }
    while (1097675741U >> (int) num1 == 0U);
    do
    {
      uint num2 = 1793138912U % (num1 | 1973366068U);
      \u0031C561093.\u00304BE210E obj2 = obj1;
      num1 = 1647858162U - num2;
      this.\u0035FD24B62(this.\u003742D300A(obj2));
    }
    while (num1 <= 354162681U);
  }

  private void \u0034DC16D57()
  {
    \u0031C561093.\u00304BE210E obj1;
    uint num1;
    do
    {
      \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
      uint num2 = 1772691823;
      obj1 = obj2;
      num1 = 201790962U + num2;
    }
    while (354246425U >= num1);
    \u0031C561093.\u00304BE210E obj3 = obj1;
    uint num3 = 598364304U >> (int) num1;
    \u0031C561093.\u00304BE210E obj4 = this.\u0037C93334A(obj3);
    uint num4 = 1371757785U / num3;
    this.\u0035FD24B62(obj4);
  }

  private void \u0035A337EF5()
  {
    uint num1 = 1004234932;
    if (num1 > 2111708883U)
      return;
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num2 = num1 | 638918048U;
    if (2116894548 << (int) num2 == 0)
      goto label_3;
label_2:
    \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
    num2 = 1190073520U + num2;
    \u0031C561093.\u00304BE210E obj3 = obj2;
label_3:
    uint num3 = num2 ^ 1791261868U;
    \u0031C561093.\u00304BE210E obj4 = obj3;
    \u0031C561093.\u00304BE210E obj5 = obj1;
    num2 = num3 << 1;
    int num4 = (int) num2 ^ -669655664;
    this.\u0035FD24B62(this.\u003242114DB(obj4, obj5, num4 != 0));
    if (1166434476U > num2)
      goto label_2;
  }

  private void \u003241C3A12()
  {
    uint num1 = 1410335674;
    if (num1 > 1856917703U)
      return;
    \u0031C561093.\u00304BE210E obj1;
    \u0031C561093.\u00304BE210E obj2;
    do
    {
      uint num2 = num1 << 24;
      \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
      uint num3 = num2 - 1910338024U;
      obj1 = obj3;
      uint num4 = 1495159954U - num3;
      \u0031C561093.\u00304BE210E obj4 = this.\u003253508E5();
      uint num5 = 219565350U >> (int) num4;
      obj2 = obj4;
      num1 = num5 >> 6;
    }
    while ((int) num1 * 1969712045 != 0);
    uint num6 = num1 + 1392322794U;
    \u0031C561093.\u00304BE210E obj5 = obj2;
    \u0031C561093.\u00304BE210E obj6 = obj1;
    int num7 = (int) num6 ^ 1392322795;
    uint num8 = num6 >> 1;
    this.\u0035FD24B62(this.\u003242114DB(obj5, obj6, num7 != 0));
  }

  private void \u00368DD47A5()
  {
    \u0031C561093.\u00304BE210E obj1;
    uint num1;
    \u0031C561093.\u00304BE210E obj2;
    do
    {
      uint num2 = 662531436;
      \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
      uint num3 = 686762553U * num2;
      obj1 = obj3;
      uint num4 = num3 + 1163681805U;
      \u0031C561093.\u00304BE210E obj4 = this.\u003253508E5();
      num1 = 1564087592U % num4;
      obj2 = obj4;
    }
    while ((int) num1 - 474367938 == 0);
    do
    {
      num1 = 1097231120U - num1;
      this.\u0035FD24B62(this.\u003325E1E71(obj2, obj1));
    }
    while (1313293247U >> (int) num1 == 0U);
  }

  private void \u00372474421()
  {
    uint num1 = 1224493074U % (uint) (1054933895 & 2098354643);
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num2 = num1 - 1959602014U;
    int num3 = obj1.E2D6F630();
    uint num4 = 1688235273U >> (int) num2;
    Type type1 = this.\u0033CE71CC6(num3);
    uint num5 = num4 | 1637231823U;
    if (1716007719U < num5)
      return;
    uint num6 = num5 >> 23;
    \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
    uint num7 = num6 - 1721568289U;
    Type type2 = type1;
    \u0031C561093.\u00304BE210E obj3 = this.\u0031152448F((object) obj2, type2);
    uint num8 = num7 % 320808061U;
    this.\u0035FD24B62(obj3);
  }

  private void \u003253C5A20()
  {
    uint num1 = 252733448;
    Type type1;
    if (num1 % 1486099813U != 0U)
    {
      do
      {
        uint num2 = 196877321U + num1 % 45626423U;
        \u0031C561093.\u00304BE210E obj = this.\u003253508E5();
        uint num3 = 1281979186U * num2;
        type1 = this.\u0033CE71CC6(obj.E2D6F630());
        num1 = 1927679194U + num3;
      }
      while ((int) num1 + 1035939867 == 0);
    }
    do
    {
      uint num2 = ((num1 | 1138561647U) & 1943485533U) / 1930328999U;
      object obj = this.\u003253508E5().C5EE7C38(type1, ((int) num2 ^ 0) != 0);
      Type type2 = type1;
      num1 = num2 ^ 1071718945U;
      this.\u0035FD24B62(this.\u0031152448F(obj, type2));
    }
    while (93723355U > num1);
  }

  private void \u0035E492702()
  {
    uint num1 = 1964332485U - 528119483U / 1127233867U;
    Type type1 = this.\u0033CE71CC6(this.\u003253508E5().E2D6F630());
    uint num2 = num1 >> 12;
    Type type2 = type1;
    uint num3 = 105712328U & num2 ^ 709042517U ^ 697724067U | 667450022U;
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num4 = 1980899381U + num3;
    Type type3 = type2;
    uint num5 = num4 + 937429900U;
    int num6 = (int) num5 + 708138122;
    uint num7 = num5 & 1465018059U;
    object obj2 = obj1.C5EE7C38(type3, num6 != 0);
    uint num8 = num7 >> 21;
    Type type4 = type2;
    uint num9 = 606552050U + num8;
    \u0031C561093.\u00304BE210E obj3 = this.\u0031152448F(obj2, type4);
    uint num10 = 2144211981U << (int) num9;
    this.\u0035FD24B62(obj3);
  }

  private void \u003542961F1()
  {
    uint num1 = (uint) (1649502453 - 1384269279);
    int num2 = this.\u0033D5821EF();
    uint num3 = num1 >> 18;
    Type t = this.\u0033CE71CC6(num2);
    uint num4 = num3 - 239023753U;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(Marshal.SizeOf(t)));
  }

  private unsafe void \u00337533FAF()
  {
    uint num1 = (uint) (985288852 & 1475897921);
    int num2 = this.\u003253508E5().E2D6F630();
    uint num3 = 1856378015U * num1;
    Type type1 = this.\u0033CE71CC6(num2);
    if (1380656497U == num3)
      goto label_2;
label_1:
    \u0031C561093.\u00304BE210E obj1;
    do
    {
      num3 = 655516094U + num3;
      obj1 = this.\u003253508E5();
    }
    while (1499333274U == num3);
label_2:
    uint num4;
    do
    {
      int num5 = obj1.\u0036736EEEA() ? 1 : 0;
      num4 = 732200586U - num3;
      if (num5 == 0)
        num3 = 773480879U - num4;
      else
        goto label_8;
    }
    while (num3 / 1230003952U == 0U);
    \u0031C561093.\u00304BE210E obj2 = obj1;
    uint num6 = num3 * 1767997048U;
    object obj3 = obj2.\u0035F319DE0();
    num3 = num6 << 20;
    if (obj3 is Pointer)
    {
      \u0031C561093.\u00304BE210E obj4 = obj1;
      uint num5 = num3 << 2;
      object ptr = obj4.\u0035F319DE0();
      uint num7 = num5 >> 29;
      IntPtr num8 = new IntPtr(Pointer.Unbox(ptr));
      uint num9 = 1699615182U - num7;
      Type type2 = type1;
      uint num10 = 235358249U / num9;
      obj1 = (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0032ABF00C0(num8, type2);
      num4 = num10 + 2132958412U;
    }
    else
    {
      if (506613932U < num3)
        throw new ArgumentException();
      goto label_1;
    }
label_8:
    uint num11 = (418120824U | num4 ^ 1589459965U) * 1114900858U;
    \u0031C561093.\u00304BE210E obj5 = obj1;
    uint num12 = 93573U - num11;
    Type type3 = type1;
    uint num13 = num12 & 1370427582U;
    \u0031C561093.\u00304BE210E obj6 = this.\u0031152448F((object) obj5, type3);
    uint num14 = 261102447U - num13;
    this.\u0035FD24B62(obj6);
  }

  private void \u0033EFF2212()
  {
    uint num1;
    do
    {
      FieldInfo fieldInfo1;
      uint num2;
      object obj1;
      do
      {
        uint num3 = (uint) (538277992 * 1079460289);
        \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
        uint num4 = 298874108U * num3;
        FieldInfo fieldInfo2 = this.\u00310D515AF(obj2.E2D6F630());
        uint num5 = 1733457009U >> (int) num4;
        fieldInfo1 = fieldInfo2;
        uint num6 = num5 * 1613848203U;
        object obj3 = this.\u003253508E5().\u0035F319DE0();
        num2 = 1004109660U % num6;
        obj1 = obj3;
        while (!fieldInfo1.IsStatic)
        {
          uint num7 = 530936708U + num2;
          object obj4 = obj1;
          num2 = 1595557342U * num7 ^ 3755654203U;
          if (obj4 == null)
          {
            num2 *= 1572240285U;
            if ((2138713343 & (int) num2) != 0)
              throw new NullReferenceException();
          }
          else
            break;
        }
      }
      while (num2 == 489044237U);
      FieldInfo fieldInfo3 = fieldInfo1;
      uint num8 = 1421827862U << (int) num2;
      object obj5 = obj1;
      uint num9 = num8 ^ 1949713596U;
      \u0031C561093.\u00304BE210E obj6 = this.\u0031152448F(fieldInfo3.GetValue(obj5), fieldInfo1.FieldType);
      num1 = 958280530U >> (int) num9;
      this.\u0035FD24B62(obj6);
    }
    while (1640633848 << (int) num1 == 0);
  }

  private void \u00317465818()
  {
    uint num1;
    do
    {
      FieldInfo fieldInfo1;
      object obj1;
      uint num2;
      do
      {
        uint num3 = 1179024896;
        int num4 = this.\u003253508E5().E2D6F630();
        uint num5 = num3 >> 14;
        fieldInfo1 = this.\u00310D515AF(num4);
        obj1 = this.\u003253508E5().\u0035F319DE0();
        num2 = num5 + 1567255112U;
      }
      while (((int) num2 ^ 1197288016) == 0);
      FieldInfo fieldInfo2 = fieldInfo1;
      uint num6 = 580482884U >> (int) num2;
      int num7 = fieldInfo2.IsStatic ? 1 : 0;
      uint num8 = 202068163U << (int) num6;
      if (num7 == 0)
      {
        object obj2 = obj1;
        num8 = 71774208U & num8 ^ 807944972U;
        if (obj2 == null)
        {
          if (1377134195U >= num8)
            throw new NullReferenceException();
          continue;
        }
      }
      uint num9 = (1094342733U & num8) / 1852184855U;
      FieldInfo fieldInfo3 = fieldInfo1;
      uint num10 = 1430731843U - num9;
      object obj3 = obj1;
      \u0031C561093.\u0034C846853 obj4 = new \u0031C561093.\u0034C846853(fieldInfo3, obj3);
      num1 = num10 % 1507609263U;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj4);
    }
    while (((int) num1 ^ 1353738052) == 0);
  }

  private void \u00301451C01()
  {
    uint num1 = 973754631;
label_1:
    uint num2 = 1762281424U & num1;
    FieldInfo fieldInfo1 = this.\u00310D515AF(this.\u003253508E5().E2D6F630());
    uint num3 = 537481533U * num2;
    FieldInfo fieldInfo2 = fieldInfo1;
    if ((int) num3 * 1578054770 == 0)
      goto label_8;
label_2:
    num1 = num3 << 24;
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    object obj2;
    if (num1 / 1383077420U == 0U)
    {
      uint num4 = 1803557217U * num1;
      object obj3 = this.\u003253508E5().\u0035F319DE0();
      uint num5 = num4 ^ 1974761096U;
      obj2 = obj3;
      uint num6 = 1976787239U + num5;
      do
      {
        int num7 = fieldInfo2.IsStatic ? 1 : 0;
        num3 = num6 % 1927496479U;
        if (num7 == 0)
          num6 = 1070268924U ^ num3;
        else
          goto label_8;
      }
      while (((int) num6 ^ 2136878907) == 0);
      object obj4 = obj2;
      num3 = num6 + 3417768164U;
      if (obj4 == null)
      {
        uint num7 = 528494589U + num3;
        throw new NullReferenceException();
      }
    }
    else
      goto label_1;
label_8:
    uint num8 = num3 % 335703978U;
    FieldInfo fieldInfo3 = fieldInfo2;
    object obj5 = obj2;
    uint num9 = 1631926528U | num8;
    \u0031C561093.\u00304BE210E obj6 = obj1;
    uint num10 = 1827302285U / num9;
    FieldInfo fieldInfo4 = fieldInfo2;
    num3 = 710943728U | num10;
    Type fieldType = fieldInfo4.FieldType;
    object obj7 = this.\u0031152448F((object) obj6, fieldType).\u0035F319DE0();
    fieldInfo3.SetValue(obj5, obj7);
    if (num3 < 131087379U)
      goto label_2;
  }

  private void \u0033D7426D0()
  {
    uint num1;
    do
    {
      uint num2 = 914515609;
      \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
      uint num3 = num2 - 79658675U;
      int num4 = obj1.E2D6F630();
      uint num5 = 925188660U << (int) num3;
      FieldInfo fieldInfo1 = this.\u00310D515AF(num4);
      uint num6 = 2042772866U << (int) num5;
      FieldInfo fieldInfo2 = fieldInfo1;
      uint num7 = num6 / 382104057U;
      \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
      uint num8 = num7 - 1449201324U;
      \u0031C561093.\u00304BE210E obj3 = obj2;
      if (num8 >= 1486171176U)
      {
        FieldInfo fieldInfo3 = fieldInfo2;
        uint num9 = 981761443U & num8 & 28328405U;
        \u0031C561093.\u00304BE210E obj4 = obj3;
        uint num10 = 2103913193U % num9;
        FieldInfo fieldInfo4 = fieldInfo2;
        uint num11 = num10 - 2066175961U;
        Type fieldType = fieldInfo4.FieldType;
        num1 = 1781597707U << (int) num11;
        object obj5 = this.\u0031152448F((object) obj4, fieldType).\u0035F319DE0();
        fieldInfo3.SetValue((object) null, obj5);
      }
      else
        goto label_2;
    }
    while (786245654U == num1);
    goto label_3;
label_2:
    return;
label_3:;
  }

  private unsafe void \u003598D2D17()
  {
    uint num1 = 402722028;
    do
    {
      Type type1;
      do
      {
        uint num2 = 1055733838U + (num1 << 20);
        \u0031C561093.\u00304BE210E obj = this.\u003253508E5();
        uint num3 = 326072589U & num2;
        Type type2 = this.\u0033CE71CC6(obj.E2D6F630());
        uint num4 = num3 & 100688074U;
        type1 = type2;
        num1 = 1056338242U / num4;
      }
      while (1499731656U <= num1);
      uint num5 = num1 >> 10;
      \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
      uint num6 = num5 ^ 1409383869U;
      \u0031C561093.\u00304BE210E obj2 = obj1;
      \u0031C561093.\u00304BE210E obj3;
      uint num7;
      uint num8;
      do
      {
        do
        {
          \u0031C561093.\u00304BE210E obj4 = this.\u003253508E5();
          uint num2 = num6 | 281743148U;
          obj3 = obj4;
          \u0031C561093.\u00304BE210E obj5 = obj3;
          num7 = num2 - 1719218492U;
          if (!obj5.\u0036736EEEA())
          {
            uint num3 = 1615215921U - num7;
            Pointer pointer = obj3.\u0035F319DE0() as Pointer;
            num8 = num3 - 1425562314U;
            if (pointer != null)
              num6 = 1004749421U ^ num8;
            else
              goto label_8;
          }
          else
            goto label_9;
        }
        while (num6 >= 1187084646U);
        object ptr = obj3.\u0035F319DE0();
        uint num4 = num6 % 7229363U;
        void* voidPtr = Pointer.Unbox(ptr);
        uint num9 = 1172000606U + num4;
        IntPtr num10 = new IntPtr(voidPtr);
        uint num11 = 1062404142U << (int) num9;
        Type type2 = type1;
        num6 = num11 << 5;
        obj3 = (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0032ABF00C0(num10, type2);
      }
      while ((int) num6 * 1962505613 == 0);
      num7 = num6 ^ 1850035888U;
      goto label_9;
label_8:
      uint num12 = num8 | 1476807985U;
      throw new ArgumentException();
label_9:
      \u0031C561093.\u00304BE210E obj6 = obj3;
      uint num13 = num7 << 9;
      \u0031C561093.\u00304BE210E obj7 = obj2;
      Type type3 = type1;
      uint num14 = 1043933709U | num13;
      \u0031C561093.\u00304BE210E obj8 = this.\u0031152448F((object) obj7, type3);
      num1 = 917319469U | num14;
      object obj9 = obj8.\u0035F319DE0();
      obj6.\u0036DCE2291(obj9);
    }
    while (2111586175 - (int) num1 == 0);
  }

  private void \u00306AB7707()
  {
    uint num1 = 1097629075;
    if (num1 >> 19 == 0U)
      return;
    uint num2 = num1 % 387256367U;
    List<\u0031C561093.\u00304BE210E> objList = this.\u00310372FF8;
    uint num3 = num2 | 278404089U;
    int num4 = (int) this.\u003514C63E6();
    uint num5 = num3 ^ 347356843U;
    int index = (int) (ushort) num4;
    uint num6 = 502679053U + num5;
    \u0031C561093.\u00304BE210E obj1 = objList[index];
    uint num7 = 1883504881U % num6;
    \u0031C561093.\u00304BE210E obj2 = obj1.\u00321939EB5();
    uint num8 = num7 << 30;
    this.\u0035FD24B62(obj2);
  }

  private void \u003019B1616()
  {
    uint num1;
    do
    {
      uint num2 = 859780404;
      List<\u0031C561093.\u00304BE210E> objList = this.\u00310372FF8;
      uint num3 = (num2 << 0) % 254476398U;
      int index = (int) (ushort) this.\u003514C63E6();
      num1 = 199704064U << (int) num3;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u003539D1618(objList[index]));
    }
    while (1552972958 * (int) num1 == 0);
  }

  private void \u00326700CB8()
  {
    \u0031C561093.\u00304BE210E obj1;
    uint num1;
    \u0031C561093.\u00304BE210E obj2;
    do
    {
      uint num2 = 912017596;
      \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
      uint num3 = num2 + 1785614240U;
      obj1 = obj3;
      uint num4 = num3 / 2128884408U;
      List<\u0031C561093.\u00304BE210E> objList = this.\u00310372FF8;
      uint num5 = num4 / 935164459U;
      int index = (int) (ushort) this.\u003514C63E6();
      num1 = 1458143097U * num5;
      obj2 = objList[index];
    }
    while (1771393800U < num1);
    do
    {
      \u0031C561093.\u00304BE210E obj3 = obj2;
      uint num2 = 1548953015U - num1 >> 22;
      \u0031C561093.\u00304BE210E obj4 = obj1;
      \u0031C561093.\u00304BE210E obj5 = obj2;
      uint num3 = 2077561776U | num2;
      Type type = obj5.\u0030452B850();
      \u0031C561093.\u00304BE210E obj6 = this.\u0031152448F((object) obj4, type);
      uint num4 = num3 & 797537110U;
      object obj7 = obj6.\u0035F319DE0();
      num1 = 1567649675U & num4;
      obj3.\u0036DCE2291(obj7);
    }
    while (num1 >> 11 == 0U);
  }

  private void \u00351CA2101()
  {
    uint num1 = 946150609;
    Type type = this.\u0033CE71CC6(this.\u003253508E5().E2D6F630());
    uint num2 = 334102984U + num1;
    this.\u00373E03C56 = type;
  }

  private void \u00305881923()
  {
    uint num1 = 413797534;
    MethodBase methodBase1;
    if (1278434045U != num1)
    {
      do
      {
        \u0031C561093.\u00304BE210E obj = this.\u003253508E5();
        uint num2 = 227026816U - num1;
        methodBase1 = this.\u00304614996(obj.E2D6F630());
        num1 = num2 / 1750344146U;
      }
      while (num1 > 2128286772U);
    }
    MethodBase methodBase2 = methodBase1;
    int num3 = (int) num1 ^ 2;
    uint num4 = 1267746304U ^ num1;
    \u0031C561093.\u00304BE210E obj1 = this.\u0034B1A622E(methodBase2, num3 != 0);
    uint num5 = num4 << 4;
    \u0031C561093.\u00304BE210E obj2 = obj1;
    if (obj2 == null)
      return;
    \u0031C561093.\u00304BE210E obj3 = obj2;
    uint num6 = 642401846U * num5;
    this.\u0035FD24B62(obj3);
    uint num7 = num6 ^ 2071029472U;
  }

  private void \u00333AC5930()
  {
label_0:
    uint num1;
    \u0031C561093.\u00304BE210E obj1;
    do
    {
      MethodBase methodBase1 = this.\u00304614996(this.\u003253508E5().E2D6F630());
      uint num2 = 781792295;
      MethodBase methodBase2 = methodBase1;
      uint num3 = num2 - 280062893U;
      if ((int) num3 << 27 == 0)
        goto label_4;
label_1:
      uint num4 = num3 - 1490512699U;
      Type type1 = this.\u00373E03C56;
      uint num5 = num4 & 350357841U;
      if ((object) type1 != null)
        num1 = num5 + 1260870363U;
      else
        goto label_14;
label_3:
      ParameterInfo[] parameters = methodBase2.GetParameters();
      uint num6 = 1429622628U % (num1 & 229452299U);
      int length = parameters.Length;
      uint num7 = num6 - 1100835288U;
      Type[] typeArray1 = new Type[length];
      uint num8 = 911637458U ^ num7;
      int num9 = (int) num8 ^ -219389298;
      uint num10 = 921268100U - num8;
      int num11 = num9;
      num3 = num10 >> 17;
      ParameterInfo[] parameterInfoArray = parameters;
label_4:
      int num12 = (int) num3 ^ 8702;
      uint num13 = num3 & 5838547U;
      int index1 = num12;
      uint num14;
      while (true)
      {
        num14 = num13 << 11;
        if (index1 < parameterInfoArray.Length)
        {
          uint num15 = 174875055;
          if (2041206789U / num15 != 0U)
          {
            ParameterInfo parameterInfo1 = parameterInfoArray[index1];
            uint num16 = 144194483U >> (int) num15;
            ParameterInfo parameterInfo2 = parameterInfo1;
            Type[] typeArray2 = typeArray1;
            int index2 = num11;
            uint num17 = num16 % 1558448572U;
            int num18 = index2 + ((int) num17 ^ 4401);
            uint num19 = num17 >> 4;
            num11 = num18;
            Type parameterType = parameterInfo2.ParameterType;
            uint num20 = num19 >> 9;
            typeArray2[index2] = parameterType;
            uint num21 = 2028304767U * num20;
            index1 += (int) num21 - -1;
            num13 = num21 + 210U;
          }
          else
            goto label_0;
        }
        else
          break;
      }
      uint num22 = num14 / 286654956U;
      Type type2 = this.\u00373E03C56;
      MethodBase methodBase3 = methodBase2;
      uint num23 = num22 + 115564696U;
      string name = methodBase3.Name;
      int num24 = (int) num23 ^ 115560876;
      uint num25 = num23 - 1891193306U ^ 1379352176U;
      Type[] types = typeArray1;
      MethodInfo method = type2.GetMethod(name, (BindingFlags) num24, (Binder) null, types, (ParameterModifier[]) null);
      uint num26 = num25 & 1947035185U;
      MethodInfo methodInfo1 = method;
      num3 = 281503867U % num26;
      if (num3 != 625168672U)
      {
        MethodInfo methodInfo2 = methodInfo1;
        uint num15 = 125975384U ^ num3;
        if ((object) methodInfo2 != null)
        {
          num1 = 133050572U | num15;
          if ((int) num1 << 14 != 0)
          {
            methodBase2 = (MethodBase) methodInfo1;
            num15 = num1 ^ 11149516U;
          }
          else
            goto label_3;
        }
        uint num16 = 743863210U / num15;
        if (((int) num16 ^ 1452032959) != 0)
        {
          uint num17 = 1392266413U * num16 ^ 2061795109U;
          this.\u00373E03C56 = (Type) null;
          num5 = num17 ^ 739785369U;
        }
        else
          continue;
      }
      else
        goto label_1;
label_14:
      num3 = 250094377U ^ num5;
      if (num3 <= 818046625U)
      {
        MethodBase methodBase4 = methodBase2;
        uint num15 = 304566067U ^ num3;
        int num16 = (int) num15 ^ 416245002;
        \u0031C561093.\u00304BE210E obj2 = this.\u0034B1A622E(methodBase4, num16 != 0);
        num1 = 1100570971U ^ num15;
        obj1 = obj2;
        if (num1 != 1268015298U)
        {
          if (obj1 == null)
            goto label_19;
        }
        else
          goto label_3;
      }
      else
        goto label_1;
    }
    while (1011550003U > num1);
    goto label_18;
label_19:
    return;
label_18:
    uint num27 = num1 << 14;
    this.\u0035FD24B62(obj1);
    uint num28 = num27 + 3628205136U;
  }

  private void \u00369BD537E()
  {
    uint num1 = 870462418;
    if (218700857 + (int) num1 != 0)
    {
      MethodBase methodBase1;
      do
      {
        uint num2 = 1135949309U % num1;
        \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
        uint num3 = num2 >> 26;
        object obj2 = obj1.\u0035F319DE0();
        uint num4 = 215893938U | num3;
        MethodBase methodBase2 = obj2 as MethodBase;
        uint num5 = 906720120U ^ num4;
        methodBase1 = methodBase2;
        num1 = num5 ^ 1252591122U;
      }
      while (num1 >> 26 == 0U);
      do
      {
        if ((object) methodBase1 == null)
        {
          num1 = 337589740U ^ num1;
          if (num1 > 1526076368U)
            goto label_4;
        }
        else
        {
          num1 /= 1039009926U;
          if (((int) num1 ^ 312888418) != 0)
          {
            MethodBase methodBase2 = methodBase1;
            uint num2 = num1 >> 5;
            int num3 = (int) num2 + 0;
            num1 = 1115977500U + num2;
            \u0031C561093.\u00304BE210E obj1 = this.\u0034B1A622E(methodBase2, num3 != 0);
            if ((1894191472 & (int) num1) != 0)
            {
              if (obj1 != null)
              {
                uint num4 = 1119627810U | 131033546U - num1;
                \u0031C561093.\u00304BE210E obj2 = obj1;
                uint num5 = 1515607579U - num4;
                this.\u0035FD24B62(obj2);
                num1 = num5 + 2955746223U;
              }
            }
          }
        }
      }
      while (1452174342 + (int) num1 == 0);
      return;
    }
label_4:
    throw new ArgumentException();
  }

  private void \u00327F109A3()
  {
    uint num1 = 1226205743;
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num2 = num1 << 2;
    int num3 = obj1.E2D6F630();
    uint num4 = 342252979U | num2;
    int num5 = (int) num4 - 880803263;
    \u0031C561093.\u00304BE210E obj2 = this.\u0033544403E(num3, num5 != 0);
    uint num6 = num4 ^ 1431789885U;
    \u0031C561093.\u00304BE210E obj3 = obj2;
    uint num7 = num6 * 1482242546U;
    if (obj3 == null)
      return;
    uint num8 = num7 | 1976438189U;
    this.\u0035FD24B62(obj3);
    uint num9 = num8 + 4269799159U;
  }

  private void \u0034ADE09E8()
  {
    uint num1 = 878672340;
    \u0031C561093.\u00304BE210E obj1;
    if (1397781873U != num1)
    {
      obj1 = this.\u0033544403E(this.\u003253508E5().E2D6F630(), ((int) num1 ^ 878672341) != 0);
      uint num2 = num1 | 1927563784U;
      \u0031C561093.\u00304BE210E obj2 = obj1;
      uint num3 = 1453082307U * num2;
      if (obj2 == null)
        return;
      num1 = 1755456888U % num3;
    }
    \u0031C561093.\u00304BE210E obj3 = obj1;
    uint num4 = num1 ^ 681063702U;
    this.\u0035FD24B62(obj3);
    uint num5 = num4 + 2723115046U;
  }

  private void \u003638A7597()
  {
    uint num1 = 1144589841;
    \u0031C561093.\u00304BE210E obj1;
    if (568096261U < num1)
    {
      uint num2 = num1 | 1649677387U;
      \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
      uint num3 = num2 % 858880061U;
      int num4 = obj2.E2D6F630();
      uint num5 = 1114059304U ^ num3;
      MethodBase methodBase1 = this.\u00304614996(num4);
      num1 = num5 >> 2;
      do
      {
        MethodBase methodBase2 = methodBase1;
        uint num6 = num1 * 794053903U;
        \u0031C561093.\u00304BE210E obj3 = this.\u00359CF2E14(methodBase2);
        uint num7 = num6 % 921769547U;
        obj1 = obj3;
        num1 = num7 / 1018375354U;
      }
      while ((int) num1 + 564801623 == 0);
    }
    \u0031C561093.\u00304BE210E obj4 = obj1;
    uint num8 = 168197358U << (int) num1;
    if (obj4 == null)
      return;
    uint num9 = 711927740U + (num8 - 1896959509U);
    this.\u0035FD24B62(obj1);
    uint num10 = num9 + 1185031769U;
  }

  private void \u00379083E9E()
  {
    uint num1 = 1616658262;
label_1:
    \u0031C561093.\u00304BE210E obj1;
    do
    {
      Type type1;
      do
      {
        uint num2 = 352023077U / num1;
        \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
        uint num3 = num2 / 1237391138U;
        int num4 = obj2.E2D6F630();
        num1 = num3 >> 3;
        type1 = this.\u0033CE71CC6(num4);
      }
      while (num1 == 938803707U);
label_2:
      do
      {
        num1 <<= 17;
        obj1 = this.\u003253508E5();
        if (num1 % 1280127728U == 0U)
        {
          Type type2 = type1;
          num1 = 584393117U - num1;
          if (type2.IsGenericType)
          {
            if (((int) num1 & 546256285) != 0)
            {
              Type genericTypeDefinition = type1.GetGenericTypeDefinition();
              uint num2 = 1603172027U - num1;
              // ISSUE: type reference
              RuntimeTypeHandle handle = __typeref (Nullable<>);
              uint num3 = 389305479U / num2;
              Type typeFromHandle = Type.GetTypeFromHandle(handle);
              num1 = num3 ^ 584393117U;
              if ((object) genericTypeDefinition != (object) typeFromHandle)
                goto label_9;
            }
            else
              break;
          }
          else
            goto label_9;
        }
        else
          goto label_1;
      }
      while (num1 == 704978301U);
label_7:
      \u0031C561093.\u00304BE210E obj3 = obj1;
      num1 = 426859423U - (num1 + 1233478746U);
      obj3.\u0036DCE2291((object) null);
      continue;
label_9:
      if (type1.IsValueType)
      {
        if (251018704U != num1)
        {
          FieldInfo[] fields = type1.GetFields((BindingFlags) ((int) num1 ^ 584393193));
          uint num2 = num1 | 1207127959U;
          int num3 = (int) num2 ^ 1744269215;
          num1 = num2 * 1242315808U;
          int num4 = num3;
          if (num1 <= 1656372841U)
          {
            while (true)
            {
              if (((int) num1 ^ 1330333453) != 0)
              {
                int num5 = num4;
                uint num6 = num1 % 2066748943U;
                FieldInfo[] fieldInfoArray1 = fields;
                uint num7 = 1225814301U >> (int) num6;
                int length = fieldInfoArray1.Length;
                uint num8 = num7 ^ 649092831U;
                int num9 = length;
                uint num10 = 1850301738U % num8;
                if (num5 < num9)
                {
                  FieldInfo[] fieldInfoArray2 = fields;
                  uint num11 = 199574187;
                  int index = num4;
                  uint num12 = 79693331U * num11;
                  FieldInfo fieldInfo1 = fieldInfoArray2[index];
                  num1 = 1207462733U & num12;
                  FieldInfo fieldInfo2 = fieldInfo1;
                  if (576194635 + (int) num1 != 0)
                  {
                    FieldInfo fieldInfo3 = fieldInfo2;
                    object obj2 = obj1.\u0035F319DE0();
                    FieldInfo fieldInfo4 = fieldInfo2;
                    uint num13 = num1 >> 20;
                    int num14 = fieldInfo4.FieldType.IsValueType ? 1 : 0;
                    uint num15 = 699414831U ^ num13;
                    object obj4;
                    if (num14 == 0)
                    {
                      obj4 = (object) null;
                    }
                    else
                    {
                      FieldInfo fieldInfo5 = fieldInfo2;
                      uint num16 = num15 + 1806575989U;
                      Type fieldType = fieldInfo5.FieldType;
                      uint num17 = num16 * 1966539751U;
                      obj4 = Activator.CreateInstance(fieldType);
                      num15 = num17 ^ 3149181443U;
                    }
                    uint num18 = 1492726545U ^ num15;
                    fieldInfo3.SetValue(obj2, obj4);
                    num1 = num18 >> 29;
                    if (1852324107U / num1 != 0U)
                    {
                      int num16 = num4 + ((int) num1 - 2);
                      uint num17 = 1416580446U - num1;
                      num4 = num16;
                      num1 = num17 + 3659262597U;
                    }
                    else
                      goto label_2;
                  }
                  else
                    goto label_1;
                }
                else
                  goto label_8;
              }
              else
                goto label_1;
            }
          }
          else
            goto label_2;
        }
        else
          goto label_2;
      }
      else if (935425852 - (int) num1 == 0)
        goto label_7;
      else
        goto label_22;
    }
    while (num1 < 1572081112U);
    return;
label_8:
    return;
label_22:
    obj1.\u0036DCE2291((object) null);
  }

  private void \u003480E7F57()
  {
    uint num1 = 1834626775;
    int num2 = this.\u003253508E5().E2D6F630();
    uint num3 = num1 - 485124901U;
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num4 = num3 ^ 1524516701U;
    \u0031C561093.\u00304BE210E obj2 = obj1;
    uint num5 = 2119911305U % num4;
    \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
    uint num6 = 302978099U & 1652371894U % num5 << 7;
    \u0031C561093.\u00304BE210E obj4 = obj3;
    uint num7 = num6 >> 22;
    \u0031C561093.\u00304BE210E obj5 = obj2;
    int num8 = (int) num7 - 64;
    int num9 = num2;
    uint num10 = num7 * 96424588U;
    int num11 = this.\u00354720219(obj4, obj5, num8 != 0, num9);
    uint num12 = 1452700336U ^ num10;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num11));
  }

  private void \u00378242571()
  {
    uint num1 = (uint) (1254765043 - 932805825);
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num2 = num1 & 100153357U;
    int num3 = obj1.E2D6F630();
    do
    {
      \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
      \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
      uint num4 = num2 ^ 1112883313U;
      \u0031C561093.\u00304BE210E obj4 = obj3;
      uint num5 = 1447052110U - num4;
      \u0031C561093.\u00304BE210E obj5 = obj2;
      int num6 = (int) num5 ^ 316330716;
      uint num7 = 485886952U ^ num5;
      int num8 = num3;
      uint num9 = 908875790U | num7;
      \u0031C561093.\u00348553D81 obj6 = new \u0031C561093.\u00348553D81(this.\u00354720219(obj4, obj5, num6 != 0, num8));
      num2 = num9 * 1606972781U;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj6);
    }
    while (1222529795U >> (int) num2 == 0U);
  }

  private void \u0033B5C3155()
  {
    Type type1 = this.\u0033CE71CC6(this.\u003253508E5().E2D6F630());
    uint num1 = 315055838;
    Type type2 = type1;
    do
    {
      uint num2 = num1 / 455630895U;
      Type elementType = type2;
      uint num3 = num2 - 178871025U;
      \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
      uint num4 = 341931088U & num3;
      int length = obj1.E2D6F630();
      uint num5 = 1233858426U & num4;
      \u0031C561093.\u0033745431B obj2 = new \u0031C561093.\u0033745431B(Array.CreateInstance(elementType, length));
      num1 = num5 * 738134549U;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj2);
    }
    while (((int) num1 & 1551572679) == 0);
  }

  private void \u00334B11578()
  {
    uint num1 = 322125671;
label_1:
    uint num2 = (1910855696U - num1) % 1161571032U;
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num3 = num2 ^ 2107128528U;
    Type type1 = this.\u0033CE71CC6(obj1.E2D6F630());
    uint num4 = 74675487U % num3;
    if (143545074U >> (int) num4 != 0U)
      return;
    \u0031C561093.\u00304BE210E obj2;
    \u0031C561093.\u00304BE210E obj3;
    Array array1;
    do
    {
      uint num5 = num4 * 1078604535U;
      \u0031C561093.\u00304BE210E obj4 = this.\u003253508E5();
      num4 = 1621234153U * num5;
      obj2 = obj4;
      do
      {
        uint num6 = 1260545958U ^ num4;
        \u0031C561093.\u00304BE210E obj5 = this.\u003253508E5();
        uint num7 = num6 >> 24;
        obj3 = obj5;
        uint num8 = 814165937U - (num7 + 105142599U);
        \u0031C561093.\u00304BE210E obj6 = this.\u003253508E5();
        uint num9 = 1149583710U << (int) num8;
        Array array2 = obj6.\u0035F319DE0() as Array;
        num4 = num9 | 1508670780U;
        array1 = array2;
      }
      while (1210785557U == num4);
      if (array1 == null)
      {
        num1 = num4 >> 20;
        if (103358408U >= num1)
          throw new ArgumentException();
        goto label_1;
      }
    }
    while (350684203 + (int) num4 == 0);
    Array array3 = array1;
    uint num10 = 1759195004U - num4 + 302845530U;
    \u0031C561093.\u00304BE210E obj7 = obj2;
    Type type2 = type1;
    uint num11 = num10 % 650654671U;
    \u0031C561093.\u00304BE210E obj8 = this.\u0031152448F((object) obj7, type2);
    Array array4 = array1;
    uint num12 = 410152438U & num11;
    Type elementType = array4.GetType().GetElementType();
    uint num13 = num12 / 1275866941U;
    \u0031C561093.\u00304BE210E obj9 = this.\u0031152448F((object) obj8, elementType);
    uint num14 = 123879227U ^ num13;
    object obj10 = obj9.\u0035F319DE0();
    uint num15 = num14 & 552429725U;
    int index = obj3.E2D6F630();
    uint num16 = 1223126281U >> (int) num15;
    array3.SetValue(obj10, index);
  }

  private void \u00322825D79()
  {
    Type type1;
    \u0031C561093.\u00304BE210E obj1;
    uint num1;
    Array array;
    do
    {
      uint num2;
      do
      {
        uint num3 = 209527141;
        int num4 = this.\u003253508E5().E2D6F630();
        num2 = num3 | 28999280U;
        type1 = this.\u0033CE71CC6(num4);
      }
      while (2056400926U == num2);
      uint num5 = 1805738929U * num2;
      \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
      uint num6 = 1998727447U | num5;
      obj1 = obj2;
      num1 = num6 + 1232629088U;
      if ((int) num1 - 741807562 != 0)
      {
        \u0031C561093.\u00304BE210E obj3 = this.\u003253508E5();
        uint num3 = 1032259137U ^ num1;
        object obj4 = obj3.\u0035F319DE0();
        uint num4 = num3 & 1606317694U;
        array = obj4 as Array;
        num1 = num4 & 1325924587U;
      }
      else
        break;
    }
    while ((992154184 & (int) num1) != 0);
    object obj5 = array != null ? array.GetValue(obj1.E2D6F630()) : throw new ArgumentException();
    uint num7 = 687215667U << (int) num1;
    Type type2 = type1;
    \u0031C561093.\u00304BE210E obj6 = this.\u0031152448F(obj5, type2);
    uint num8 = 1892577599U * num7;
    this.\u0035FD24B62(obj6);
  }

  private void \u00375C44302()
  {
    uint num1 = 1735818158;
    if (1563386764U == num1)
      goto label_2;
label_1:
    \u0031C561093.\u00304BE210E obj = this.\u003253508E5();
    num1 >>= 25;
    Array array = obj.\u0035F319DE0() as Array;
label_2:
    if (array == null && num1 < 48831087U)
      throw new ArgumentException();
    uint num2 = 1489780980U >> (int) num1;
    int length = array.Length;
    num1 = num2 * 86992867U;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(length));
    if ((766652839 ^ (int) num1) == 0)
      goto label_1;
  }

  private void \u00303DD46B9()
  {
    uint num1 = 2051872882;
    \u0031C561093.\u00304BE210E obj1;
    Array array1;
    do
    {
      obj1 = this.\u003253508E5();
      uint num2 = num1 + 447219222U;
      if (1191404102U >> (int) num2 != 0U)
      {
        uint num3 = num2 + 540111614U;
        \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
        uint num4 = 1944399803U | num3;
        object obj3 = obj2.\u0035F319DE0();
        uint num5 = num4 / 1959796278U;
        array1 = obj3 as Array;
        num1 = 90457106U & num5;
      }
      else
        goto label_4;
    }
    while (935339419 << (int) num1 == 0);
    do
    {
      Array array2 = array1;
      uint num2 = num1 ^ 840764592U;
      if (array2 != null)
        num1 = 826959015U - num2;
      else
        goto label_4;
    }
    while (1642078112U > num1);
    Array array3 = array1;
    uint num6 = 721888865U + num1;
    \u0031C561093.\u00304BE210E obj4 = obj1;
    uint num7 = num6 % 1715284010U;
    int num8 = obj4.E2D6F630();
    uint num9 = num7 << 19;
    \u0031C561093.\u0035C7A6B63 obj5 = new \u0031C561093.\u0035C7A6B63(array3, num8);
    uint num10 = 1283409339U | num9;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj5);
    return;
label_4:
    throw new ArgumentException();
  }

  private void \u003304C55CE()
  {
    uint num1 = 3017668;
    if (num1 >= 20335934U)
      return;
    do
    {
      uint num2 = num1 & 2133223367U;
      int num3 = this.\u003253508E5().E2D6F630();
      num1 = 2032696972U * num2;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u0037E41300F(this.\u00304614996(num3)));
    }
    while (num1 % 1003516270U == 0U);
  }

  private void \u003148208EA()
  {
label_0:
    uint num1 = (uint) (411333259 * 755920761);
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num2 = 1446720340U ^ num1;
    MethodBase methodBase1 = this.\u00304614996(obj1.E2D6F630());
    uint num3 = 776872028U ^ num2;
    MethodBase methodBase2 = methodBase1;
    uint num4 = num3 & 1565211574U;
label_1:
    do
    {
      Type type1;
      do
      {
        uint num5 = num4 / 627912330U;
        \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
        uint num6 = num5 >> 17;
        object obj3 = obj2.\u0035F319DE0();
        num4 = num6 / 2087191221U;
        type1 = obj3.GetType();
      }
      while ((int) num4 * 1976506756 != 0);
      MethodBase methodBase3 = methodBase2;
      uint num7 = 964825448U >> (int) num4;
      Type declaringType = methodBase3.DeclaringType;
      if (((int) num7 ^ 205079845) != 0)
      {
        MethodBase methodBase4 = methodBase2;
        uint num5 = 598494148U * num7;
        ParameterInfo[] parameters = methodBase4.GetParameters();
        uint num6 = num5 + 1019887657U;
        int length1 = parameters.Length;
        uint num8 = 1513585216U << (int) num6;
        int length2 = length1;
        uint num9 = num8 & 824847080U;
        Type[] typeArray1 = new Type[length2];
        uint num10 = num9 + 1931491371U;
        Type[] typeArray2 = typeArray1;
        int num11 = (int) num10 ^ -1824507861;
        uint num12 = 753865584U >> (int) num10;
        int num13 = num11;
        uint num14 = num12 / 2134862833U;
        ParameterInfo[] parameterInfoArray1 = parameters;
        int num15;
        do
        {
          num14 >>= 0;
          num15 = (int) num14 ^ 0;
        }
        while (1682575721U >> (int) num14 == 0U);
        while (true)
        {
          uint num16 = 1619599238U << (int) num14;
          int num17 = num15;
          uint num18 = num16 % 570185773U;
          int length3 = parameterInfoArray1.Length;
          num4 = 694188150U + num18;
          if (num17 < length3)
          {
            uint num19 = 520299555;
            if (1851726948U != num19)
            {
              ParameterInfo[] parameterInfoArray2 = parameterInfoArray1;
              int index1 = num15;
              uint num20 = num19 - 1195981731U;
              ParameterInfo parameterInfo1 = parameterInfoArray2[index1];
              uint num21 = num20 | 8936234U;
              ParameterInfo parameterInfo2 = parameterInfo1;
              uint num22 = num21 >> 1;
              Type[] typeArray3 = typeArray2;
              uint num23 = num22 >> 22;
              int index2 = num13;
              uint num24 = num23 + 869809530U;
              int num25 = index2 + ((int) num24 ^ 869809960);
              uint num26 = 1819965612U - num24;
              num13 = num25;
              Type parameterType = parameterInfo2.ParameterType;
              uint num27 = num26 ^ 87827938U;
              typeArray3[index2] = parameterType;
              uint num28 = 463228873U % num27;
              if (1602891485U % num28 != 0U)
              {
                int num29 = num15;
                uint num30 = num28 & 866549085U;
                int num31 = (int) num30 ^ 327437640;
                uint num32 = num30 << 30;
                int num33 = num29 + num31;
                uint num34 = 1225944726U << (int) num32;
                num15 = num33;
                num14 = num34 ^ 1225944726U;
              }
              else
                goto label_0;
            }
            else
              goto label_0;
          }
          else
            break;
        }
        MethodInfo method;
        uint num35;
        uint num36;
        uint num37;
        while (true)
        {
          if (num4 % 1977894519U != 0U)
          {
            Type type2 = type1;
            num36 = 1569813815U / num4 + 4145740997U;
            if ((object) type2 != null)
            {
              uint num16 = 1341546161U - num36;
              Type type3 = type1;
              uint num17 = 1150500903U >> (int) num16;
              Type type4 = declaringType;
              num37 = num17 >> 22;
              if ((object) type3 != (object) type4)
              {
                uint num18 = 815225778;
                if (num18 >> 1 != 0U)
                {
                  Type type5 = type1;
                  string name = methodBase2.Name;
                  uint num19 = num18 * 912620121U;
                  int num20 = (int) num19 ^ -1081441068;
                  int num21 = (int) num19 ^ -1081363231;
                  Type[] types = typeArray2;
                  uint num22 = num19 % 1580037716U;
                  method = type5.GetMethod(name, (BindingFlags) num20, (Binder) null, (CallingConventions) num21, types, (ParameterModifier[]) null);
                  uint num23 = 1186989383U - num22;
                  MethodInfo methodInfo = method;
                  num35 = num23 * 2028352798U;
                  if ((object) methodInfo != null)
                  {
                    uint num24 = num35 ^ 1253788604U;
                    MethodInfo baseDefinition = method.GetBaseDefinition();
                    MethodBase methodBase5 = methodBase2;
                    num35 = num24 ^ 1253788604U;
                    if ((object) baseDefinition == (object) methodBase5)
                      break;
                  }
                  Type baseType = type1.BaseType;
                  uint num25 = num35 % 143018285U;
                  type1 = baseType;
                  num4 = num25 + 1102338239U;
                }
                else
                  goto label_0;
              }
              else
                goto label_17;
            }
            else
              goto label_18;
          }
          else
            goto label_1;
        }
        num36 = 1930067142U | num35;
        methodBase2 = (MethodBase) method;
        goto label_18;
label_17:
        num36 = num37 + 4145740998U;
label_18:
        num4 = 1977832444U << (int) num36;
      }
      else
        goto label_0;
    }
    while ((805389265 ^ (int) num4) == 0);
    MethodBase methodBase6 = methodBase2;
    uint num38 = 1417104054U / num4;
    \u0031C561093.\u0037E41300F obj4 = new \u0031C561093.\u0037E41300F(methodBase6);
    uint num39 = num38 & 2088720238U;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj4);
  }

  private void \u0031F9B2F7F()
  {
    uint num1 = (uint) (1659782316 & 1612280433);
    int num2 = this.\u003253508E5().E2D6F630();
    uint num3 = 734220622U - num1;
    this.\u0035E5D486B = num2;
  }

  private void \u00334DD32D5()
  {
    uint num1 = 995825144;
    if (num1 <= 382694318U)
      return;
    uint num2 = 797771956U * num1;
    this.\u003253508E5();
  }

  private void \u0034722764A()
  {
    uint num1 = 1927161757;
label_1:
    Stack<int> intStack1 = this.\u00370214200;
    uint num2 = num1 ^ 75760542U;
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num3 = 1562055657U + num2;
    int num4 = obj1.E2D6F630();
    intStack1.Push(num4);
    uint num5 = num3 | 75442856U;
label_2:
    int num6 = this.\u003253508E5().E2D6F630();
    uint num7 = num5 ^ 1281717799U;
    int num8 = num6;
    if (2040075416U <= num7)
      goto label_13;
label_6:
    List<\u0031C561093.\u0037B071B97> objList1;
    List<\u0031C561093.\u0037B071B97> objList2 = objList1;
    int num9;
    int num10 = num9;
    uint num11 = 763717937;
    int index = num10 - 1;
    uint num12 = 747467186U * num11;
    \u0031C561093.\u0037B071B97 obj2 = objList2[index];
label_7:
    \u0031C561093.\u0037B071B97 obj3 = obj2;
    uint num13 = num12 - 1169234902U;
    int num14 = (int) obj3.\u0036ADB41E8();
    int num15 = (int) num13 ^ -1602377410;
    num5 = num13 / 1559652333U;
    if (num14 == num15)
    {
      if (112741278U != num5)
      {
        Stack<int> intStack2 = this.\u00370214200;
        int num16 = obj2.\u00327244D76();
        uint num17 = num5 ^ 1225024028U;
        intStack2.Push(num16);
        num5 = num17 + 3069943268U;
      }
      else
        goto label_2;
    }
    int num18 = num9;
    uint num19 = num5 / 848377428U;
    int num20 = (int) num19 ^ 1;
    num9 = num18 - num20;
    uint num21 = num19 + 466817093U;
label_11:
    int num22 = num9;
    int num23 = (int) num21 - 466817093;
    uint num24 = 1377450552U << (int) num21;
    if (num22 <= num23)
      num7 = num24 + 1473446603U;
    else
      goto label_6;
label_13:
    uint num25;
    do
    {
      uint num16 = 1621114150U + num7;
      if (num16 >= 1040477641U)
      {
        uint num17 = num16 << 12;
        Stack<\u0031C561093.\u0037BC90C3B> objStack = this.\u0035EBC5C0D;
        uint num26 = 1357391145U & num17;
        int count = objStack.Count;
        num25 = num26 & 812600423U;
        if (count != 0)
          num7 = num25 | 1163290219U;
        else
          goto label_18;
      }
      else
        goto label_5;
    }
    while (num7 <= 75116058U);
    goto label_16;
label_5:
    List<\u0031C561093.\u0037B071B97> objList3 = objList1;
    num21 = 466817093U;
    num9 = objList3.Count;
    goto label_11;
label_16:
    int num27 = num8;
    uint num28 = 2016694863U + (9468121U + num7);
    Stack<\u0031C561093.\u0037BC90C3B> objStack1 = this.\u0035EBC5C0D;
    uint num29 = 886774179U ^ num28;
    int num30 = objStack1.Peek().\u00371A73A97();
    uint num31 = num29 / 86588296U;
    if (num27 > num30)
    {
      objList1 = this.\u0035EBC5C0D.Pop().\u0033CC40EC4();
      goto label_5;
    }
    else
      num25 = num31 ^ 6815770U;
label_18:
    num1 = num25 * 696266259U;
    this.\u0034B807558 = (Exception) null;
    if (num1 >= 41234258U)
    {
      uint num16 = num1 / 112356107U;
      Stack<\u0031C561093.\u0033AF92E6D> objStack2 = this.\u0032B654A18;
      uint num17 = 1317108426U | num16;
      objStack2.Clear();
      num1 = num17 ^ 424439048U;
      if (1751661125U >= num1)
      {
        num12 = 682718115U / num1 / 1983339138U;
        this.\u0035E5D486B = this.\u00370214200.Pop();
        if (((int) num12 ^ 1789553507) == 0)
          goto label_7;
      }
      else
        goto label_1;
    }
    else
      goto label_1;
  }

  private void \u0032098468E()
  {
    uint num1;
    do
    {
      uint num2;
      do
      {
        uint num3 = 169679851;
        Exception exception = this.\u0034B807558;
        uint num4 = 897527615U / num3;
        if (exception == null)
        {
          this.\u0035E5D486B = this.\u00370214200.Pop();
          return;
        }
        num2 = num4 >> 16;
      }
      while (num2 > 2061771469U);
      Exception exception1 = this.\u0034B807558;
      num1 = 1438475768U >> (int) num2;
      this.\u003668C74B0(exception1);
    }
    while (542527159U / num1 != 0U);
  }

  private void \u003417C37F2()
  {
    uint num1;
    do
    {
      uint num2 = 1518293778;
      \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
      uint num3 = num2 >> 31;
      int num4 = obj1.E2D6F630();
      uint num5 = num3 * 2034307591U;
      if (num4 != 0)
      {
        if (251953043U >> (int) num5 != 0U)
        {
          uint num6 = num5 >> 16;
          this.\u0035EBC5C0D.Pop();
          if (1947888542U > num6)
          {
            Stack<\u0031C561093.\u0033AF92E6D> objStack = this.\u0032B654A18;
            uint num7 = 1922508123U + (1136685425U ^ num6);
            \u0031C561093.\u00362DF5BD2 obj2 = new \u0031C561093.\u00362DF5BD2((object) this.\u0034B807558);
            uint num8 = num7 % 145253354U;
            objStack.Push((\u0031C561093.\u0033AF92E6D) obj2);
            num5 = num8 | 498218955U;
          }
          else
            continue;
        }
        this.\u0035E5D486B = this.\u00319B82813.\u00327244D76();
        uint num9 = 1209497897U ^ num5;
        this.\u00319B82813 = (\u0031C561093.\u0037B071B97) null;
        break;
      }
      num1 = num5 >> 17;
      this.\u003668C74B0(this.\u0034B807558);
    }
    while (328816361 << (int) num1 == 0);
  }

  private void \u00355BE1401()
  {
    uint num1 = 7359679;
    do
    {
      uint num2 = 782924710U - 913442620U % num1;
      Type type1 = this.\u0033CE71CC6(this.\u003253508E5().E2D6F630());
      uint num3 = num2 ^ 136137589U;
      Type type2 = type1;
      if (((int) num3 ^ 187188739) != 0)
      {
        uint num4 = (1896640048U >> (int) num3) * 1017185343U;
        \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
        uint num5 = 1858671139U << (int) num4;
        Type type3 = type2;
        object obj2 = this.\u0031152448F((object) obj1, type3).\u0035F319DE0();
        num1 = num5 / 1518691078U;
        this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u00362DF5BD2(obj2));
      }
      else
        goto label_3;
    }
    while ((1866148944 ^ (int) num1) == 0);
    goto label_4;
label_3:
    return;
label_4:;
  }

  private void \u00300AF38F6()
  {
    uint num1 = 728438720;
    if ((int) num1 + 383997999 == 0)
      return;
    uint num2 = 1986603243U - num1;
    Type type1 = this.\u0033CE71CC6(this.\u003253508E5().E2D6F630());
    uint num3 = num2 * 1921672187U;
    Type type2 = type1;
    uint num4 = 78532810U ^ num3 - 759198846U;
    object obj = this.\u003253508E5().\u0035F319DE0();
    uint num5 = 1534547524U % num4;
    Type type3 = type2;
    uint num6 = 433152948U << (int) num5;
    this.\u0035FD24B62(this.\u0031152448F(obj, type3));
  }

  private void \u003772121CE()
  {
label_0:
    uint num1;
    object obj1;
    uint num2;
    uint num3;
    do
    {
      do
      {
        uint num4;
        Type type1;
        do
        {
          uint num5 = 1164865179;
          int num6 = this.\u003253508E5().E2D6F630();
          num4 = num5 % 1721000996U;
          type1 = this.\u0033CE71CC6(num6);
        }
        while (1986688168U == num4);
label_1:
        do
        {
          num1 = num4 % 1361788850U;
          \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
          if (457709097U != num1)
          {
label_2:
            uint num5;
            do
            {
              obj1 = obj2.\u0035F319DE0();
label_3:
              object obj3 = obj1;
              num5 = num1 | 1481532567U;
              if (obj3 == null)
                num1 = 1585453415U + num5;
              else if (66086462U < num5)
              {
                if (!type1.IsValueType)
                {
                  if (1638889638U / num5 != 0U)
                  {
                    TypeCode typeCode = Type.GetTypeCode(type1);
                    if (1291155792U != num5)
                    {
                      int num6 = (int) (typeCode - ((int) num5 - 1567518364));
                      num1 = num5 - 662190812U;
                      switch (num6)
                      {
                        case 0:
                          goto label_17;
                        case 1:
                          goto label_18;
                        case 2:
                          goto label_20;
                        case 3:
                          goto label_22;
                        case 4:
                          goto label_23;
                        case 5:
                          goto label_25;
                        case 6:
                          goto label_26;
                        case 7:
                          goto label_27;
                        case 8:
                          if ((229531559 & (int) num1) == 0)
                            goto label_3;
                          else
                            goto label_31;
                        case 9:
                          num1 = 1444759812U + num1;
                          if (((int) num1 & 657469311) == 0)
                            goto label_3;
                          else
                            goto label_34;
                        case 10:
                          goto label_35;
                        case 11:
                          goto label_38;
                        default:
                          goto label_40;
                      }
                    }
                    else
                      goto label_0;
                  }
                  else
                    goto label_0;
                }
                else
                  goto label_8;
              }
              else
                goto label_0;
            }
            while ((43582531 ^ (int) num1) == 0);
label_5:
            throw new NullReferenceException();
label_8:
            if (num5 >= 1836328558U)
              goto label_5;
label_9:
            Type type2 = type1;
            object obj4 = obj1;
            uint num7 = 57685162U & num5;
            Type type3 = obj4.GetType();
            num4 = num7 ^ 795286620U;
            if ((object) type2 != (object) type3)
              throw new InvalidCastException();
            this.\u0035FD24B62(obj2);
            continue;
label_20:
            if (1064252511U < num1)
              goto label_2;
            else
              goto label_21;
label_27:
            num4 = 1473669172U << (int) num1;
            if (781918849U <= num4)
            {
              uint num6 = 650340645U & num4;
              object obj3 = obj1;
              uint num8 = 2055690625U % num6;
              \u0031C561093.\u00328355445 obj5 = new \u0031C561093.\u00328355445((uint) obj3);
              num1 = num8 ^ 1567707450U;
              this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj5);
              if (num1 == 1346981997U)
                goto label_2;
              else
                goto label_12;
            }
            else
              continue;
label_31:
            uint num9 = 859640195U ^ num1;
            long num10 = (long) obj1;
            num1 = num9 | 1034817369U;
            this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(num10));
            if (num1 >> 1 == 0U)
              goto label_2;
            else
              goto label_29;
label_38:
            if (num1 < 2023783639U)
            {
              uint num6 = num1 + 776932829U;
              double num8 = (double) obj1;
              num1 = 436872669U >> (int) num6;
              this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(num8));
              if (num1 == 480780425U)
                goto label_2;
              else
                goto label_37;
            }
            else
              goto label_0;
label_40:
            num5 = num1 ^ 285960528U;
            if ((1356344529 ^ (int) num5) == 0)
              goto label_9;
            else
              goto label_41;
          }
          else
            goto label_0;
        }
        while (995427122U >> (int) num4 == 0U);
        return;
label_17:
        uint num11 = 798171861U % (146883134U | num1);
        int num12 = (bool) obj1 ? 1 : 0;
        num2 = num11 / 1672904100U;
        this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u003459C67EE(num12 != 0));
        return;
label_18:
        continue;
label_35:
        if (num1 <= 1048654735U)
        {
          double num5 = (double) (float) obj1;
          uint num6 = num1 >> 6;
          \u0031C561093.\u00341173E9D obj2 = new \u0031C561093.\u00341173E9D((float) num5);
          num4 = num6 - 482433566U;
          this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj2);
          if ((1931492553 ^ (int) num4) == 0)
            goto label_1;
          else
            goto label_32;
        }
      }
      while (num1 == 1116147331U);
      num2 = 750599541U / num1;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u00343192462((char) obj1));
      return;
label_21:
      uint num13 = num1 * 1140939426U;
      object obj6 = obj1;
      num2 = num13 | 844435061U;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u003707D1DC6((sbyte) obj6));
      return;
label_22:
      uint num14 = num1 - 131669173U;
      \u0031C561093.\u0034C6A3A6D obj7 = new \u0031C561093.\u0034C6A3A6D((byte) obj1);
      num2 = 660298527U * num14;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj7);
      return;
label_23:
      num3 = num1 >> 22;
    }
    while (928544946U < num3);
    object obj8 = obj1;
    uint num15 = num3 >> 21;
    \u0031C561093.\u003292A58A9 obj9 = new \u0031C561093.\u003292A58A9((short) obj8);
    num2 = 1703359643U ^ num15;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj9);
    return;
label_25:
    uint num16 = 754940836U % num1;
    \u0031C561093.\u003727958FF obj10 = new \u0031C561093.\u003727958FF((ushort) obj1);
    num2 = num16 - 605423644U;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj10);
    return;
label_26:
    int num17 = (int) obj1;
    uint num18 = 1708327792U | num1;
    \u0031C561093.\u00348553D81 obj11 = new \u0031C561093.\u00348553D81(num17);
    num2 = num18 << 31;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj11);
    return;
label_12:
    return;
label_29:
    return;
label_34:
    object obj12 = obj1;
    uint num19 = num1 << 14;
    long num20 = (long) (ulong) obj12;
    num2 = 1400261517U >> (int) num19;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u00362E85068((ulong) num20));
    return;
label_32:
    return;
label_37:
    return;
label_41:
    throw new InvalidCastException();
  }

  private void \u00363AE4409()
  {
    uint num1 = (uint) (1011232958 & 2045666082);
    long num2 = this.\u00313EB2311;
    uint num3 = 1691554334U + num1 / 1983806053U;
    \u0031C561093.\u00304BE210E obj = this.\u003253508E5();
    uint num4 = num3 ^ 672736759U;
    int num5 = (int) obj.\u00377124934();
    uint num6 = num4 | 1703164440U;
    long num7 = (long) (uint) num5;
    uint num8 = 1553552492U - num6;
    long num9 = num2 + num7;
    uint num10 = 661994272U + num8;
    int num11 = Marshal.ReadInt32(new IntPtr(num9));
    uint num12 = 222044077U ^ num10;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(num11));
  }

  private void \u0032DF91857()
  {
    int typeToken;
    uint num1;
    uint num2;
    do
    {
      typeToken = this.\u003253508E5().E2D6F630();
      uint num3 = 1878612113;
      int num4;
      if (527791957 - (int) num3 != 0)
      {
        do
        {
          int num5 = typeToken;
          int num6 = (int) num3 - 1878612089;
          uint num7 = 2103011369U - num3;
          int num8 = num5 >> num6;
          num3 = 638860291U % num7;
          num4 = num8;
        }
        while (297338854U <= num3);
      }
      int num9 = num4;
      int num10 = (int) num3 ^ 190061785;
      num1 = 696793801U | num3;
      if (num9 <= num10)
      {
        switch (num4 - ((int) num1 ^ 735854298))
        {
          case 0:
          case 1:
            goto label_12;
          case 2:
          case 4:
            goto label_20;
          case 3:
            uint num11 = 993082605U - (num1 & 1659261008U);
            ModuleHandle moduleHandle1 = this.\u00318CB0DB9.ModuleHandle;
            uint num12 = 167919822U % num11;
            ModuleHandle moduleHandle2 = moduleHandle1;
            ref ModuleHandle local = ref moduleHandle2;
            int fieldToken = typeToken;
            uint num13 = num12 * 1990748995U;
            RuntimeFieldHandle runtimeFieldHandle = local.ResolveFieldHandle(fieldToken);
            uint num14 = num13 - 1959942167U;
            this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u003475922BE((object) runtimeFieldHandle));
            if (433983292 - (int) num14 != 0)
              return;
            continue;
          case 5:
            goto label_14;
        }
      }
      else
        goto label_7;
label_4:
      int num15 = num4;
      int num16 = (int) num1 ^ 735854289;
      num2 = num1 - 107882141U;
      if (num15 != num16)
      {
        if (num2 != 842932682U)
        {
          num1 = num2 + 107882141U;
          goto label_20;
        }
        else
          continue;
      }
      else
        goto label_16;
label_7:
      uint num17 = 1056401402U ^ num1;
      int num18 = num4;
      int num19 = (int) num17 ^ 355162426;
      num1 = num17 + 234438108U + 146253790U;
      if (num18 != num19)
      {
        uint num5 = 1406039283U * num1;
        if (num5 != 508254445U)
        {
          int num6 = num4;
          int num7 = (int) num5 - 63235510;
          num1 = num5 + 1446316275U + 3521269767U;
          if (num6 != num7)
          {
            num1 ^= 0U;
            goto label_20;
          }
          else
            goto label_14;
        }
        else
          continue;
      }
label_12:
      continue;
label_14:
      if (num1 >= 1347696258U)
        goto label_4;
      else
        goto label_15;
    }
    while (num1 == 1418345601U);
    uint num20 = num1 ^ 2080726520U;
    Module module1 = this.\u00318CB0DB9;
    uint num21 = num20 | 992623082U;
    ModuleHandle moduleHandle3 = module1.ModuleHandle;
    uint num22 = 1460875157U << (int) num21;
    ModuleHandle moduleHandle4 = moduleHandle3;
    uint num23 = 566701919U >> (int) num22;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u003475922BE((object) moduleHandle4.ResolveTypeHandle(typeToken)));
    return;
label_15:
    uint num24 = 933955773U * num1 % 801315803U;
    ModuleHandle moduleHandle5 = this.\u00318CB0DB9.ModuleHandle;
    uint num25 = num24 * 1507853587U;
    ModuleHandle moduleHandle6 = moduleHandle5;
    uint num26 = 1842903442U - num25;
    ref ModuleHandle local1 = ref moduleHandle6;
    uint num27 = num26 | 1172713153U;
    int methodToken1 = typeToken;
    uint num28 = num27 / 591154573U;
    RuntimeMethodHandle runtimeMethodHandle = local1.ResolveMethodHandle(methodToken1);
    uint num29 = num28 % 98505318U;
    \u0031C561093.\u003475922BE obj = new \u0031C561093.\u003475922BE((object) runtimeMethodHandle);
    num23 = num29 * 13581068U;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj);
    return;
label_16:
    try
    {
      uint num3 = num2 / 246746851U;
      do
      {
        ModuleHandle moduleHandle1 = this.\u00318CB0DB9.ModuleHandle;
        ref ModuleHandle local2 = ref moduleHandle1;
        int fieldToken = typeToken;
        num3 ^= 1298289786U;
        this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u003475922BE((object) local2.ResolveFieldHandle(fieldToken)));
      }
      while (1656163699 << (int) num3 == 0);
      return;
    }
    catch
    {
      uint num3 = 895447897U | (uint) (959513549 + 1818429860);
      Module module2 = this.\u00318CB0DB9;
      uint num4 = num3 ^ 777008484U;
      ModuleHandle moduleHandle1 = module2.ModuleHandle;
      uint num5 = num4 - 1314332380U;
      ModuleHandle moduleHandle2 = moduleHandle1;
      uint num6 = 1689142940U << (int) num5;
      ref ModuleHandle local2 = ref moduleHandle2;
      uint num7 = 421464515U >> (int) num6;
      int methodToken2 = typeToken;
      num23 = num7 ^ 1015552563U;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u003475922BE((object) local2.ResolveMethodHandle(methodToken2)));
      return;
    }
label_20:
    num23 = 1262831085U << (int) num1;
    throw new InvalidOperationException();
  }

  private void \u00345220DC2()
  {
    uint num1 = 1049761774;
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num2 = 1584102309U & num1;
    object obj2 = obj1.\u0035F319DE0();
    uint num3 = num2 | 444469366U;
    Exception exception = obj2 as Exception;
    uint num4 = 1398962354U / num3;
    if (exception == null)
      throw new ArgumentException();
    throw exception;
  }

  private void \u0034ECD6316()
  {
    uint num1 = 1736658793;
    if (this.\u0034B807558 == null)
      throw new InvalidOperationException();
    uint num2 = 453132860U << (int) (num1 << 27);
    throw this.\u0034B807558;
  }

  private void \u00367690095()
  {
    uint num1 = 1913607853;
    Type type1;
    if (num1 > 903379571U)
    {
      uint num2 = num1 << 27 >> 23;
      Type type2 = this.\u0033CE71CC6(this.\u003253508E5().E2D6F630());
      uint num3 = 1649764038U | num2;
      type1 = type2;
      num1 = num3 >> 18;
    }
    \u0031C561093.\u00304BE210E obj1;
    uint num4;
    do
    {
      uint num2 = 280313836U + num1;
      \u0031C561093.\u00304BE210E obj2 = this.\u003253508E5();
      uint num3 = num2 ^ 1390964220U;
      obj1 = obj2;
      uint num5 = num3 + 2043685330U;
      object obj3 = obj1.\u0035F319DE0();
      Type type2 = type1;
      uint num6 = num5 & 2121999480U;
      if (!this.\u0036B0E3E15(obj3, type2))
      {
        num4 = num6 * 735583595U;
        throw new InvalidCastException();
      }
      num1 = num6 ^ 572607182U;
    }
    while ((int) num1 << 7 == 0);
    uint num7 = 1757822147U | num1;
    \u0031C561093.\u00304BE210E obj4 = obj1;
    num4 = 196377611U / num7;
    this.\u0035FD24B62(obj4);
  }

  private void \u00345977C35()
  {
    uint num1 = 1816745162;
    \u0031C561093.\u00304BE210E obj1 = this.\u003253508E5();
    uint num2 = 178522462U % num1;
    int num3 = obj1.E2D6F630();
    uint num4 = num2 ^ 263916305U;
    Type type1 = this.\u0033CE71CC6(num3);
    uint num5 = num4 - 519726396U;
    Type type2 = type1;
    \u0031C561093.\u00304BE210E obj2;
    do
    {
      uint num6 = 520293680U ^ num5;
      obj2 = this.\u003253508E5();
      num5 = num6 << 10;
    }
    while (num5 < 912669207U);
    do
    {
      \u0031C561093.\u00304BE210E obj3 = obj2;
      uint num6 = num5 & 1694906488U;
      object obj4 = obj3.\u0035F319DE0();
      Type type3 = type2;
      uint num7 = num6 / 1858680761U;
      int num8 = this.\u0036B0E3E15(obj4, type3) ? 1 : 0;
      uint num9 = 512582677U * num7;
      if (num8 == 0)
        num5 = num9 >> 18;
      else
        goto label_5;
    }
    while (num5 > 1989938685U);
    uint num10 = 1221424109U & num5;
    \u0031C561093.\u00362DF5BD2 obj5 = new \u0031C561093.\u00362DF5BD2((object) null);
    uint num11 = 1471249150U + num10;
    obj2 = (\u0031C561093.\u00304BE210E) obj5;
    uint num12 = num11 ^ 1471249150U;
label_5:
    this.\u0035FD24B62(obj2);
  }

  private void \u00361DF0502()
  {
    \u0031C561093.\u00304BE210E obj1;
    uint num1;
    do
    {
      obj1 = this.\u003253508E5();
      uint num2;
      do
      {
        \u0031C561093.\u00304BE210E obj2 = obj1;
        num2 = 415517324U;
        if (!(obj2.\u0035F319DE0() is IConvertible))
          goto label_8;
      }
      while (2128284705U < num2);
      \u0031C561093.\u00304BE210E obj3 = obj1;
      uint num3 = 111217188U * num2;
      double d1 = obj3.\u00383BC968D();
      uint num4 = 2027687446U * num3;
      int num5 = double.IsNaN(d1) ? 1 : 0;
      uint num6 = num4 ^ 1811765820U;
      uint num7;
      if (num5 == 0)
      {
        double d2 = d1;
        uint num8 = num6 >> 10;
        int num9 = double.IsInfinity(d2) ? 1 : 0;
        num7 = 1952137768U >> (int) num8;
        if (num9 != 0)
          num6 = num7 + 3708792326U;
        else
          goto label_9;
      }
      if (num6 > 738208594U)
        throw new OverflowException();
      continue;
label_8:
      obj1 = (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(double.NaN);
      num7 = num2 ^ 415520666U;
label_9:
      num1 = 1462307076U & num7;
    }
    while (1968781080U < num1);
    uint num10 = num1 / 303045999U;
    this.\u0035FD24B62(obj1);
  }

  private unsafe void \u0030D231658()
  {
    IntPtr num1;
    uint num2;
    do
    {
      uint num3 = 1832542713;
      IntPtr cb = this.\u003253508E5().B8342F7A();
      uint num4 = num3 + 1493122803U;
      num1 = Marshal.AllocHGlobal(cb);
      List<IntPtr> numList = this.\u00326FE16FB;
      IntPtr num5 = num1;
      num2 = num4 << 4;
      numList.Add(num5);
    }
    while (615399937U == num2);
    do
    {
      uint num3 = 174462971U | num2;
      void* pointer = num1.ToPointer();
      uint num4 = 577991856U >> (int) num3;
      Type type = typeof (void*);
      uint num5 = num4 ^ 1130447116U;
      \u0031C561093.\u00362DF5BD2 obj = new \u0031C561093.\u00362DF5BD2(Pointer.Box(pointer, type));
      num2 = 1488666401U | num5;
      this.\u0035FD24B62((\u0031C561093.\u00304BE210E) obj);
    }
    while ((139350286 ^ (int) num2) == 0);
  }

  private void \u003735D1A0C()
  {
    uint num1 = 698569755;
    List<IntPtr> numList = this.\u00326FE16FB;
    uint num2 = 1183494U - num1;
    List<IntPtr>.Enumerator enumerator = numList.GetEnumerator();
    uint num3;
    try
    {
      while (true)
      {
        if (234499554U <= num2)
          goto label_4;
label_2:
        uint num4 = 799545263;
        ref List<IntPtr>.Enumerator local1 = ref enumerator;
        uint num5 = 1641169324U >> (int) num4;
        Marshal.FreeHGlobal(local1.Current);
        num2 = num5 ^ 3597564239U;
        continue;
label_4:
        ref List<IntPtr>.Enumerator local2 = ref enumerator;
        num3 = 330646345U * num2;
        if (local2.MoveNext())
          goto label_2;
        else
          break;
      }
    }
    finally
    {
      ref List<IntPtr>.Enumerator local = ref enumerator;
      num3 = 1920740005U;
      local.Dispose();
    }
  }

  public object \u00335B818BE(object[] _param1, int _param2)
  {
    uint num1;
    do
    {
      int num2 = _param2;
      uint num3 = 484910179;
      this.\u0035E5D486B = num2;
      num1 = num3 ^ 1055204311U;
    }
    while (num1 > 828271849U);
    object[] objArray = _param1;
    uint num4 = 674117956U + num1;
    this.\u0035FD24B62((\u0031C561093.\u00304BE210E) new \u0031C561093.\u0033745431B((Array) objArray));
label_2:
    object obj1;
    try
    {
      while (true)
      {
        try
        {
          uint num2;
          do
          {
            num2 = 203835423U;
            this.\u003342620F1[(uint) this.\u00353B340B3()]();
            if ((1493727288 & (int) num2) != 0)
            {
              if (this.\u0035E5D486B != 0)
                goto label_2;
            }
            else
              goto label_2;
          }
          while (((int) num2 ^ 1059653721) == 0);
          break;
        }
        catch (Exception ex)
        {
          if ((1283000372 ^ 1064896157) != 0)
            this.\u003668C74B0(ex);
        }
      }
      uint num3;
      do
      {
        object obj2 = this.\u003253508E5().\u0035F319DE0();
        num3 = 697725775U;
        obj1 = obj2;
      }
      while (num3 >= 1265844048U);
    }
    finally
    {
      this.\u003735D1A0C();
    }
    return obj1;
  }

  static \u0031C561093()
  {
    uint num;
    do
    {
      Dictionary<int, object> dictionary = new Dictionary<int, object>();
      num = 1109284117U;
      \u0031C561093.\u0031ACB10FF = dictionary;
    }
    while ((int) num + 986383727 == 0);
    do
    {
      Dictionary<MethodBase, DynamicMethod> dictionary = new Dictionary<MethodBase, DynamicMethod>();
      num += 1024491126U;
      \u0031C561093.\u003696E132D = dictionary;
    }
    while ((int) num - 1126499098 == 0);
  }

  private static class \u0036DD66A50
  {
  }

  private abstract class \u00304BE210E
  {
    public abstract \u0031C561093.\u00304BE210E \u00321939EB5();

    public abstract object \u0035F319DE0();

    public abstract void \u0036DCE2291(object _param1);

    public virtual bool \u0036736EEEA() => false;

    public virtual \u0031C561093.\u0033AF92E6D \u00366E9DD83() => throw new InvalidOperationException();

    public virtual \u0031C561093.\u00304BE210E \u0030323FE8D() => this;

    public virtual Type \u0030452B850() => throw new InvalidOperationException();

    public virtual TypeCode \u003363C3519() => throw new InvalidOperationException();

    public virtual bool \u0039CB63F4A() => Convert.ToBoolean(this.\u0035F319DE0());

    public virtual sbyte \u00309729E51() => Convert.ToSByte(this.\u0035F319DE0());

    public virtual short E66DE219()
    {
      uint num = (uint) (349002956 + 1694654183);
      return Convert.ToInt16(this.\u0035F319DE0());
    }

    public virtual int E2D6F630() => Convert.ToInt32(this.\u0035F319DE0());

    public virtual long D500CE01()
    {
      uint num1 = (uint) (2072331676 | 752289118);
      object obj = this.\u0035F319DE0();
      uint num2 = num1 & 1958508841U;
      return Convert.ToInt64(obj);
    }

    public virtual char FCB291BE()
    {
      uint num1 = 1893422050;
      object obj = this.\u0035F319DE0();
      uint num2 = num1 % 1459299046U;
      return Convert.ToChar(obj);
    }

    public virtual byte \u00342E17D34()
    {
      uint num1 = (uint) (1002654211 * 1622804126);
      object obj = this.\u0035F319DE0();
      uint num2 = 1147538714U & num1;
      return Convert.ToByte(obj);
    }

    public virtual ushort DD7230A3()
    {
      uint num = 448803612U >> 29;
      return Convert.ToUInt16(this.\u0035F319DE0());
    }

    public virtual uint \u00377124934()
    {
      uint num1 = 340285587;
      object obj = this.\u0035F319DE0();
      uint num2 = num1 - 10049071U;
      return Convert.ToUInt32(obj);
    }

    public virtual ulong \u00353FB65C3() => Convert.ToUInt64(this.\u0035F319DE0());

    public virtual float BA2939E9() => Convert.ToSingle(this.\u0035F319DE0());

    public virtual double \u00383BC968D() => Convert.ToDouble(this.\u0035F319DE0());

    public override string ToString()
    {
      uint num1 = 1409559595;
      object obj1 = this.\u0035F319DE0();
      uint num2 = 1510230650U / num1;
      uint num3;
      if (num2 <= 662010957U)
      {
        if (obj1 == null)
          num3 = 288826387U | num2;
        else if (716966464 + (int) num2 != 0)
        {
          object obj2 = obj1;
          num3 = 901337647U / num2;
          return Convert.ToString(obj2);
        }
      }
      return (string) null;
    }

    public virtual IntPtr B8342F7A() => throw new InvalidOperationException();

    public virtual UIntPtr \u0032452299F() => throw new InvalidOperationException();

    public virtual unsafe void* \u003480545A0() => throw new InvalidOperationException();

    public virtual object C5EE7C38(Type _param1, bool _param2) => throw new InvalidOperationException();

    protected \u00304BE210E()
    {
      uint num;
      do
      {
        num = 722224867U;
        // ISSUE: explicit constructor call
        base.\u002Ector();
      }
      while (86711681U == num);
    }
  }

  private abstract class \u0033AF92E6D : \u0031C561093.\u00304BE210E
  {
    public override \u0031C561093.\u0033AF92E6D \u00366E9DD83() => this;

    public override TypeCode \u003363C3519() => (TypeCode) (1464795243 ^ 1464795243);
  }

  private sealed class \u00348553D81 : \u0031C561093.\u0033AF92E6D
  {
    private int \u0033D8E52EB;

    public \u00348553D81(int _param1)
    {
      uint num = 1629887166;
      do
      {
        // ISSUE: explicit constructor call
        base.\u002Ector();
        num = 94253940U + num;
        this.\u0033D8E52EB = _param1;
      }
      while (num == 2126261317U);
    }

    public override Type \u0030452B850()
    {
      uint num1 = 813526143;
      // ISSUE: type reference
      RuntimeTypeHandle handle = __typeref (int);
      uint num2 = num1 + 1114331699U;
      return Type.GetTypeFromHandle(handle);
    }

    public override TypeCode \u003363C3519() => TypeCode.Int32;

    public override \u0031C561093.\u00304BE210E \u00321939EB5() => (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(this.\u0033D8E52EB);

    public override object \u0035F319DE0()
    {
      uint num = 183533045U % 798781085U;
      return (object) this.\u0033D8E52EB;
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num1 = 234257010;
      do
      {
        uint num2 = 316285888U / num1;
        int int32 = Convert.ToInt32(_param1);
        num1 = num2 / 1477257663U;
        this.\u0033D8E52EB = int32;
      }
      while ((2090285481 & (int) num1) != 0);
    }

    public override bool \u0039CB63F4A() => (uint) this.\u0033D8E52EB > 0U;

    public override sbyte \u00309729E51()
    {
      uint num1 = (uint) (1803169472 & 132732399);
      int num2 = this.\u0033D8E52EB;
      uint num3 = 1821854808U >> (int) num1;
      return (sbyte) num2;
    }

    public override short E66DE219() => (short) this.\u0033D8E52EB;

    public override int E2D6F630() => this.\u0033D8E52EB;

    public override long D500CE01() => (long) this.\u0033D8E52EB;

    public override char FCB291BE() => (char) this.\u0033D8E52EB;

    public override byte \u00342E17D34() => (byte) this.\u0033D8E52EB;

    public override ushort DD7230A3()
    {
      uint num1 = 384251252;
      int num2 = this.\u0033D8E52EB;
      uint num3 = num1 & 1325682475U;
      return (ushort) num2;
    }

    public override uint \u00377124934() => (uint) this.\u0033D8E52EB;

    public override ulong \u00353FB65C3()
    {
      uint num1 = (uint) (276125914 & 893086424);
      int num2 = this.\u0033D8E52EB;
      uint num3 = num1 ^ 435835613U;
      return (ulong) (uint) num2;
    }

    public override float BA2939E9()
    {
      uint num1 = 463363505;
      int num2 = this.\u0033D8E52EB;
      uint num3 = 1462065315U + num1;
      return (float) num2;
    }

    public override double \u00383BC968D()
    {
      uint num1 = 422927325;
      int num2 = this.\u0033D8E52EB;
      uint num3 = num1 | 1129798155U;
      return (double) num2;
    }

    public override IntPtr B8342F7A() => new IntPtr(this.\u0033D8E52EB);

    public override UIntPtr \u0032452299F()
    {
      uint num = 323488648U % 1978411571U;
      return new UIntPtr((uint) this.\u0033D8E52EB);
    }

    public override \u0031C561093.\u00304BE210E \u0030323FE8D()
    {
      uint num1 = 863905246;
      int num2 = this.\u0033D8E52EB;
      uint num3 = 1576685667U << (int) num1;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00328355445((uint) num2);
    }

    public override object C5EE7C38(Type _param1, bool _param2)
    {
      uint num1 = 1956121156;
label_1:
      do
      {
        uint num2;
        uint num3;
        uint num4;
        do
        {
          Type type1 = _param1;
          Type type2 = typeof (IntPtr);
          num1 <<= 10;
          if ((object) type1 != (object) type2 && num1 != 1088766954U)
            goto label_17;
label_2:
          uint num5;
          uint num6;
          long num7;
          int num8;
          do
          {
            int size = IntPtr.Size;
            uint num9 = num1 / 1567711198U;
            int num10 = (int) num9 - -3;
            uint num11 = num9 * 2083993314U;
            if (size == num10)
            {
              num1 = 1309347344U >> (int) num11;
              if (num1 / 1401825239U == 0U)
              {
                if (!_param2)
                {
                  num1 &= 30611987U;
                  if (num1 <= 1829588977U)
                    goto label_6;
                }
                else
                {
                  num1 >>= 29;
                  if (1148390874U > num1)
                  {
                    uint num12 = num1 ^ 269050223U;
                    int num13 = (int) checked ((uint) this.\u0033D8E52EB);
                    uint num14 = num12 | 1817660016U;
                    num8 = checked ((int) (uint) num13);
                    num5 = num14 ^ 1552566479U;
                    goto label_9;
                  }
                  else
                    goto label_1;
                }
              }
            }
            else
            {
              num1 = num11 >> 26;
              if ((int) num1 << 26 != 0)
              {
                int num12 = _param2 ? 1 : 0;
                uint num13 = 39060006U >> (int) num1;
                if (num12 == 0)
                {
                  num1 = 938556689U - num13;
                  if ((int) num1 - 355101180 != 0)
                  {
                    uint num14 = 1575689038U & num1;
                    int num15 = this.\u0033D8E52EB;
                    num6 = num14 * 1642402620U;
                    num7 = (long) num15;
                    goto label_16;
                  }
                  else
                    goto label_1;
                }
                else
                  num1 = num13 / 281706193U;
              }
              else
                goto label_1;
            }
          }
          while (((int) num1 & 1145450616) != 0);
          uint num16 = num1 << 8;
          num7 = (long) (uint) this.\u0033D8E52EB;
          num6 = num16 ^ 849140736U;
label_16:
          uint num17 = num6 >> 14;
          IntPtr num18 = new IntPtr(num7);
          num2 = num17 >> 21;
          return (object) num18;
label_6:
          num5 = num1 ^ 559358384U;
          num8 = this.\u0033D8E52EB;
label_9:
          num2 = 1796681855U - num5;
          return (object) new IntPtr(num8);
label_17:
          Type type3 = _param1;
          Type type4 = typeof (UIntPtr);
          num1 = 81156365U - num1;
          if ((object) type3 == (object) type4)
          {
            if ((int) num1 - 349780099 != 0)
            {
              int num9 = _param2 ? 1 : 0;
              num1 -= 1693804776U;
              uint num10;
              int num11;
              if (num9 == 0)
              {
                uint num12 = 85020130U - num1;
                int num13 = this.\u0033D8E52EB;
                num10 = 1725324231U | num12;
                num11 = (int) checked ((uint) num13);
              }
              else if (2135425024U >= num1)
              {
                num11 = this.\u0033D8E52EB;
                num10 = num1 + 2821169114U;
              }
              else
                goto label_2;
              num2 = num10 * 1634156450U;
              return (object) new UIntPtr((uint) num11);
            }
          }
          else
          {
            TypeCode typeCode = Type.GetTypeCode(_param1);
            if (912162183U != num1)
            {
              int num9 = (int) typeCode;
              uint num10 = 669189157U / num1;
              int num11 = (int) num10 ^ 5;
              uint num12 = 1056266382U * num10;
              int num13 = num9 - num11;
              num1 = 664218910U >> (int) num12;
              switch (num13)
              {
                case 0:
                  num1 = 278860344U + num1;
                  if (1995662633U > num1)
                  {
                    int num14 = _param2 ? 1 : 0;
                    num1 >>= 19;
                    uint num15;
                    int num19;
                    if (num14 == 0)
                    {
                      if (((int) num1 & 1687511451) != 0)
                      {
                        uint num20 = 1519211773U - num1;
                        int num21 = this.\u0033D8E52EB;
                        num15 = 1006701087U & num20;
                        num19 = (int) checked ((sbyte) num21);
                      }
                      else
                        goto label_2;
                    }
                    else if (500709249U / num1 != 0U)
                    {
                      num19 = (int) checked ((sbyte) (uint) this.\u0033D8E52EB);
                      num15 = num1 ^ 402722577U;
                    }
                    else
                      goto label_6;
                    num2 = 1863718718U + num15;
                    return (object) (sbyte) num19;
                  }
                  continue;
                case 1:
                  num1 = 719027053U << (int) num1;
                  continue;
                case 2:
                  num1 /= 987060221U;
                  uint num22;
                  int num23;
                  if (!_param2)
                  {
                    if ((333780519 & (int) num1) == 0)
                    {
                      num22 = num1 % 2044014810U;
                      num23 = (int) checked ((short) this.\u0033D8E52EB);
                    }
                    else
                      goto label_2;
                  }
                  else
                  {
                    num1 ^= 722172790U;
                    if (1874806913U != num1)
                    {
                      int num14 = this.\u0033D8E52EB;
                      uint num15 = 1197016497U - num1;
                      int num19 = (int) checked ((uint) num14);
                      uint num20 = num15 << 30;
                      num23 = (int) checked ((short) (uint) num19);
                      num22 = num20 ^ 3221225472U;
                    }
                    else
                      continue;
                  }
                  num2 = num22 + 1261654810U;
                  return (object) (short) num23;
                case 3:
                  if (num1 != 510461956U)
                  {
                    int num14 = _param2 ? 1 : 0;
                    num3 = 962022464U % num1;
                    if (num14 != 0)
                    {
                      num1 = num3 + 2078288089U;
                      if ((1980105802 ^ (int) num1) == 0)
                        goto label_2;
                      else
                        goto label_62;
                    }
                    else
                      goto label_60;
                  }
                  else
                    continue;
                case 4:
                  num1 = 1270622762U / num1;
                  if ((int) num1 - 1621759579 != 0)
                  {
                    int num14;
                    if (!_param2)
                      num14 = this.\u0033D8E52EB;
                    else if (num1 != 1185762596U)
                    {
                      uint num15 = 1694696993U / num1;
                      int num19 = this.\u0033D8E52EB;
                      uint num20 = num15 / 1122905965U;
                      int num21 = (int) checked ((uint) num19);
                      uint num24 = 1485650208U % num20;
                      num14 = checked ((int) (uint) num21);
                      num2 = num24 + 1U;
                    }
                    else
                      goto label_2;
                    return (object) num14;
                  }
                  goto label_6;
                case 5:
                  num4 = 1247150856U + num1;
                  if (_param2)
                  {
                    num1 = 1198282273U >> (int) num4;
                    if (811013559 << (int) num1 == 0)
                      goto label_6;
                    else
                      goto label_67;
                  }
                  else
                    goto label_65;
                case 6:
                  if (1685208260 << (int) num1 == 0)
                  {
                    int num14 = _param2 ? 1 : 0;
                    num1 = 193420678U % num1;
                    long num15;
                    if (num14 == 0)
                    {
                      num1 &= 859594251U;
                      if (num1 != 1743606517U)
                        num15 = (long) this.\u0033D8E52EB;
                      else
                        goto label_2;
                    }
                    else if (num1 % 418912111U != 0U)
                    {
                      uint num19 = num1 & 200943280U;
                      num15 = (long) (uint) this.\u0033D8E52EB;
                      num2 = num19 ^ 143022210U;
                    }
                    else
                      goto label_2;
                    return (object) num15;
                  }
                  goto label_6;
                case 7:
                  goto label_69;
                case 8:
                  goto label_78;
                case 9:
                  num1 = 593036190U / num1;
                  if (num1 >= 2088788336U)
                    goto label_2;
                  else
                    goto label_74;
                default:
                  num1 ^= 0U;
                  goto label_78;
              }
            }
          }
        }
        while (num1 == 522145232U);
        int num25 = _param2 ? 1 : 0;
        uint num26 = 1236946638U | num1;
        int num27;
        if (num25 == 0)
        {
          num2 = num26 << 15;
          num27 = (int) checked ((byte) this.\u0033D8E52EB);
        }
        else
        {
          uint num5 = 1754208537U ^ num26;
          int num6 = this.\u0033D8E52EB;
          uint num7 = num5 + 678243833U;
          int num8 = (int) checked ((uint) num6);
          uint num9 = num7 * 1080251586U;
          num27 = (int) checked ((byte) num8);
          num2 = num9 + 1189435488U;
        }
        return (object) (byte) num27;
label_60:
        uint num28 = num3 & 241790049U | 1432118948U;
        int num29 = this.\u0033D8E52EB;
        uint num30 = 2076012766U + num28;
        int num31 = (int) checked ((ushort) num29);
        goto label_63;
label_62:
        uint num32 = num1 & 1768820563U;
        int num33 = this.\u0033D8E52EB;
        uint num34 = num32 * 553546967U;
        int num35 = (int) checked ((uint) num33);
        uint num36 = num34 + 476404360U;
        num31 = (int) checked ((ushort) num35);
        num30 = num36 + 3810705989U;
label_63:
        num2 = 444235004U / num30;
        return (object) (ushort) num31;
label_65:
        uint num37 = 528177287U / num4;
        int num38 = this.\u0033D8E52EB;
        num2 = num37 << 11;
        int num39 = (int) checked ((uint) num38);
        goto label_68;
label_67:
        num39 = this.\u0033D8E52EB;
        num2 = num1 ^ 18723160U;
label_68:
        return (object) (uint) num39;
label_69:
        uint num40;
        int num41;
        if (!_param2)
        {
          int num5 = this.\u0033D8E52EB;
          num40 = num1 % 1949771253U;
          num41 = (int) checked ((uint) num5);
        }
        else
        {
          num41 = this.\u0033D8E52EB;
          num40 = num1 ^ 0U;
        }
        num2 = 600987224U % num40;
        return (object) (uint) num41;
label_74:
        int num42 = _param2 ? 1 : 0;
        uint num43 = num1 % 1218993256U;
        uint num44;
        double num45;
        if (num42 == 0)
        {
          uint num5 = 145241258U + num43;
          int num6 = this.\u0033D8E52EB;
          num44 = 332944389U >> (int) num5;
          num45 = (double) num6;
        }
        else
        {
          int num5 = this.\u0033D8E52EB;
          uint num6 = num43 / 1229081943U;
          num45 = (double) (uint) num5;
          num44 = num6 + 325141U;
        }
        num2 = num44 & 804472590U;
        return (object) num45;
label_78:;
      }
      while (num1 > 1620589842U);
      throw new ArgumentException();
    }
  }

  private sealed class \u00304E67D6F : \u0031C561093.\u0033AF92E6D
  {
    private long \u00359BC7F14;

    public \u00304E67D6F(long _param1)
    {
      uint num1 = 1722296763;
      if (num1 < 702378368U)
        return;
      long num2 = _param1;
      uint num3 = 1698249033U - num1;
      this.\u00359BC7F14 = num2;
    }

    public override Type \u0030452B850() => typeof (long);

    public override TypeCode \u003363C3519() => TypeCode.Int64;

    public override \u0031C561093.\u00304BE210E \u0030323FE8D()
    {
      uint num1 = 1818756902;
      long num2 = this.\u00359BC7F14;
      uint num3 = num1 / 1517247046U;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00362E85068((ulong) num2);
    }

    public override \u0031C561093.\u00304BE210E \u00321939EB5() => (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(this.\u00359BC7F14);

    public override object \u0035F319DE0() => (object) this.\u00359BC7F14;

    public override void \u0036DCE2291(object _param1)
    {
      uint num = 2042915147;
      do
      {
        long int64 = Convert.ToInt64(_param1);
        num = 1775635481U >> (int) num;
        this.\u00359BC7F14 = int64;
      }
      while (793864745 + (int) num == 0);
    }

    public override bool \u0039CB63F4A() => (ulong) this.\u00359BC7F14 > (ulong) (1033901644 - 168692304 - 865209340);

    public override char FCB291BE()
    {
      uint num1 = 214904593U >> 1496975864;
      long num2 = this.\u00359BC7F14;
      uint num3 = num1 | 823604066U;
      return (char) num2;
    }

    public override byte \u00342E17D34() => (byte) this.\u00359BC7F14;

    public override sbyte \u00309729E51() => (sbyte) this.\u00359BC7F14;

    public override short E66DE219()
    {
      uint num = (uint) (829315805 ^ 1756892282);
      return (short) this.\u00359BC7F14;
    }

    public override int E2D6F630() => (int) this.\u00359BC7F14;

    public override long D500CE01() => this.\u00359BC7F14;

    public override ushort DD7230A3() => (ushort) this.\u00359BC7F14;

    public override uint \u00377124934() => (uint) this.\u00359BC7F14;

    public override ulong \u00353FB65C3() => (ulong) this.\u00359BC7F14;

    public override float BA2939E9() => (float) this.\u00359BC7F14;

    public override double \u00383BC968D()
    {
      uint num1 = (uint) (1817932399 | 152309650);
      long num2 = this.\u00359BC7F14;
      uint num3 = 1910902361U ^ num1;
      return (double) num2;
    }

    public override IntPtr B8342F7A()
    {
      uint num1 = 2121223543;
      uint num2;
      long num3;
      if (111364913 + (int) num1 != 0)
      {
        do
        {
          int size = IntPtr.Size;
          uint num4 = 2065202808U % num1;
          int num5 = (int) num4 - 2065202804;
          num1 = num4 | 97533799U;
          if (size != num5)
          {
            num1 |= 884093453U;
            if (num1 > 1238500527U)
              goto label_3;
          }
        }
        while ((int) num1 - 357391800 == 0);
        uint num6 = 2025937296U - num1;
        int num7 = (int) this.\u00359BC7F14;
        uint num8 = 1943609492U / num6;
        long num9 = (long) num7;
        num2 = num8 + 2147123199U;
        num3 = num9;
        goto label_6;
      }
label_3:
      num2 = 1904901550U | num1;
      num3 = this.\u00359BC7F14;
label_6:
      uint num10 = 1495356539U / num2;
      return new IntPtr(num3);
    }

    public override UIntPtr \u0032452299F()
    {
      uint num1 = 567674122;
      int size = UIntPtr.Size;
      uint num2 = 959009913U - num1;
      int num3 = (int) num2 ^ 391335787;
      uint num4 = 1762882621U ^ num2;
      long num5;
      if (size != num3)
      {
        num5 = this.\u00359BC7F14;
      }
      else
      {
        uint num6 = num4 + 1417507864U;
        long num7 = this.\u00359BC7F14;
        uint num8 = num6 | 1866290503U;
        num5 = (long) (uint) num7;
        uint num9 = num8 + 2122464227U;
      }
      return new UIntPtr((ulong) num5);
    }

    public override object C5EE7C38(Type _param1, bool _param2)
    {
      uint num1;
      do
      {
        uint num2;
        uint num3;
        uint num4;
        uint num5;
        uint num6;
        int num7;
        do
        {
          uint num8;
          do
          {
            uint num9;
            do
            {
              uint num10;
              uint num11;
              long num12;
              do
              {
                uint num13;
                do
                {
                  Type type1 = _param1;
                  // ISSUE: type reference
                  RuntimeTypeHandle handle = __typeref (IntPtr);
                  uint num14 = 1326998470;
                  Type typeFromHandle = Type.GetTypeFromHandle(handle);
                  num1 = num14 ^ 2097899829U;
                  if ((object) type1 == (object) typeFromHandle)
                  {
                    num1 /= 1472028127U;
                    if (2134924921U == num1)
                      continue;
                  }
                  else
                    goto label_7;
label_2:
                  int num15 = _param2 ? 1 : 0;
                  num13 = 910327317U + num1;
                  if (num15 == 0)
                    continue;
                  goto label_5;
label_7:
                  Type type2 = _param1;
                  num1 = 1816688533U / num1;
                  Type type3 = typeof (UIntPtr);
                  if ((object) type2 != (object) type3)
                  {
                    if (num1 != 1976249104U)
                    {
                      TypeCode typeCode = Type.GetTypeCode(_param1);
                      num8 = 2096254109U % num1;
label_17:
                      int num16 = (int) typeCode;
                      int num17 = (int) num8 + 4;
                      num1 = 1727689393U << (int) num8;
                      switch (num16 - num17)
                      {
                        case 0:
                          goto label_19;
                        case 1:
                          if (1089936621U % num1 == 0U)
                            goto label_7;
                          else
                            goto label_41;
                        case 2:
                          goto label_24;
                        case 3:
                          num8 = num1 | 1295404527U;
                          if (632387380 - (int) num8 == 0)
                            goto label_17;
                          else
                            goto label_46;
                        case 4:
                          goto label_30;
                        case 5:
                          if (((int) num1 ^ 2110919039) == 0)
                            goto label_2;
                          else
                            goto label_51;
                        case 6:
                          goto label_34;
                        case 7:
                          uint num18 = num1 * 996410573U;
                          int num19 = _param2 ? 1 : 0;
                          num5 = num18 << 24;
                          if (num19 != 0)
                          {
                            num1 = num5 + 1780691049U;
                            if (2042761516U >> (int) num1 == 0U)
                              goto label_2;
                            else
                              goto label_59;
                          }
                          else
                            goto label_57;
                        case 8:
                          goto label_67;
                        case 9:
                          num6 = 150365718U << (int) num1;
                          if (_param2)
                          {
                            num1 = 1371220099U * num6;
                            if (1746149953U >= num1)
                              goto label_2;
                            else
                              goto label_65;
                          }
                          else
                            goto label_62;
                        default:
                          goto label_18;
                      }
                    }
                    else
                      goto label_2;
                  }
                  else
                    goto label_8;
                }
                while ((377625613 & (int) num13) == 0);
label_4:
                long num20 = this.\u00359BC7F14;
                goto label_6;
label_5:
                uint num21 = num13 | 519926042U;
                long num22 = (long) checked ((ulong) this.\u00359BC7F14);
                uint num23 = num21 << 17;
                num20 = checked ((long) (ulong) num22);
                num2 = num23 + 939818517U;
label_6:
                return (object) new IntPtr(num20);
label_8:
                num1 = 1689346956U + num1;
label_9:
                if (!_param2)
                {
                  if (21188438U <= num1)
                  {
                    long num14 = this.\u00359BC7F14;
                    num10 = 737834670U - num1;
                    num12 = (long) checked ((ulong) num14);
                    goto label_14;
                  }
                  else
                    goto label_4;
                }
                else
                {
                  num11 = num1 * 1975342002U;
                  continue;
                }
label_24:
                if (_param2)
                {
                  if (709963864U == num1)
                    goto label_9;
                  else
                    goto label_28;
                }
                else
                  goto label_25;
              }
              while (num11 < 1097998611U);
              uint num24 = num11 % 1860514370U;
              num12 = this.\u00359BC7F14;
              num10 = num24 + 3097441512U;
label_14:
              num2 = num10 << 15;
              return (object) new UIntPtr((ulong) num12);
label_18:
              num1 += 0U;
              goto label_67;
label_19:
              num9 = 1583312589U * num1;
            }
            while (num9 >= 1254691637U);
            int num25;
            if (!_param2)
            {
              num25 = (int) checked ((sbyte) this.\u00359BC7F14);
            }
            else
            {
              uint num10 = 457070091U | num9;
              num25 = (int) checked ((sbyte) (ulong) this.\u00359BC7F14);
              num2 = num10 + 3888770047U;
            }
            return (object) (sbyte) num25;
label_25:;
          }
          while ((int) num1 * 716387121 == 0);
          long num26 = this.\u00359BC7F14;
          num2 = 1603340828U + num1;
          int num27 = (int) checked ((short) num26);
          goto label_29;
label_28:
          long num28 = this.\u00359BC7F14;
          uint num29 = num1 / 2118726170U;
          num27 = (int) checked ((short) (ulong) num28);
          num2 = num29 ^ 763752319U;
label_29:
          return (object) (short) num27;
label_30:
          int num30 = _param2 ? 1 : 0;
          uint num31 = 1902718651U - num1;
          int num32;
          if (num30 == 0)
          {
            uint num9 = 479153706U >> (int) num31;
            long num10 = this.\u00359BC7F14;
            num2 = num9 & 451499515U;
            num32 = checked ((int) num10);
          }
          else
          {
            uint num9 = 1450978988U & num31;
            long num10 = (long) checked ((ulong) this.\u00359BC7F14);
            uint num11 = 1697866093U * num9;
            num32 = checked ((int) (ulong) num10);
            num2 = num11 ^ 3289019234U;
          }
          return (object) num32;
label_34:
          uint num33 = num1 | 382484956U;
          if (((int) num33 & 284442385) != 0)
          {
            long num9;
            if (!_param2)
            {
              if (((int) (num33 & 674829973U) ^ 1538394665) != 0)
                num9 = this.\u00359BC7F14;
              else
                continue;
            }
            else
            {
              uint num10 = 429338228U * num33;
              long num11 = this.\u00359BC7F14;
              uint num12 = 1247612979U << (int) num10;
              num9 = checked ((long) (ulong) num11);
              num2 = num12 ^ 993526932U;
            }
            return (object) num9;
          }
          continue;
label_41:
          int num34 = _param2 ? 1 : 0;
          uint num35 = 297416913U / num1;
          uint num36;
          int num37;
          if (num34 == 0)
          {
            uint num9 = 783030154U + num35 + 182010707U;
            long num10 = this.\u00359BC7F14;
            num36 = num9 % 21563804U;
            num37 = (int) checked ((byte) num10);
          }
          else
          {
            uint num9 = num35 ^ 1257639272U;
            long num10 = this.\u00359BC7F14;
            uint num11 = 785001178U >> (int) num9;
            long num12 = (long) checked ((ulong) num10);
            uint num13 = 980974258U + num11;
            num37 = (int) checked ((byte) num12);
            num36 = num13 + 3327160113U;
          }
          num2 = 1812207052U << (int) num36;
          return (object) (byte) num37;
label_46:
          uint num38;
          int num39;
          if (!_param2)
          {
            long num9 = this.\u00359BC7F14;
            num38 = 1486169910U % num8;
            num39 = (int) checked ((ushort) num9);
          }
          else
          {
            uint num9 = 1831691817U + num8;
            num39 = (int) checked ((ushort) this.\u00359BC7F14);
            num38 = num9 + 493933342U;
          }
          num2 = num38 << 26;
          return (object) (ushort) num39;
label_51:
          int num40 = _param2 ? 1 : 0;
          uint num41 = num1 % 1543927533U;
          if (num40 == 0)
          {
            num3 = 225449035U << (int) num41 | 1644955221U;
            num7 = (int) checked ((uint) this.\u00359BC7F14);
            goto label_55;
          }
          else
            num4 = 558192140U - num41;
        }
        while (1016084674U <= num4);
        uint num42 = 247559949U & num4;
        long num43 = (long) checked ((ulong) this.\u00359BC7F14);
        uint num44 = num42 << 22;
        num7 = (int) checked ((uint) num43);
        num3 = num44 ^ 4078718805U;
label_55:
        num2 = 1997094546U / num3;
        return (object) (uint) num7;
label_57:
        uint num45 = num5 * 859121687U;
        long num46 = this.\u00359BC7F14;
        uint num47 = num45 + 1508576940U;
        long num48 = (long) checked ((ulong) num46);
        goto label_60;
label_59:
        num48 = this.\u00359BC7F14;
        num47 = num1 ^ 2882027205U;
label_60:
        num2 = num47 ^ 1641681995U;
        return (object) (ulong) num48;
label_62:
        uint num49 = num6 << 16;
        double num50;
        if (188762382U >> (int) num49 != 0U)
        {
          uint num8 = num49 % 1487233492U;
          long num9 = this.\u00359BC7F14;
          num2 = num8 >> 13;
          num50 = (double) num9;
          goto label_66;
        }
        else
          continue;
label_65:
        long num51 = this.\u00359BC7F14;
        uint num52 = 2005752354U / num1;
        num50 = (double) (ulong) num51;
        num2 = num52 + 130452U;
label_66:
        return (object) num50;
label_67:;
      }
      while (1947886449U > num1);
      throw new ArgumentException();
    }
  }

  private sealed class \u00341173E9D : \u0031C561093.\u0033AF92E6D
  {
    private float \u003742739A7;

    public \u00341173E9D(float _param1)
    {
      uint num1;
      do
      {
        num1 = 1145508769U;
        // ISSUE: explicit constructor call
        base.\u002Ector();
      }
      while (1850955540U == num1);
      double num2 = (double) _param1;
      uint num3 = num1 ^ 888824599U;
      this.\u003742739A7 = (float) num2;
    }

    public override Type \u0030452B850()
    {
      uint num1 = 476412941;
      // ISSUE: type reference
      RuntimeTypeHandle handle = __typeref (float);
      uint num2 = 769339213U - num1;
      return Type.GetTypeFromHandle(handle);
    }

    public override TypeCode \u003363C3519() => (TypeCode) (1224496090 - 1224496077);

    public override \u0031C561093.\u00304BE210E \u00321939EB5() => (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00341173E9D(this.\u003742739A7);

    public override object \u0035F319DE0()
    {
      uint num1 = (uint) (71660456 + 361041957);
      double num2 = (double) this.\u003742739A7;
      uint num3 = num1 << 22;
      return (object) (float) num2;
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num = 1948125462;
      if (2074615737U <= num)
        return;
      do
      {
        double single = (double) Convert.ToSingle(_param1);
        num = 349636491U << (int) num;
        this.\u003742739A7 = (float) single;
      }
      while (num / 1252416517U == 0U);
    }

    public override bool \u0039CB63F4A()
    {
      uint num1 = (uint) (792165759 << 13);
      double num2 = (double) this.\u003742739A7;
      uint num3 = 1143742619U - num1;
      return Convert.ToBoolean((float) num2);
    }

    public override sbyte \u00309729E51() => (sbyte) this.\u003742739A7;

    public override short E66DE219() => (short) this.\u003742739A7;

    public override int E2D6F630() => (int) this.\u003742739A7;

    public override long D500CE01() => (long) this.\u003742739A7;

    public override char FCB291BE() => (char) this.\u003742739A7;

    public override byte \u00342E17D34()
    {
      uint num1 = 337861229;
      double num2 = (double) this.\u003742739A7;
      uint num3 = 770262901U % num1;
      return (byte) num2;
    }

    public override ushort DD7230A3()
    {
      uint num1 = (uint) (2089945532 << 3);
      double num2 = (double) this.\u003742739A7;
      uint num3 = num1 & 79972653U;
      return (ushort) num2;
    }

    public override uint \u00377124934()
    {
      uint num = (uint) (490612073 - 547885676);
      return (uint) this.\u003742739A7;
    }

    public override ulong \u00353FB65C3()
    {
      uint num = 2127789946U % 734872578U;
      return (ulong) this.\u003742739A7;
    }

    public override float BA2939E9() => this.\u003742739A7;

    public override double \u00383BC968D()
    {
      uint num1 = 50555129;
      double num2 = (double) this.\u003742739A7;
      uint num3 = num1 / 1125008064U;
      return num2;
    }

    public override IntPtr B8342F7A()
    {
      int size = IntPtr.Size;
      uint num1 = 1346704416;
      uint num2;
      long num3;
      if (size != 4 || num1 <= 24408442U)
      {
        num2 = num1 >> 27;
        num3 = (long) this.\u003742739A7;
      }
      else
      {
        int num4 = (int) this.\u003742739A7;
        uint num5 = 1094597249U + num1;
        long num6 = (long) num4;
        num2 = num5 + 1853665641U;
        num3 = num6;
      }
      uint num7 = 54092104U | num2;
      return new IntPtr(num3);
    }

    public override UIntPtr \u0032452299F()
    {
      uint num1 = 818887966;
      uint num2;
      long num3;
      if (num1 <= 1710454490U)
      {
        int size = IntPtr.Size;
        num1 <<= 1;
        int num4 = (int) num1 - 1637775928;
        if (size == num4 && 1033849821U != num1)
        {
          int num5 = (int) (uint) this.\u003742739A7;
          uint num6 = num1 / 1457601707U;
          long num7 = (long) (uint) num5;
          num2 = num6 ^ 668U;
          num3 = num7;
          goto label_4;
        }
      }
      uint num8 = num1 + 1171722276U;
      double num9 = (double) this.\u003742739A7;
      num2 = num8 >> 22;
      num3 = (long) (ulong) num9;
label_4:
      uint num10 = 1669162325U & num2;
      return new UIntPtr((ulong) num3);
    }

    public override object C5EE7C38(Type _param1, bool _param2)
    {
      uint num1;
      do
      {
        uint num2;
        uint num3;
        uint num4;
        uint num5;
        int num6;
        do
        {
          uint num7;
          int num8;
          do
          {
            Type type1 = _param1;
            uint num9 = 1675757593;
            Type type2 = typeof (IntPtr);
            uint num10 = num9 + 2011500039U;
            if ((object) type1 == (object) type2)
              num2 = 1569075213U >> (int) num10;
            else
              goto label_3;
label_2:
            uint num11 = num2 / 1339755581U;
            IntPtr num12 = new IntPtr(checked ((long) this.\u003742739A7));
            num3 = num11 | 1390827988U;
            return (object) num12;
label_3:
            num10 <<= 31;
            if (468404592U > num10)
            {
              if ((object) _param1 == (object) typeof (UIntPtr))
                num1 = 2073968574U & num10;
              else
                goto label_7;
label_6:
              uint num13 = num1 ^ 222199303U;
              double num14 = (double) this.\u003742739A7;
              num3 = num13 & 114574081U;
              return (object) new UIntPtr(checked ((ulong) num14));
label_7:
              if ((int) num10 + 489385929 != 0)
              {
                int typeCode1 = (int) Type.GetTypeCode(_param1);
                uint num15 = 95623679U ^ num10;
                TypeCode typeCode2 = (TypeCode) typeCode1;
                if (28843441U != num15)
                {
                  int num16 = (int) typeCode2;
                  int num17 = (int) num15 - 95623674;
                  uint num18 = num15 * 1505578886U;
                  int num19 = num16 - num17;
                  num1 = 1641938979U | num18;
                  switch (num19)
                  {
                    case 0:
                      uint num20 = 1552493277U << (int) num1;
                      int num21 = _param2 ? 1 : 0;
                      num7 = num20 & 104733859U;
                      if (num21 == 0)
                      {
                        uint num22 = 321782190U & num7;
                        double num23 = (double) this.\u003742739A7;
                        num3 = 638064998U * num22;
                        num8 = (int) checked ((sbyte) num23);
                        goto label_16;
                      }
                      else
                        continue;
                    case 1:
                      num2 = 1587299893U / num1;
                      if (num2 > 1177839283U)
                        goto label_2;
                      else
                        goto label_25;
                    case 2:
                      if (851587414U >> (int) num1 == 0U)
                        goto case 0;
                      else
                        goto label_18;
                    case 3:
                      goto label_26;
                    case 4:
                      goto label_23;
                    case 5:
                      goto label_27;
                    case 6:
                      goto label_29;
                    case 7:
                      goto label_28;
                    default:
                      if (1341265728U <= num1)
                      {
                        num1 += 0U;
                        goto label_29;
                      }
                      else
                        goto label_6;
                  }
                }
              }
              else
                goto label_3;
            }
          }
          while (1693264567U < num7);
          uint num24 = 1553743235U + num7;
          int num25 = (int) checked ((uint) this.\u003742739A7);
          uint num26 = num24 / 2034436747U;
          num8 = (int) checked ((sbyte) (uint) num25);
          num3 = num26 + 0U;
label_16:
          return (object) (sbyte) num8;
label_18:
          if (!_param2)
          {
            uint num9 = num1 << 12;
            double num10 = (double) this.\u003742739A7;
            num4 = num9 * 980425533U;
            num6 = (int) checked ((short) num10);
            goto label_22;
          }
          else
            num5 = num1 >> 28;
        }
        while (1285193453U <= num5);
        uint num27 = num5 << 23;
        int num28 = (int) checked ((uint) this.\u003742739A7);
        uint num29 = 2016086750U * num27;
        num6 = (int) checked ((short) (uint) num28);
        num4 = num29 + 2317676544U;
label_22:
        num3 = num4 / 1786605506U;
        return (object) (short) num6;
label_23:
        double num30 = (double) this.\u003742739A7;
        num3 = 1673201623U >> (int) num1;
        return (object) checked ((int) num30);
label_25:
        double num31 = (double) this.\u003742739A7;
        num3 = 819412631U | num2;
        return (object) checked ((byte) num31);
label_26:
        num3 = num1 / 1867280093U;
        return (object) checked ((ushort) this.\u003742739A7);
label_27:
        double num32 = (double) this.\u003742739A7;
        uint num33 = num1 ^ 576659780U;
        int num34 = (int) checked ((uint) num32);
        num3 = 1430927621U | num33;
        return (object) (uint) num34;
label_28:
        return (object) checked ((ulong) this.\u003742739A7);
label_29:;
      }
      while (2081572812 << (int) num1 == 0);
      throw new ArgumentException();
    }
  }

  private sealed class \u0030A983227 : \u0031C561093.\u0033AF92E6D
  {
    private double \u00378306A3A;

    public \u0030A983227(double _param1)
    {
      uint num1 = (uint) (359557572 * 585452740);
      // ISSUE: explicit constructor call
      base.\u002Ector();
      uint num2 = 1299595073U & num1;
      do
      {
        uint num3 = 633739371U & num2;
        double num4 = _param1;
        num2 = num3 * 1685608816U;
        this.\u00378306A3A = num4;
      }
      while (num2 == 1590439582U);
    }

    public override Type \u0030452B850() => typeof (double);

    public override TypeCode \u003363C3519() => (TypeCode) (317284548 - 317284534);

    public override \u0031C561093.\u00304BE210E \u00321939EB5() => (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0030A983227(this.\u00378306A3A);

    public override object \u0035F319DE0() => (object) this.\u00378306A3A;

    public override void \u0036DCE2291(object _param1)
    {
      uint num1 = 120732257U / 1818956609U;
      object obj = _param1;
      uint num2 = num1 << 18;
      double num3 = (double) obj;
      uint num4 = 1348489727U & num2;
      this.\u00378306A3A = num3;
    }

    public override bool \u0039CB63F4A()
    {
      uint num1 = 75054198;
      double num2 = this.\u00378306A3A;
      uint num3 = num1 ^ 1412434910U;
      return Convert.ToBoolean(num2);
    }

    public override sbyte \u00309729E51() => (sbyte) this.\u00378306A3A;

    public override short E66DE219()
    {
      uint num1 = 372451812;
      double num2 = this.\u00378306A3A;
      uint num3 = num1 << 28;
      return (short) num2;
    }

    public override int E2D6F630() => (int) this.\u00378306A3A;

    public override long D500CE01() => (long) this.\u00378306A3A;

    public override char FCB291BE() => (char) this.\u00378306A3A;

    public override byte \u00342E17D34()
    {
      uint num1 = 74011199;
      double num2 = this.\u00378306A3A;
      uint num3 = num1 + 2088662866U;
      return (byte) num2;
    }

    public override ushort DD7230A3() => (ushort) this.\u00378306A3A;

    public override uint \u00377124934() => (uint) this.\u00378306A3A;

    public override ulong \u00353FB65C3() => (ulong) this.\u00378306A3A;

    public override float BA2939E9()
    {
      uint num1 = 2117619712;
      double num2 = this.\u00378306A3A;
      uint num3 = num1 * 258226633U;
      return (float) num2;
    }

    public override double \u00383BC968D()
    {
      uint num = 1844870555U >> 1970480393;
      return this.\u00378306A3A;
    }

    public override IntPtr B8342F7A()
    {
      uint num1 = 1097289461;
      uint num2;
      long num3;
      if (1068593282U < num1)
      {
        int size = IntPtr.Size;
        int num4 = (int) num1 ^ 1097289457;
        uint num5 = num1 - 669786962U;
        if (size != num4)
        {
          num1 = 1247823621U + num5;
        }
        else
        {
          num1 = num5 >> 9;
          if ((int) num1 * 140647464 != 0)
          {
            long num6 = (long) (int) this.\u00378306A3A;
            num2 = num1 ^ 2093714365U;
            num3 = num6;
            goto label_6;
          }
        }
      }
      num2 = 1264395953U * num1;
      num3 = (long) this.\u00378306A3A;
label_6:
      uint num7 = num2 << 24;
      return new IntPtr(num3);
    }

    public override UIntPtr \u0032452299F()
    {
      uint num1 = 255088163;
      uint num2;
      long num3;
      if (IntPtr.Size != ((int) num1 ^ 255088167))
      {
        num2 = num1 << 17;
        num3 = (long) (ulong) this.\u00378306A3A;
      }
      else
      {
        uint num4 = num1 << 5;
        double num5 = this.\u00378306A3A;
        uint num6 = num4 << 31;
        int num7 = (int) (uint) num5;
        uint num8 = num6 + 1812951492U;
        num3 = (long) (uint) num7;
        num2 = num8 + 1077317180U;
      }
      return new UIntPtr((ulong) num3);
    }

    public override object C5EE7C38(Type _param1, bool _param2)
    {
      uint num1;
      uint num2;
      uint num3;
      do
      {
        uint num4;
        uint num5;
        uint num6;
        uint num7;
        int num8;
        do
        {
          Type type1 = _param1;
          uint num9 = 815944077;
          Type type2 = typeof (IntPtr);
          num1 = num9 + 983109098U;
          if ((object) type1 == (object) type2)
          {
            if (2022210935U <= num1)
              continue;
          }
          else
            goto label_3;
label_2:
          long num10 = checked ((long) this.\u00378306A3A);
          uint num11 = num1 | 901006727U;
          IntPtr num12 = new IntPtr(num10);
          num2 = 2134144054U % num11;
          return (object) num12;
label_3:
          uint num13 = 1334204510U << (int) num1;
          Type type3 = _param1;
          uint num14 = 17258785U + num13;
          // ISSUE: type reference
          RuntimeTypeHandle handle = __typeref (UIntPtr);
          uint num15 = 1603011949U / num14;
          Type typeFromHandle = Type.GetTypeFromHandle(handle);
          num4 = 1946112772U ^ num15;
          if ((object) type3 == (object) typeFromHandle)
          {
            uint num16 = 180174156U ^ num4 ^ 807030734U;
            long num17 = (long) checked ((ulong) this.\u00378306A3A);
            uint num18 = 1042359877U - num16;
            UIntPtr num19 = new UIntPtr((ulong) num17);
            num2 = 1640725024U / num18;
            return (object) num19;
          }
label_5:
          Type type4 = _param1;
          uint num20 = num4 - 142496710U;
          int typeCode1 = (int) Type.GetTypeCode(type4);
          uint num21 = num20 % 1495027815U;
          TypeCode typeCode2 = (TypeCode) typeCode1;
          if (num21 < 1180593838U)
          {
            int num16 = (int) typeCode2;
            int num17 = (int) num21 - 308588243;
            num3 = num21 - 580721928U;
            switch (num16 - num17)
            {
              case 0:
                uint num18 = num3 | 1892511006U;
                int num19 = _param2 ? 1 : 0;
                uint num22 = num18 << 25;
                if (num19 == 0)
                {
                  uint num23 = 652240585U * num22 & 1094536051U;
                  double num24 = this.\u00378306A3A;
                  num5 = num23 << 2;
                  num8 = (int) checked ((sbyte) num24);
                  goto label_12;
                }
                else
                {
                  num6 = 1818561451U - num22;
                  continue;
                }
              case 1:
                goto label_23;
              case 2:
                num7 = 283981135U / num3;
                if (num7 != 624506082U)
                {
                  if (!_param2)
                  {
                    num4 = 405485635U * num7;
                    if (num4 / 441408117U != 0U)
                      goto label_5;
                    else
                      goto label_16;
                  }
                  else
                    goto label_17;
                }
                else
                  continue;
              case 3:
                goto label_24;
              case 4:
                goto label_19;
              case 5:
                goto label_25;
              case 6:
                num1 = 985537539U * num3;
                if ((1024290993 ^ (int) num1) == 0)
                  goto label_3;
                else
                  goto label_22;
              case 7:
                goto label_26;
              case 8:
                num1 = 191052048U << (int) num3;
                if (1539970689U <= num1)
                  goto label_2;
                else
                  goto label_29;
              case 9:
                goto label_27;
              default:
                num3 += 0U;
                goto case 8;
            }
          }
        }
        while (num6 == 2102594462U);
        num8 = (int) checked ((sbyte) (uint) this.\u00378306A3A);
        num5 = num6 + 1335555157U;
label_12:
        num2 = num5 - 2145728733U;
        return (object) (sbyte) num8;
label_16:
        int num25 = (int) checked ((short) this.\u00378306A3A);
        goto label_18;
label_17:
        uint num26 = 847859051U + (num7 & 634269758U);
        double num27 = this.\u00378306A3A;
        uint num28 = num26 & 47455404U;
        int num29 = (int) checked ((uint) num27);
        uint num30 = 923097982U * num28;
        num25 = (int) checked ((short) (uint) num29);
        num4 = num30 + 1809828944U;
label_18:
        num2 = num4 & 351687659U;
        return (object) (short) num25;
label_19:;
      }
      while (917180134U % num3 == 0U);
      return (object) checked ((int) this.\u00378306A3A);
label_22:
      num2 = num1 >> 8;
      return (object) checked ((long) this.\u00378306A3A);
label_23:
      uint num31 = num3 ^ 790853800U;
      double num32 = this.\u00378306A3A;
      uint num33 = 979717606U - num31;
      int num34 = (int) checked ((byte) num32);
      num2 = 1590253728U ^ num33;
      return (object) (byte) num34;
label_24:
      num2 = num3 + 1047881834U;
      return (object) checked ((ushort) this.\u00378306A3A);
label_25:
      uint num35 = 167595900U & num3;
      double num36 = this.\u00378306A3A;
      uint num37 = 1568946387U >> (int) num35;
      int num38 = (int) checked ((uint) num36);
      num2 = 1353535767U << (int) num37;
      return (object) (uint) num38;
label_26:
      num2 = 1979335708U + num3;
      return (object) checked ((ulong) this.\u00378306A3A);
label_27:
      double num39 = this.\u00378306A3A;
      num2 = num3 << 27;
      return (object) num39;
label_29:
      throw new ArgumentException();
    }
  }

  private sealed class \u0036D9D2AA1 : \u0031C561093.\u0033AF92E6D
  {
    private string \u00317E900CD;

    public \u0036D9D2AA1(string _param1)
    {
      uint num1;
      do
      {
        uint num2 = 939340233;
        // ISSUE: explicit constructor call
        base.\u002Ector();
        num1 = num2 * 1303472541U;
      }
      while (((int) num1 & 644052183) == 0);
      string str = _param1;
      uint num3 = 963401564U & num1;
      this.\u00317E900CD = str;
    }

    public override Type \u0030452B850() => typeof (string);

    public override TypeCode \u003363C3519() => TypeCode.Object;

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num = (uint) (1598051581 ^ 480842144);
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0036D9D2AA1(this.\u00317E900CD);
    }

    public override object \u0035F319DE0() => (object) this.\u00317E900CD;

    public override void \u0036DCE2291(object _param1)
    {
      uint num1 = 1695686460;
      object obj1 = _param1;
      uint num2 = num1 / 956515629U;
      uint num3;
      string str;
      if (obj1 == null)
      {
        num3 = 1043473443U ^ num2;
        str = (string) null;
      }
      else
      {
        object obj2 = _param1;
        uint num4 = 1743268193U * num2;
        str = Convert.ToString(obj2);
        num3 = num4 + 3595172545U;
      }
      uint num5 = num3 / 954548067U;
      this.\u00317E900CD = str;
    }

    public override bool \u0039CB63F4A()
    {
      uint num1 = 619788938;
      string str = this.\u00317E900CD;
      uint num2 = 1505979873U / num1;
      return str > null;
    }

    public override string ToString() => this.\u00317E900CD;
  }

  private sealed class \u003292A58A9 : \u0031C561093.\u00304BE210E
  {
    private short \u00302E83180;

    public \u003292A58A9(short _param1)
    {
      uint num1 = 857044528;
      // ISSUE: explicit constructor call
      base.\u002Ector();
      uint num2 = num1 % 195982578U;
      do
      {
        uint num3 = num2 - 2145615362U;
        int num4 = (int) _param1;
        num2 = 2008249509U % num3;
        this.\u00302E83180 = (short) num4;
      }
      while (((int) num2 ^ 178747847) == 0);
    }

    public override Type \u0030452B850() => typeof (short);

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num = (uint) (100236200 - 1144090256);
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u003292A58A9(this.\u00302E83180);
    }

    public override object \u0035F319DE0()
    {
      uint num1 = 2002663199;
      int num2 = (int) this.\u00302E83180;
      uint num3 = num1 << 18;
      return (object) (short) num2;
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num1 = 674442967;
      if ((1931550236 & (int) num1) == 0)
        return;
      object obj = _param1;
      uint num2 = 318723973U >> (int) num1;
      this.\u00302E83180 = Convert.ToInt16(obj);
    }

    public override \u0031C561093.\u0033AF92E6D \u00366E9DD83() => (\u0031C561093.\u0033AF92E6D) new \u0031C561093.\u00348553D81(this.E2D6F630());

    public override sbyte \u00309729E51()
    {
      uint num1 = 592133394;
      int num2 = (int) this.\u00302E83180;
      uint num3 = num1 >> 1;
      return (sbyte) num2;
    }

    public override byte \u00342E17D34() => (byte) this.\u00302E83180;

    public override short E66DE219() => this.\u00302E83180;

    public override ushort DD7230A3()
    {
      uint num1 = 1250315615;
      int num2 = (int) this.\u00302E83180;
      uint num3 = num1 + 1608862586U;
      return (ushort) num2;
    }

    public override int E2D6F630() => (int) this.\u00302E83180;

    public override uint \u00377124934() => (uint) this.\u00302E83180;
  }

  private sealed class \u003727958FF : \u0031C561093.\u00304BE210E
  {
    private ushort \u00379F80679;

    public \u003727958FF(ushort _param1)
    {
      uint num1;
      do
      {
        // ISSUE: explicit constructor call
        base.\u002Ector();
        num1 = 1033175903U;
      }
      while (1442062070U <= num1);
      do
      {
        uint num2 = 1713120313U - num1;
        int num3 = (int) _param1;
        num1 = num2 ^ 750938134U;
        this.\u00379F80679 = (ushort) num3;
      }
      while (num1 == 2073379573U);
    }

    public override Type \u0030452B850() => typeof (ushort);

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num = (uint) (1885812081 << 283719506);
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u003727958FF(this.\u00379F80679);
    }

    public override object \u0035F319DE0()
    {
      uint num1 = 436609530U >> 4;
      int num2 = (int) this.\u00379F80679;
      uint num3 = num1 & 1809328228U;
      return (object) (ushort) num2;
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num1 = 1557158636;
      object obj = _param1;
      uint num2 = num1 & 1490566870U;
      int uint16 = (int) Convert.ToUInt16(obj);
      uint num3 = 941839578U | num2;
      this.\u00379F80679 = (ushort) uint16;
    }

    public override \u0031C561093.\u0033AF92E6D \u00366E9DD83() => (\u0031C561093.\u0033AF92E6D) new \u0031C561093.\u00348553D81(this.E2D6F630());

    public override sbyte \u00309729E51()
    {
      uint num1 = (uint) (1663530485 ^ 2075656917);
      int num2 = (int) this.\u00379F80679;
      uint num3 = 1217083296U - num1;
      return (sbyte) num2;
    }

    public override byte \u00342E17D34() => (byte) this.\u00379F80679;

    public override short E66DE219()
    {
      uint num1 = 2104950970;
      int num2 = (int) this.\u00379F80679;
      uint num3 = num1 + 1701202831U;
      return (short) num2;
    }

    public override ushort DD7230A3() => this.\u00379F80679;

    public override int E2D6F630()
    {
      uint num = (uint) (215891653 + 20662754);
      return (int) this.\u00379F80679;
    }

    public override uint \u00377124934() => (uint) this.\u00379F80679;
  }

  private sealed class \u003459C67EE : \u0031C561093.\u00304BE210E
  {
    private bool \u00313B35860;

    public \u003459C67EE(bool _param1)
    {
      uint num1;
      do
      {
        // ISSUE: explicit constructor call
        base.\u002Ector();
        num1 = 2138309572U;
      }
      while (534995209 << (int) num1 == 0);
      do
      {
        int num2 = _param1 ? 1 : 0;
        num1 |= 413994878U;
        this.\u00313B35860 = num2 != 0;
      }
      while (num1 < 898706788U);
    }

    public override Type \u0030452B850() => typeof (bool);

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num1 = 640362255;
      int num2 = this.\u00313B35860 ? 1 : 0;
      uint num3 = num1 + 345929178U;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u003459C67EE(num2 != 0);
    }

    public override object \u0035F319DE0()
    {
      uint num1 = 786906549;
      int num2 = this.\u00313B35860 ? 1 : 0;
      uint num3 = num1 ^ 1642988475U;
      return (object) (bool) num2;
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num1;
      do
      {
        uint num2 = 736578541;
        int num3 = Convert.ToBoolean(_param1) ? 1 : 0;
        num1 = num2 % 358692438U;
        this.\u00313B35860 = num3 != 0;
      }
      while (1857517364U < num1);
    }

    public override \u0031C561093.\u0033AF92E6D \u00366E9DD83() => (\u0031C561093.\u0033AF92E6D) new \u0031C561093.\u00348553D81(this.E2D6F630());

    public override int E2D6F630()
    {
      uint num = 1195540086;
      return 642657247U >= num || !this.\u00313B35860 ? (int) num - 1195540086 : (int) num - 1195540085;
    }
  }

  private sealed class \u00343192462 : \u0031C561093.\u00304BE210E
  {
    private char \u003150D44E2;

    public \u00343192462(char _param1)
    {
      uint num1 = 1816949304;
      if (1674402133 + (int) num1 == 0)
        return;
      do
      {
        do
        {
          // ISSUE: explicit constructor call
          base.\u002Ector();
          num1 &= 397032971U;
        }
        while (763834032U >> (int) num1 == 0U);
        uint num2 = num1 - 36640977U;
        int num3 = (int) _param1;
        num1 = 26100026U / num2;
        this.\u003150D44E2 = (char) num3;
      }
      while ((int) num1 - 1006585112 == 0);
    }

    public override Type \u0030452B850() => typeof (char);

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num = (uint) (1078221145 - 1052594464);
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00343192462(this.\u003150D44E2);
    }

    public override object \u0035F319DE0() => (object) this.\u003150D44E2;

    public override void \u0036DCE2291(object _param1)
    {
      uint num1;
      do
      {
        uint num2 = 1315513982;
        int num3 = (int) Convert.ToChar(_param1);
        num1 = 1696865145U | num2;
        this.\u003150D44E2 = (char) num3;
      }
      while (num1 > 2085175540U);
    }

    public override \u0031C561093.\u0033AF92E6D \u00366E9DD83()
    {
      uint num1 = 1581927967;
      int num2 = this.E2D6F630();
      uint num3 = num1 / 2112103255U;
      return (\u0031C561093.\u0033AF92E6D) new \u0031C561093.\u00348553D81(num2);
    }

    public override sbyte \u00309729E51() => (sbyte) this.\u003150D44E2;

    public override byte \u00342E17D34() => (byte) this.\u003150D44E2;

    public override short E66DE219() => (short) this.\u003150D44E2;

    public override ushort DD7230A3()
    {
      uint num = (uint) (1719156905 ^ 1003233104);
      return (ushort) this.\u003150D44E2;
    }

    public override int E2D6F630() => (int) this.\u003150D44E2;

    public override uint \u00377124934() => (uint) this.\u003150D44E2;
  }

  private sealed class \u0034C6A3A6D : \u0031C561093.\u00304BE210E
  {
    private byte \u00319C9352E;

    public \u0034C6A3A6D(byte _param1)
    {
      uint num1 = 1884634714;
      // ISSUE: explicit constructor call
      base.\u002Ector();
      uint num2 = num1 & 1392385083U;
      int num3 = (int) _param1;
      uint num4 = 1675832389U % num2;
      this.\u00319C9352E = (byte) num3;
    }

    public override Type \u0030452B850() => typeof (byte);

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num1 = (uint) (378087649 | 1347362292);
      int num2 = (int) this.\u00319C9352E;
      uint num3 = 734015374U * num1;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0034C6A3A6D((byte) num2);
    }

    public override object \u0035F319DE0()
    {
      uint num1 = 352665609;
      int num2 = (int) this.\u00319C9352E;
      uint num3 = 1416646897U + num1;
      return (object) (byte) num2;
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num1;
      do
      {
        uint num2 = 1569091680;
        int num3 = (int) Convert.ToByte(_param1);
        num1 = 1263166743U ^ num2;
        this.\u00319C9352E = (byte) num3;
      }
      while (num1 >= 841695485U);
    }

    public override \u0031C561093.\u0033AF92E6D \u00366E9DD83()
    {
      uint num1 = 1442655648;
      int num2 = this.E2D6F630();
      uint num3 = 332470659U >> (int) num1;
      return (\u0031C561093.\u0033AF92E6D) new \u0031C561093.\u00348553D81(num2);
    }

    public override sbyte \u00309729E51()
    {
      uint num1 = (uint) (233063896 | 122098256);
      int num2 = (int) this.\u00319C9352E;
      uint num3 = 2009356951U | num1;
      return (sbyte) num2;
    }

    public override byte \u00342E17D34() => this.\u00319C9352E;

    public override short E66DE219() => (short) this.\u00319C9352E;

    public override ushort DD7230A3()
    {
      uint num = (uint) (843339356 + 268638871);
      return (ushort) this.\u00319C9352E;
    }

    public override int E2D6F630() => (int) this.\u00319C9352E;

    public override uint \u00377124934()
    {
      uint num = (uint) (2041132284 * 598242372);
      return (uint) this.\u00319C9352E;
    }
  }

  private sealed class \u003707D1DC6 : \u0031C561093.\u00304BE210E
  {
    private sbyte \u0030D02747B;

    public \u003707D1DC6(sbyte _param1)
    {
      uint num1 = 1562528271;
      if (num1 <= 1027106880U)
        return;
      uint num2 = num1 % 1669621959U;
      // ISSUE: explicit constructor call
      base.\u002Ector();
      do
      {
        int num3 = (int) _param1;
        num2 &= 71718479U;
        this.\u0030D02747B = (sbyte) num3;
      }
      while (2016110853U <= num2);
    }

    public override Type \u0030452B850() => typeof (sbyte);

    public override \u0031C561093.\u00304BE210E \u00321939EB5() => (\u0031C561093.\u00304BE210E) new \u0031C561093.\u003707D1DC6(this.\u0030D02747B);

    public override object \u0035F319DE0()
    {
      uint num1 = (uint) (22087274 << 1703309851);
      int num2 = (int) this.\u0030D02747B;
      uint num3 = 805837593U + num1;
      return (object) (sbyte) num2;
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num1;
      do
      {
        int num2 = (int) Convert.ToSByte(_param1);
        num1 = 498027627U;
        this.\u0030D02747B = (sbyte) num2;
      }
      while (num1 >= 1864727210U);
    }

    public override \u0031C561093.\u0033AF92E6D \u00366E9DD83()
    {
      uint num1 = 1358787080U % 1014393881U;
      int num2 = this.E2D6F630();
      uint num3 = num1 ^ 1358435949U;
      return (\u0031C561093.\u0033AF92E6D) new \u0031C561093.\u00348553D81(num2);
    }

    public override sbyte \u00309729E51() => this.\u0030D02747B;

    public override byte \u00342E17D34() => (byte) this.\u0030D02747B;

    public override short E66DE219() => (short) this.\u0030D02747B;

    public override ushort DD7230A3()
    {
      uint num = (uint) (1046558095 + 1829655949);
      return (ushort) this.\u0030D02747B;
    }

    public override int E2D6F630() => (int) this.\u0030D02747B;

    public override uint \u00377124934() => (uint) this.\u0030D02747B;
  }

  private sealed class \u00328355445 : \u0031C561093.\u00304BE210E
  {
    private uint \u00371A45680;

    public \u00328355445(uint _param1)
    {
      uint num1 = 1702892105U >> 2;
      // ISSUE: explicit constructor call
      base.\u002Ector();
      uint num2 = 1276650169U - num1 * 182134877U;
      this.\u00371A45680 = _param1;
    }

    public override Type \u0030452B850()
    {
      uint num1 = 882076585;
      // ISSUE: type reference
      RuntimeTypeHandle handle = __typeref (uint);
      uint num2 = num1 & 903817814U;
      return Type.GetTypeFromHandle(handle);
    }

    public override \u0031C561093.\u00304BE210E \u00321939EB5() => (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00328355445(this.\u00371A45680);

    public override object \u0035F319DE0()
    {
      uint num1 = 1954758419;
      int num2 = (int) this.\u00371A45680;
      uint num3 = 1234917318U | num1;
      return (object) (uint) num2;
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num = 29110243;
      if (2106409925U < num)
        return;
      do
      {
        object obj = _param1;
        num *= 497751602U;
        this.\u00371A45680 = Convert.ToUInt32(obj);
      }
      while (num <= 406671224U);
    }

    public override \u0031C561093.\u0033AF92E6D \u00366E9DD83() => (\u0031C561093.\u0033AF92E6D) new \u0031C561093.\u00348553D81(this.E2D6F630());

    public override sbyte \u00309729E51() => (sbyte) this.\u00371A45680;

    public override byte \u00342E17D34()
    {
      uint num1 = 1956259252;
      int num2 = (int) this.\u00371A45680;
      uint num3 = 1476023939U / num1;
      return (byte) num2;
    }

    public override short E66DE219() => (short) this.\u00371A45680;

    public override ushort DD7230A3() => (ushort) this.\u00371A45680;

    public override int E2D6F630()
    {
      uint num = (uint) (2143106066 * 778456435);
      return (int) this.\u00371A45680;
    }

    public override uint \u00377124934() => this.\u00371A45680;
  }

  private sealed class \u00362E85068 : \u0031C561093.\u00304BE210E
  {
    private ulong \u0037AF06DFA;

    public \u00362E85068(ulong _param1)
    {
      uint num1 = 1749903904;
      if (338721623U >= num1)
        return;
      do
      {
        uint num2 = num1 % 1524526760U;
        // ISSUE: explicit constructor call
        base.\u002Ector();
        long num3 = (long) _param1;
        num1 = 1419142095U | num2;
        this.\u0037AF06DFA = (ulong) num3;
      }
      while (num1 == 1342003295U);
    }

    public override Type \u0030452B850() => typeof (ulong);

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num1 = (uint) (57417554 & 1977963855);
      long num2 = (long) this.\u0037AF06DFA;
      uint num3 = 933581087U & num1;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00362E85068((ulong) num2);
    }

    public override object \u0035F319DE0() => (object) this.\u0037AF06DFA;

    public override void \u0036DCE2291(object _param1)
    {
      uint num1 = 43610843;
      if (num1 == 128335797U)
        return;
      uint num2 = 1022769422U >> (int) num1;
      object obj = _param1;
      uint num3 = 861955974U | num2;
      this.\u0037AF06DFA = Convert.ToUInt64(obj);
    }

    public override \u0031C561093.\u0033AF92E6D \u00366E9DD83() => (\u0031C561093.\u0033AF92E6D) new \u0031C561093.\u00304E67D6F(this.D500CE01());

    public override sbyte \u00309729E51()
    {
      uint num1 = 691105066;
      long num2 = (long) this.\u0037AF06DFA;
      uint num3 = 1773471396U << (int) num1;
      return (sbyte) num2;
    }

    public override byte \u00342E17D34()
    {
      uint num1 = 2097028386;
      long num2 = (long) this.\u0037AF06DFA;
      uint num3 = 1746304110U >> (int) num1;
      return (byte) num2;
    }

    public override short E66DE219()
    {
      uint num1 = (uint) (1743979827 - 743906601);
      long num2 = (long) this.\u0037AF06DFA;
      uint num3 = num1 >> 28;
      return (short) num2;
    }

    public override ushort DD7230A3()
    {
      uint num = (uint) (562968605 - 1818132079);
      return (ushort) this.\u0037AF06DFA;
    }

    public override int E2D6F630()
    {
      uint num1 = 554250077U % 1193872369U;
      long num2 = (long) this.\u0037AF06DFA;
      uint num3 = num1 ^ 740776425U;
      return (int) num2;
    }

    public override uint \u00377124934() => (uint) this.\u0037AF06DFA;

    public override long D500CE01() => (long) this.\u0037AF06DFA;

    public override ulong \u00353FB65C3()
    {
      uint num = (uint) (1245017883 + 1441728313);
      return this.\u0037AF06DFA;
    }
  }

  private sealed class \u00362DF5BD2 : \u0031C561093.\u0033AF92E6D
  {
    private object \u00374FB532A;

    public \u00362DF5BD2(object _param1)
    {
      uint num = 1681590045;
      if (num <= 244740884U)
        return;
      do
      {
        do
        {
          // ISSUE: explicit constructor call
          base.\u002Ector();
          num = 634586539U % num;
        }
        while (1334976400U <= num);
        this.\u00374FB532A = _param1;
      }
      while (num == 369980405U);
    }

    public override Type \u0030452B850() => typeof (object);

    public override TypeCode \u003363C3519() => TypeCode.Object;

    public override \u0031C561093.\u00304BE210E \u00321939EB5() => (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00362DF5BD2(this.\u00374FB532A);

    public override object \u0035F319DE0() => this.\u00374FB532A;

    public override void \u0036DCE2291(object _param1)
    {
      if (540082576U > 962424558U)
        return;
      this.\u00374FB532A = _param1;
    }

    public override bool \u0039CB63F4A()
    {
      uint num1 = 869082532;
      object obj = this.\u00374FB532A;
      uint num2 = 163068366U % num1;
      return obj > null;
    }
  }

  private sealed class \u00369D911C6 : \u0031C561093.\u0033AF92E6D
  {
    private object \u0034C13519D;
    private Type \u0037CF26045;
    private \u0031C561093.\u00304BE210E \u0037AC5408B;

    public \u00369D911C6(object _param1, Type _param2)
    {
      uint num1 = 475943666;
      do
      {
        uint num2 = num1 * 1644460090U;
        // ISSUE: explicit constructor call
        base.\u002Ector();
        uint num3 = 638604916U | num2;
        object obj = _param1;
        uint num4 = 186149686U / num3;
        this.\u0034C13519D = obj;
        uint num5 = (153748654U << (int) num4) / 1022518615U;
        Type type = _param2;
        uint num6 = num5 * 298857363U;
        this.\u0037CF26045 = type;
        num1 = 106441763U >> (int) num6;
      }
      while (1087595696U >> (int) num1 == 0U);
      this.\u0037AC5408B = \u0031C561093.\u00369D911C6.\u00316FD0D92(_param1);
    }

    private static unsafe \u0031C561093.\u00304BE210E \u00316FD0D92(object _param0)
    {
      uint num1;
      IntPtr num2;
      if (_param0 != null)
      {
        num1 = 136933515U;
        num2 = new IntPtr(Pointer.Unbox(_param0));
      }
      else
      {
        num2 = IntPtr.Zero;
        num1 = 136933515U;
      }
      IntPtr num3 = num2;
      uint num4 = num1 / 759119745U;
      uint num5;
      do
      {
        int size = IntPtr.Size;
        int num6 = (int) num4 + 4;
        num4 = 1425296032U - num4;
        if (size == num6)
        {
          uint num7 = num4 >> 29;
          int int32 = num3.ToInt32();
          num5 = num7 << 18;
          return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(int32);
        }
      }
      while (((int) num4 ^ 898919428) == 0);
      ref IntPtr local = ref num3;
      num5 = num4 >> 9;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(local.ToInt64());
    }

    public override Type \u0030452B850()
    {
      uint num = (uint) (900416397 ^ 677931246);
      return this.\u0037CF26045;
    }

    public override TypeCode \u003363C3519()
    {
      uint num = 1700795147;
      return num <= 712252351U || IntPtr.Size != ((int) num ^ 1700795151) ? (TypeCode) ((int) num - 1700795135) : (TypeCode) ((int) (num | 1565809208U) ^ 2104777521);
    }

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num1 = 1540959590;
      object obj = this.\u0034C13519D;
      uint num2 = 1777890512U + (877272056U + num1);
      Type type = this.\u0037CF26045;
      uint num3 = 548349792U ^ num2;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00369D911C6(obj, type);
    }

    public override object \u0035F319DE0()
    {
      uint num = (uint) (238966930 << 29);
      return this.\u0034C13519D;
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num1 = 658649605;
      if (1971666428U != num1)
      {
        do
        {
          object obj = _param1;
          num1 += 1183716790U;
          this.\u0034C13519D = obj;
        }
        while (303106922U == num1);
      }
      uint num2 = num1 >> 5;
      object obj1 = _param1;
      uint num3 = num2 / 1746685156U;
      \u0031C561093.\u00304BE210E obj2 = \u0031C561093.\u00369D911C6.\u00316FD0D92(obj1);
      uint num4 = 906978814U * num3;
      this.\u0037AC5408B = obj2;
    }

    public override bool \u0039CB63F4A()
    {
      uint num1 = (uint) (1923564536 + 2102210972);
      object obj = this.\u0034C13519D;
      uint num2 = num1 * 236659889U;
      return obj > null;
    }

    public override sbyte \u00309729E51() => this.\u0037AC5408B.\u00309729E51();

    public override short E66DE219() => this.\u0037AC5408B.E66DE219();

    public override int E2D6F630() => this.\u0037AC5408B.E2D6F630();

    public override long D500CE01() => this.\u0037AC5408B.D500CE01();

    public override byte \u00342E17D34() => this.\u0037AC5408B.\u00342E17D34();

    public override ushort DD7230A3() => this.\u0037AC5408B.DD7230A3();

    public override uint \u00377124934()
    {
      uint num1 = (uint) (921520907 | 301357217);
      \u0031C561093.\u00304BE210E obj = this.\u0037AC5408B;
      uint num2 = num1 / 692332537U;
      return obj.\u00377124934();
    }

    public override ulong \u00353FB65C3() => this.\u0037AC5408B.\u00353FB65C3();

    public override float BA2939E9()
    {
      uint num1 = 842807481;
      \u0031C561093.\u00304BE210E obj = this.\u0037AC5408B;
      uint num2 = num1 / 1616527946U;
      return obj.BA2939E9();
    }

    public override double \u00383BC968D() => this.\u0037AC5408B.\u00383BC968D();

    public override IntPtr B8342F7A()
    {
      uint num = 1772645540U % 1563628039U;
      return this.\u0037AC5408B.B8342F7A();
    }

    public override UIntPtr \u0032452299F()
    {
      uint num1 = 13836640U % 104491600U;
      \u0031C561093.\u00304BE210E obj = this.\u0037AC5408B;
      uint num2 = 1285294693U & num1;
      return obj.\u0032452299F();
    }

    public override unsafe void* \u003480545A0() => Pointer.Unbox(this.\u0034C13519D);

    public override object C5EE7C38(Type _param1, bool _param2)
    {
      uint num1 = (uint) (1104957107 | 850875770);
      \u0031C561093.\u00304BE210E obj = this.\u0037AC5408B;
      uint num2 = num1 * 1060135719U;
      Type type = _param1;
      uint num3 = 1256087076U * num2;
      int num4 = _param2 ? 1 : 0;
      uint num5 = num3 - 1310984656U;
      return obj.C5EE7C38(type, num4 != 0);
    }
  }

  private sealed class \u003475922BE : \u0031C561093.\u0033AF92E6D
  {
    private object \u0030EF07C63;

    public \u003475922BE(object _param1)
    {
      uint num1 = 997592365;
      if (1973356217U / num1 != 0U)
      {
        do
        {
          // ISSUE: explicit constructor call
          base.\u002Ector();
        }
        while (1146232969U < num1);
      }
      if (_param1 != null)
      {
        uint num2 = 772870794U >> (int) num1;
        ValueType valueType = _param1 as ValueType;
        num1 = num2 + 997498021U;
        if (valueType == null)
        {
          if (139483141U == num1)
            return;
          throw new ArgumentException();
        }
      }
      object obj = _param1;
      uint num3 = num1 & 1315335106U;
      this.\u0030EF07C63 = obj;
    }

    public override Type \u0030452B850() => typeof (ValueType);

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num1 = 1725708010;
      object obj = this.\u0030EF07C63;
      uint num2 = num1 | 1417156599U;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u003475922BE(obj);
    }

    public override object \u0035F319DE0() => this.\u0030EF07C63;

    public override void \u0036DCE2291(object _param1)
    {
      if (_param1 == null)
        goto label_4;
label_2:
      if (!(_param1 is ValueType))
        throw new ArgumentException();
label_4:
      uint num1 = 903026462;
      object obj = _param1;
      uint num2 = num1 | 198451776U;
      this.\u0030EF07C63 = obj;
      if (((int) num2 ^ 1945508303) == 0)
        goto label_2;
    }
  }

  private sealed class \u0033745431B : \u0031C561093.\u0033AF92E6D
  {
    private Array \u003143904B5;

    public \u0033745431B(Array _param1)
    {
      uint num1 = 1498968401;
      if (num1 != 800545846U)
      {
        // ISSUE: explicit constructor call
        base.\u002Ector();
        num1 = 712992727U ^ num1;
      }
      uint num2 = num1 - 1285765450U;
      this.\u003143904B5 = _param1;
    }

    public override Type \u0030452B850()
    {
      uint num1 = 946884121;
      // ISSUE: type reference
      RuntimeTypeHandle handle = __typeref (Array);
      uint num2 = 1957132383U - num1;
      return Type.GetTypeFromHandle(handle);
    }

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num1 = 866281563;
      Array array = this.\u003143904B5;
      uint num2 = 2122150506U - num1;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0033745431B(array);
    }

    public override object \u0035F319DE0() => (object) this.\u003143904B5;

    public override void \u0036DCE2291(object _param1)
    {
      uint num = 1695111148;
      if (((int) num ^ 656101358) == 0)
        return;
      do
      {
        object obj = _param1;
        num >>= 31;
        this.\u003143904B5 = (Array) obj;
      }
      while (758076456 + (int) num == 0);
    }

    public override bool \u0039CB63F4A()
    {
      uint num1 = 1872118384;
      Array array = this.\u003143904B5;
      uint num2 = 973087475U & num1 - 1560161440U;
      return array > null;
    }
  }

  private abstract class \u003324700AD : \u0031C561093.\u0033AF92E6D
  {
    public override bool \u0036736EEEA() => 1337537035 - 1337537034 != 0;

    protected \u003324700AD()
    {
      uint num;
      do
      {
        num = 1712741101U;
        // ISSUE: explicit constructor call
        base.\u002Ector();
      }
      while (358232044U > num);
    }
  }

  private sealed class \u003539D1618 : \u0031C561093.\u003324700AD
  {
    private \u0031C561093.\u00304BE210E \u0032BEA5D4C;

    public \u003539D1618(\u0031C561093.\u00304BE210E _param1)
    {
      uint num1 = 1515727858;
      do
      {
        uint num2 = num1 / 1224685331U;
        // ISSUE: explicit constructor call
        base.\u002Ector();
        num1 = 1423728929U >> (int) num2;
        if (1963078677U != num1)
          this.\u0032BEA5D4C = _param1;
        else
          goto label_3;
      }
      while (((int) num1 & 631128680) == 0);
      goto label_4;
label_3:
      return;
label_4:;
    }

    public override Type \u0030452B850() => this.\u0032BEA5D4C.\u0030452B850();

    public override \u0031C561093.\u00304BE210E \u00321939EB5() => (\u0031C561093.\u00304BE210E) new \u0031C561093.\u003539D1618(this.\u0032BEA5D4C);

    public override object \u0035F319DE0() => this.\u0032BEA5D4C.\u0035F319DE0();

    public override void \u0036DCE2291(object _param1)
    {
      uint num = 1775385615U / 2145871596U;
      this.\u0032BEA5D4C.\u0036DCE2291(_param1);
    }

    public override bool \u0039CB63F4A() => this.\u0032BEA5D4C != null;
  }

  private sealed class \u00371A06EE8 : \u0031C561093.\u003324700AD
  {
    private \u0031C561093.\u00304BE210E \u0030D8A711A;
    private \u0031C561093.\u00304BE210E \u003494F772F;

    public \u00371A06EE8(\u0031C561093.\u00304BE210E _param1, \u0031C561093.\u00304BE210E _param2)
    {
      uint num1 = 1509100535;
      if (num1 / 1352338107U != 0U)
      {
        // ISSUE: explicit constructor call
        base.\u002Ector();
      }
      uint num2 = num1 >> 17;
      \u0031C561093.\u00304BE210E obj = _param1;
      uint num3 = 906714129U - num2;
      this.\u0030D8A711A = obj;
      uint num4 = num3 >> 18 >> 18;
      this.\u003494F772F = _param2;
    }

    public override Type \u0030452B850() => this.\u0030D8A711A.\u0030452B850();

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num1 = 57022674;
      \u0031C561093.\u00304BE210E obj1 = this.\u0030D8A711A;
      uint num2 = 346558394U * num1 & 857625748U;
      \u0031C561093.\u00304BE210E obj2 = this.\u003494F772F;
      uint num3 = 1703873701U * num2;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00371A06EE8(obj1, obj2);
    }

    public override object \u0035F319DE0() => this.\u0030D8A711A.\u0035F319DE0();

    public override void \u0036DCE2291(object _param1)
    {
      uint num1;
      do
      {
        \u0031C561093.\u00304BE210E obj1 = this.\u0030D8A711A;
        num1 = 1718234127U;
        object obj2 = _param1;
        obj1.\u0036DCE2291(obj2);
      }
      while (1197752224U >= num1);
      uint num2 = 1141442722U / num1;
      this.\u003494F772F.\u0036DCE2291(this.\u0030D8A711A.\u0035F319DE0());
    }

    public override bool \u0039CB63F4A() => this.\u0030D8A711A > null;
  }

  private sealed class \u0034C846853 : \u0031C561093.\u003324700AD
  {
    private FieldInfo \u00313863FCB;
    private object \u0036812742D;

    public \u0034C846853(FieldInfo _param1, object _param2)
    {
      uint num = (uint) (1050688200 | 1321278335);
      // ISSUE: explicit constructor call
      base.\u002Ector();
      do
      {
        this.\u00313863FCB = _param1;
        num = 892430444U / num;
      }
      while ((287799390 & (int) num) != 0);
      do
      {
        object obj = _param2;
        num = 1144920340U << (int) num;
        this.\u0036812742D = obj;
      }
      while (438839316U >= num);
    }

    public override Type \u0030452B850()
    {
      uint num1 = 1388584555U / 999962412U;
      FieldInfo fieldInfo = this.\u00313863FCB;
      uint num2 = num1 - 2062490712U;
      return fieldInfo.FieldType;
    }

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num1 = 625809644;
      FieldInfo fieldInfo = this.\u00313863FCB;
      uint num2 = 1745445098U * num1;
      object obj = this.\u0036812742D;
      uint num3 = num2 - 343689562U;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0034C846853(fieldInfo, obj);
    }

    public override object \u0035F319DE0()
    {
      uint num1 = (uint) (585444076 | 1880310255);
      FieldInfo fieldInfo = this.\u00313863FCB;
      uint num2 = num1 % 727071416U / 56979042U;
      object obj = this.\u0036812742D;
      return fieldInfo.GetValue(obj);
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num1 = 1905339687;
      FieldInfo fieldInfo = this.\u00313863FCB;
      object obj1 = this.\u0036812742D;
      object obj2 = _param1;
      uint num2 = 757627503U % num1;
      fieldInfo.SetValue(obj1, obj2);
    }
  }

  private sealed class \u0035C7A6B63 : \u0031C561093.\u003324700AD
  {
    private Array \u0033A9A1330;
    private int \u00374BD1755;

    public \u0035C7A6B63(Array _param1, int _param2)
    {
      uint num1 = 1273637731;
      do
      {
        Array array = _param1;
        uint num2 = 456868468U << (int) num1;
        this.\u0033A9A1330 = array;
        uint num3 = num2 | 458445444U;
        int num4 = _param2;
        num1 = 1861774635U / num3;
        this.\u00374BD1755 = num4;
      }
      while (num1 == 1934100649U);
    }

    public override Type \u0030452B850()
    {
      uint num1 = 369844016;
      Array array = this.\u0033A9A1330;
      uint num2 = num1 >> 10;
      Type type = array.GetType();
      uint num3 = num2 | 1470255020U;
      return type.GetElementType();
    }

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      Array array = this.\u0033A9A1330;
      uint num1 = (uint) (2039099291 + 1132537607);
      int num2 = this.\u00374BD1755;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0035C7A6B63(array, num2);
    }

    public override object \u0035F319DE0()
    {
      uint num1 = 1910403162;
      Array array = this.\u0033A9A1330;
      uint num2 = 2073514910U + num1;
      int index = this.\u00374BD1755;
      uint num3 = num2 / 1858148820U;
      return array.GetValue(index);
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num1 = 1991327022;
      Array array = this.\u0033A9A1330;
      object obj = _param1;
      uint num2 = num1 >> 27;
      int index = this.\u00374BD1755;
      uint num3 = 466059005U * num2;
      array.SetValue(obj, index);
    }

    public override UIntPtr \u0032452299F()
    {
      uint num1 = 182525820U % 1019240805U;
      // ISSUE: type reference
      RuntimeTypeHandle handle1 = __typeref (UIntPtr);
      uint num2 = num1 % 131410820U;
      Type typeFromHandle = Type.GetTypeFromHandle(handle1);
      Type[] parameterTypes = new Type[(int) num2 ^ 51115002];
      int index1 = (int) num2 - 51115000;
      uint num3 = num2 % 743968577U;
      Type type1 = this.\u0033A9A1330.GetType();
      uint num4 = num3 / 1403850245U;
      parameterTypes[index1] = type1;
      uint num5 = 1959398528U >> (int) num4;
      int index2 = (int) num5 - 1959398527;
      uint num6 = num5 / 1171606079U;
      Type type2 = typeof (int);
      parameterTypes[index2] = type2;
      uint num7 = num6 % 275583672U;
      // ISSUE: type reference
      RuntimeTypeHandle handle2 = __typeref (\u0031C561093);
      uint num8 = 828728426U / num7;
      Module module = Type.GetTypeFromHandle(handle2).Module;
      uint num9 = 1474455775U / num8;
      int num10 = (int) num9 ^ 0;
      uint num11 = 516708692U * num9;
      DynamicMethod dynamicMethod = new DynamicMethod("", typeFromHandle, parameterTypes, module, num10 != 0);
      ILGenerator ilGenerator = dynamicMethod.GetILGenerator();
      ilGenerator.Emit(OpCodes.Ldarg, (int) num11 ^ 516708692);
      uint num12 = 156899610U * num11;
      OpCode ldarg = OpCodes.Ldarg;
      int num13 = (int) num12 ^ 1895974537;
      uint num14 = 363997236U | num12;
      ilGenerator.Emit(ldarg, num13);
      uint num15 = 283839253U & 969616084U * num14;
      OpCode ldelema = OpCodes.Ldelema;
      Type type3 = this.\u0033A9A1330.GetType();
      uint num16 = 1835665812U << (int) num15;
      Type elementType = type3.GetElementType();
      ilGenerator.Emit(ldelema, elementType);
      uint num17 = 589702192U >> (int) (1776231819U ^ num16);
      OpCode convU = OpCodes.Conv_U;
      uint num18 = 767196259U + num17;
      ilGenerator.Emit(convU);
      uint num19 = 700385843U * num18;
      ilGenerator.Emit(OpCodes.Ret);
      uint num20 = num19 | 1113399171U;
      int length = (int) num20 ^ -822116411;
      uint num21 = 1918453570U >> (int) num20;
      object[] parameters = new object[length];
      uint num22 = 2125873300U + num21;
      int index3 = (int) num22 - 2140861218;
      uint num23 = 183128690U ^ num22;
      Array array = this.\u0033A9A1330;
      parameters[index3] = (object) array;
      uint num24 = 879954805U | num23;
      int index4 = (int) num24 ^ 1970514804;
      int num25 = this.\u00374BD1755;
      uint num26 = num24 & 1112817612U;
      // ISSUE: variable of a boxed type
      __Boxed<int> local = (ValueType) num25;
      uint num27 = 7809614U + num26;
      parameters[index4] = (object) local;
      object obj = dynamicMethod.Invoke((object) null, parameters);
      uint num28 = 279119865U / num27;
      return (UIntPtr) obj;
    }
  }

  private sealed class \u0037E41300F : \u0031C561093.\u0033AF92E6D
  {
    private MethodBase \u00362A473D9;

    public \u0037E41300F(MethodBase _param1)
    {
      uint num1;
      do
      {
        num1 = 2099404101U;
        // ISSUE: explicit constructor call
        base.\u002Ector();
      }
      while (903156209U == num1);
      MethodBase methodBase = _param1;
      uint num2 = num1 - 573266833U;
      this.\u00362A473D9 = methodBase;
    }

    public override Type \u0030452B850() => typeof (MethodBase);

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num1 = 1515587170;
      MethodBase methodBase = this.\u00362A473D9;
      uint num2 = 1845894507U >> (int) num1;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0037E41300F(methodBase);
    }

    public override object \u0035F319DE0()
    {
      uint num = 1531256344U % 1493637995U;
      return (object) this.\u00362A473D9;
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num1;
      do
      {
        object obj = _param1;
        uint num2 = 1864641945;
        MethodBase methodBase = (MethodBase) obj;
        num1 = 133725172U - num2;
        this.\u00362A473D9 = methodBase;
      }
      while (712127295U > num1);
    }

    public override bool \u0039CB63F4A()
    {
      uint num1 = 620235960U / 589826978U;
      MethodBase methodBase = this.\u00362A473D9;
      uint num2 = num1 ^ 1502312127U;
      return methodBase > null;
    }

    public override IntPtr B8342F7A()
    {
      uint num;
      RuntimeMethodHandle runtimeMethodHandle;
      do
      {
        RuntimeMethodHandle methodHandle = this.\u00362A473D9.MethodHandle;
        num = 1607485251U;
        runtimeMethodHandle = methodHandle;
      }
      while (((int) (num - 389505088U) & 916338644) == 0);
      return runtimeMethodHandle.GetFunctionPointer();
    }
  }

  private sealed class \u0033E8F1420 : \u0031C561093.\u0033AF92E6D
  {
    private IntPtr \u003087219FB;
    private \u0031C561093.\u00304BE210E \u00306830A31;

    public \u0033E8F1420(IntPtr _param1)
    {
      uint num1 = (uint) (1177901807 - 1926582982);
      // ISSUE: explicit constructor call
      base.\u002Ector();
      uint num2 = num1 / 2022776445U;
      if ((1356082513 & (int) num2) == 0)
        return;
      uint num3 = 1398044500U / num2;
      this.\u003087219FB = _param1;
      uint num4 = 2099118202U & num3 - 1225946786U;
      IntPtr num5 = this.\u003087219FB;
      uint num6 = num4 + 1178693991U;
      this.\u00306830A31 = \u0031C561093.\u0033E8F1420.\u00320450B7E(num5);
    }

    private static \u0031C561093.\u00304BE210E \u00320450B7E(IntPtr _param0)
    {
      int size = IntPtr.Size;
      uint num1 = 1322547412;
      int num2 = (int) num1 ^ 1322547408;
      if (size != num2)
        goto label_2;
label_1:
      ref IntPtr local1 = ref _param0;
      uint num3 = 1556762117U - num1;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(local1.ToInt32());
label_2:
      num1 = 1228603956U >> (int) num1;
      if (num1 / 266878697U == 0U)
      {
        ref IntPtr local2 = ref _param0;
        num3 = 1344104687U / num1;
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(local2.ToInt64());
      }
      goto label_1;
    }

    public override Type \u0030452B850()
    {
      uint num1 = 286814329;
      // ISSUE: type reference
      RuntimeTypeHandle handle = __typeref (IntPtr);
      uint num2 = 1617524633U % num1;
      return Type.GetTypeFromHandle(handle);
    }

    public override TypeCode \u003363C3519() => this.\u00306830A31.\u003363C3519();

    public override \u0031C561093.\u00304BE210E \u00321939EB5() => (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0033E8F1420(this.\u003087219FB);

    public override object \u0035F319DE0()
    {
      uint num1 = 1315329148U % 899889279U;
      IntPtr num2 = this.\u003087219FB;
      uint num3 = num1 - 2087606333U;
      return (object) num2;
    }

    public override void \u0036DCE2291(object _param1)
    {
      uint num1;
      do
      {
        uint num2 = 740909713;
        IntPtr num3 = (IntPtr) _param1;
        uint num4 = num2 << 19;
        this.\u003087219FB = num3;
        if (num4 <= 440205760U)
        {
          IntPtr num5 = this.\u003087219FB;
          num1 = num4 >> 29;
          this.\u00306830A31 = \u0031C561093.\u0033E8F1420.\u00320450B7E(num5);
        }
        else
          goto label_2;
      }
      while ((int) num1 - 592334512 == 0);
      goto label_3;
label_2:
      return;
label_3:;
    }

    public override bool \u0039CB63F4A() => this.\u003087219FB != IntPtr.Zero;

    public override sbyte \u00309729E51() => this.\u00306830A31.\u00309729E51();

    public override short E66DE219()
    {
      uint num1 = 2137860120;
      \u0031C561093.\u00304BE210E obj = this.\u00306830A31;
      uint num2 = num1 * 1212763798U;
      return obj.E66DE219();
    }

    public override int E2D6F630() => this.\u00306830A31.E2D6F630();

    public override long D500CE01()
    {
      uint num1 = (uint) (396306759 + 832534076);
      \u0031C561093.\u00304BE210E obj = this.\u00306830A31;
      uint num2 = 379349409U + num1;
      return obj.D500CE01();
    }

    public override byte \u00342E17D34() => this.\u00306830A31.\u00342E17D34();

    public override ushort DD7230A3()
    {
      uint num = (uint) (1830384928 + 224666186);
      return this.\u00306830A31.DD7230A3();
    }

    public override uint \u00377124934() => this.\u00306830A31.\u00377124934();

    public override ulong \u00353FB65C3()
    {
      uint num1 = 1217227380;
      \u0031C561093.\u00304BE210E obj = this.\u00306830A31;
      uint num2 = num1 / 1069772560U;
      return obj.\u00353FB65C3();
    }

    public override float BA2939E9() => this.\u00306830A31.BA2939E9();

    public override double \u00383BC968D() => this.\u00306830A31.\u00383BC968D();

    public override IntPtr B8342F7A()
    {
      uint num = (uint) (679819340 | 2132635096);
      return this.\u003087219FB;
    }

    public override UIntPtr \u0032452299F()
    {
      uint num = 1492875248U / 1816740594U;
      return this.\u00306830A31.\u0032452299F();
    }

    public override unsafe void* \u003480545A0() => this.\u003087219FB.ToPointer();

    public override object C5EE7C38(Type _param1, bool _param2)
    {
      uint num1 = 1435068621;
      \u0031C561093.\u00304BE210E obj = this.\u00306830A31;
      uint num2 = 593652035U << (int) num1;
      Type type = _param1;
      uint num3 = 1852395725U * num2;
      int num4 = _param2 ? 1 : 0;
      uint num5 = num3 | 1816598489U;
      return obj.C5EE7C38(type, num4 != 0);
    }
  }

  private sealed class \u0035D455BDE : \u0031C561093.\u0033AF92E6D
  {
    private UIntPtr \u0036F980031;
    private \u0031C561093.\u00304BE210E \u003308A6740;

    public \u0035D455BDE(UIntPtr _param1)
    {
      uint num1 = 772157054;
      if ((int) num1 + 149767782 != 0)
      {
        uint num2 = num1 ^ 1025982245U;
        // ISSUE: explicit constructor call
        base.\u002Ector();
        num1 = num2 - 1267488656U;
        if (35607876U % num1 != 0U)
        {
          uint num3 = num1 << 18;
          UIntPtr num4 = _param1;
          uint num5 = 2073191039U % num3;
          this.\u0036F980031 = num4;
          num1 = 815147260U * num5;
        }
      }
      uint num6 = num1 & 937979889U | 1402950555U;
      UIntPtr num7 = this.\u0036F980031;
      uint num8 = num6 & 1838549226U;
      \u0031C561093.\u00304BE210E obj = \u0031C561093.\u0035D455BDE.\u00302064D5F(num7);
      uint num9 = num8 << 2;
      this.\u003308A6740 = obj;
    }

    private static \u0031C561093.\u00304BE210E \u00302064D5F(UIntPtr _param0)
    {
      uint num1;
      uint num2;
      do
      {
        int size = IntPtr.Size;
        num1 = 535761159U;
        int num3 = (int) num1 - 535761155;
        if (size == num3)
          num2 = num1 / 705961648U;
        else
          goto label_3;
      }
      while (num2 == 1610168805U);
      int uint32 = (int) _param0.ToUInt32();
      uint num4 = num2 % 242227574U;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(uint32);
label_3:
      num4 = num1 + 1006467029U;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F((long) _param0.ToUInt64());
    }

    public override Type \u0030452B850() => typeof (UIntPtr);

    public override TypeCode \u003363C3519()
    {
      uint num = 238896756U >> 26;
      return this.\u003308A6740.\u003363C3519();
    }

    public override \u0031C561093.\u00304BE210E \u00321939EB5()
    {
      uint num1 = (uint) (1270106434 & 1072236377);
      UIntPtr num2 = this.\u0036F980031;
      uint num3 = 1115029679U % num1;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0035D455BDE(num2);
    }

    public override object \u0035F319DE0() => (object) this.\u0036F980031;

    public override void \u0036DCE2291(object _param1)
    {
      uint num;
      do
      {
        object obj = _param1;
        num = 1129711619U;
        this.\u0036F980031 = (UIntPtr) obj;
      }
      while (233844350U <= num << 24);
      this.\u003308A6740 = \u0031C561093.\u0035D455BDE.\u00302064D5F(this.\u0036F980031);
    }

    public override bool \u0039CB63F4A()
    {
      uint num1 = 350365264;
      UIntPtr num2 = this.\u0036F980031;
      uint num3 = num1 >> 9;
      UIntPtr zero = UIntPtr.Zero;
      return num2 != zero;
    }

    public override sbyte \u00309729E51()
    {
      uint num1 = 602758122;
      \u0031C561093.\u00304BE210E obj = this.\u003308A6740;
      uint num2 = 1477537302U + num1;
      return obj.\u00309729E51();
    }

    public override short E66DE219() => this.\u003308A6740.E66DE219();

    public override int E2D6F630()
    {
      uint num = (uint) (1701607489 << 13);
      return this.\u003308A6740.E2D6F630();
    }

    public override long D500CE01()
    {
      uint num1 = 1066680443U / 1943868400U;
      \u0031C561093.\u00304BE210E obj = this.\u003308A6740;
      uint num2 = 1392851953U - num1;
      return obj.D500CE01();
    }

    public override byte \u00342E17D34()
    {
      uint num1 = (uint) (601163422 * 1271621072);
      \u0031C561093.\u00304BE210E obj = this.\u003308A6740;
      uint num2 = num1 ^ 100140171U;
      return obj.\u00342E17D34();
    }

    public override ushort DD7230A3() => this.\u003308A6740.DD7230A3();

    public override uint \u00377124934()
    {
      uint num1 = 181419953;
      \u0031C561093.\u00304BE210E obj = this.\u003308A6740;
      uint num2 = 1581922944U & num1;
      return obj.\u00377124934();
    }

    public override ulong \u00353FB65C3()
    {
      uint num1 = 1843690704;
      \u0031C561093.\u00304BE210E obj = this.\u003308A6740;
      uint num2 = num1 - 545999136U;
      return obj.\u00353FB65C3();
    }

    public override float BA2939E9()
    {
      uint num = (uint) (956841389 + 1905666277);
      return this.\u003308A6740.BA2939E9();
    }

    public override double \u00383BC968D() => this.\u003308A6740.\u00383BC968D();

    public override IntPtr B8342F7A() => this.\u003308A6740.B8342F7A();

    public override UIntPtr \u0032452299F() => this.\u0036F980031;

    public override unsafe void* \u003480545A0()
    {
      uint num = (uint) (1788243204 * 810447388);
      return this.\u0036F980031.ToPointer();
    }

    public override object C5EE7C38(Type _param1, bool _param2)
    {
      uint num1 = (uint) (2126664798 + 1181369331);
      \u0031C561093.\u00304BE210E obj = this.\u003308A6740;
      Type type = _param1;
      uint num2 = 1363696321U & num1;
      int num3 = _param2 ? 1 : 0;
      uint num4 = num2 ^ 2124569178U;
      return obj.C5EE7C38(type, num3 != 0);
    }
  }

  private sealed class \u0036152782D : \u0031C561093.\u0033AF92E6D
  {
    private Enum \u0032B0D1EB6;
    private \u0031C561093.\u00304BE210E \u00316EE505C;

    public \u0036152782D(Enum _param1)
    {
label_0:
      // ISSUE: explicit constructor call
      base.\u002Ector();
      uint num1 = 1983123463;
      Enum enum1 = _param1;
      uint num2 = 288563155U / num1;
      if (enum1 != null)
        goto label_2;
label_1:
      throw new ArgumentException();
label_2:
      if ((844331894 ^ (int) num2) != 0)
      {
        uint num3 = num2 * 1675451648U;
        this.\u0032B0D1EB6 = _param1;
        if (1741104226U >= num3)
        {
          Enum enum2 = this.\u0032B0D1EB6;
          uint num4 = num3 ^ 1655836942U;
          \u0031C561093.\u00304BE210E obj = \u0031C561093.\u0036152782D.\u003455205F3(enum2);
          uint num5 = 1878683425U | num4;
          this.\u00316EE505C = obj;
        }
        else
          goto label_1;
      }
      else
        goto label_0;
    }

    private static \u0031C561093.\u00304BE210E \u003455205F3(Enum _param0)
    {
      TypeCode typeCode = _param0.GetTypeCode();
      uint num1 = 826237354;
      do
      {
        int num2 = (int) typeCode;
        uint num3 = num1 - 1152080996U;
        int num4 = (int) num3 - -325843647;
        int num5 = num2 - num4;
        num1 = 1300459983U & num3;
        switch (num5)
        {
          case 0:
          case 2:
          case 4:
            goto label_5;
          case 1:
          case 3:
          case 5:
            continue;
          case 6:
            goto label_8;
          case 7:
            goto label_6;
          default:
            if (1031280276U >> (int) num1 == 0U)
              goto case 1;
            else
              goto label_10;
        }
      }
      while (709642454 + (int) num1 == 0);
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81((int) Convert.ToUInt32((object) _param0));
label_5:
      uint num6 = num1 | 742998605U;
      Enum enum1 = _param0;
      uint num7 = num6 | 467811566U;
      return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00348553D81(Convert.ToInt32((object) enum1));
label_6:
      if (num1 > 744378630U)
      {
        Enum enum2 = _param0;
        num7 = num1 & 2124284342U;
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F((long) Convert.ToUInt64((object) enum2));
      }
      goto label_5;
label_8:
      if (1462579439U > num1)
        return (\u0031C561093.\u00304BE210E) new \u0031C561093.\u00304E67D6F(Convert.ToInt64((object) _param0));
label_10:
      num7 = num1 - 567496578U;
      throw new InvalidOperationException();
    }

    public override \u0031C561093.\u00304BE210E \u0030323FE8D() => this.\u00316EE505C.\u0030323FE8D();

    public override Type \u0030452B850()
    {
      uint num1 = (uint) (1828328586 ^ 39344416);
      Enum @enum = this.\u0032B0D1EB6;
      uint num2 = 986085773U & num1;
      return @enum.GetType();
    }

    public override TypeCode \u003363C3519() => this.\u00316EE505C.\u003363C3519();

    public override \u0031C561093.\u00304BE210E \u00321939EB5() => (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0036152782D(this.\u0032B0D1EB6);

    public override object \u0035F319DE0() => (object) this.\u0032B0D1EB6;

    public override void \u0036DCE2291(object _param1)
    {
      object obj1 = _param1;
      uint num1 = 653930002;
      uint num2;
      if (obj1 == null)
        num2 = 908005918U & num1;
      else
        goto label_3;
label_2:
      throw new ArgumentException();
label_3:
      if (91557254U <= num1)
      {
        this.\u0032B0D1EB6 = (Enum) _param1;
        uint num3 = (num1 & 351814312U) - 5864602U;
        \u0031C561093.\u00304BE210E obj2 = \u0031C561093.\u0036152782D.\u003455205F3(this.\u0032B0D1EB6);
        num2 = 1726615802U + num3;
        this.\u00316EE505C = obj2;
      }
      else
        goto label_2;
    }

    public override byte \u00342E17D34()
    {
      uint num1 = 1311861987;
      \u0031C561093.\u00304BE210E obj = this.\u00316EE505C;
      uint num2 = 1631521804U & num1;
      return obj.\u00342E17D34();
    }

    public override sbyte \u00309729E51()
    {
      uint num1 = 1411477431U >> 7;
      \u0031C561093.\u00304BE210E obj = this.\u00316EE505C;
      uint num2 = 160254100U * num1;
      return obj.\u00309729E51();
    }

    public override short E66DE219()
    {
      uint num1 = 919436490;
      \u0031C561093.\u00304BE210E obj = this.\u00316EE505C;
      uint num2 = num1 << 14;
      return obj.E66DE219();
    }

    public override ushort DD7230A3()
    {
      uint num1 = 1919102335;
      \u0031C561093.\u00304BE210E obj = this.\u00316EE505C;
      uint num2 = 1503093221U / num1;
      return obj.DD7230A3();
    }

    public override int E2D6F630()
    {
      uint num1 = 1074878817;
      \u0031C561093.\u00304BE210E obj = this.\u00316EE505C;
      uint num2 = 2141738216U & num1;
      return obj.E2D6F630();
    }

    public override uint \u00377124934()
    {
      uint num1 = (uint) (132385386 * 2126134802);
      \u0031C561093.\u00304BE210E obj = this.\u00316EE505C;
      uint num2 = 1801274982U >> (int) num1;
      return obj.\u00377124934();
    }

    public override long D500CE01()
    {
      uint num1 = 897209936;
      \u0031C561093.\u00304BE210E obj = this.\u00316EE505C;
      uint num2 = num1 | 1741643505U;
      return obj.D500CE01();
    }

    public override ulong \u00353FB65C3()
    {
      uint num1 = (uint) (1215697442 | 1801267024);
      \u0031C561093.\u00304BE210E obj = this.\u00316EE505C;
      uint num2 = 505954084U & num1;
      return obj.\u00353FB65C3();
    }

    public override float BA2939E9() => this.\u00316EE505C.BA2939E9();

    public override double \u00383BC968D()
    {
      uint num1 = 1056602647;
      \u0031C561093.\u00304BE210E obj = this.\u00316EE505C;
      uint num2 = 1712416268U & num1;
      return obj.\u00383BC968D();
    }

    public override IntPtr B8342F7A()
    {
      uint num1 = 2013268264;
      if (880886373 + (int) num1 != 0)
      {
        while (IntPtr.Size != ((int) num1 ^ 2013268268))
        {
          if (num1 > 1638946743U)
            goto label_3;
        }
        goto label_4;
      }
      else
        goto label_4;
label_3:
      uint num2 = 629674277U * num1;
      long num3 = this.D500CE01();
      goto label_6;
label_4:
      num1 = 1307247522U % num1;
      if ((int) num1 * 164186156 != 0)
      {
        uint num4 = 633359711U & num1;
        int num5 = this.E2D6F630();
        uint num6 = num4 ^ 1442073245U;
        long num7 = (long) num5;
        num2 = num6 ^ 2917708119U;
        num3 = num7;
      }
      else
        goto label_3;
label_6:
      uint num8 = 2022770070U + num2;
      return new IntPtr(num3);
    }

    public override UIntPtr \u0032452299F()
    {
      uint num1 = 543715296;
      uint num2;
      long num3;
      if (IntPtr.Size != (int) num1 - 543715292)
      {
        num2 = 1827957648U | num1;
        num3 = (long) this.\u00353FB65C3();
      }
      else
      {
        num3 = (long) this.\u00377124934();
        num2 = num1 + 1284767760U;
      }
      return new UIntPtr((ulong) num3);
    }

    public override object C5EE7C38(Type _param1, bool _param2)
    {
      uint num1 = 708850983U / 1392401263U;
      \u0031C561093.\u00304BE210E obj = this.\u00316EE505C;
      uint num2 = num1 + 434853908U;
      Type type = _param1;
      int num3 = _param2 ? 1 : 0;
      return obj.C5EE7C38(type, num3 != 0);
    }
  }

  private sealed class \u0032ABF00C0 : \u0031C561093.\u003324700AD
  {
    private IntPtr \u0030D164F95;
    private Type \u0031E2710F0;

    public \u0032ABF00C0(IntPtr _param1, Type _param2)
    {
      uint num1 = 1615024429;
      // ISSUE: explicit constructor call
      base.\u002Ector();
      if (1415980102U % num1 == 0U)
        return;
      IntPtr num2 = _param1;
      uint num3 = 396697565U % num1;
      this.\u0030D164F95 = num2;
      uint num4 = num3 * 416233681U & 1503602273U;
      this.\u0031E2710F0 = _param2;
    }

    public override Type \u0030452B850() => typeof (Pointer);

    public override TypeCode \u003363C3519() => TypeCode.Empty;

    public override \u0031C561093.\u00304BE210E \u00321939EB5() => (\u0031C561093.\u00304BE210E) new \u0031C561093.\u0032ABF00C0(this.\u0030D164F95, this.\u0031E2710F0);

    public override object \u0035F319DE0()
    {
      uint num1 = 1600993347U / 48829493U;
      Type type = this.\u0031E2710F0;
      uint num2 = num1 & 1125320531U;
      int num3 = type.IsValueType ? 1 : 0;
      uint num4 = num2 >> 23;
      uint num5;
      if (num3 != 0)
      {
        uint num6 = num4 - 170072918U - 422974028U;
        IntPtr ptr = this.\u0030D164F95;
        num5 = 520629610U >> (int) num6;
        Type structureType = this.\u0031E2710F0;
        return Marshal.PtrToStructure(ptr, structureType);
      }
      num5 = num4 + 967272930U;
      throw new InvalidOperationException();
    }

    public override void \u0036DCE2291(object _param1)
    {
label_0:
      uint num1;
      uint num2;
      do
      {
        uint num3;
        do
        {
          object obj1 = _param1;
          uint num4 = 2094823582;
          if (obj1 == null)
            throw new ArgumentException();
label_2:
          do
          {
            if (num4 >= 1593848533U)
            {
              uint num5 = num4 | 1735617764U;
              if (this.\u0031E2710F0.IsValueType)
                num1 = num5 * 1887788996U;
              else
                goto label_7;
label_5:
              object structure = _param1;
              IntPtr ptr1 = this.\u0030D164F95;
              int num6 = (int) num1 ^ -554437512;
              num2 = num1 << 27;
              Marshal.StructureToPtr(structure, ptr1, num6 != 0);
              break;
label_7:
              uint num7 = num5 * 1721722311U;
              if (((int) num7 ^ 309270170) != 0)
              {
                object obj2 = _param1;
                uint num8 = 1987595035U << (int) num7;
                TypeCode typeCode = Type.GetTypeCode(obj2.GetType());
                if (num8 <= 882670667U)
                {
                  do
                  {
                    int num9 = (int) typeCode;
                    int num10 = (int) num8 - 745275388;
                    uint num11 = num8 + 938367251U;
                    int num12 = num9 - num10;
                    num1 = 618220554U ^ num11;
                    switch (num12)
                    {
                      case 0:
                        goto label_15;
                      case 1:
                        num8 = num1 << 25;
                        continue;
                      case 2:
                        goto label_12;
                      case 3:
                        goto label_17;
                      case 4:
                        goto label_19;
                      case 5:
                        goto label_20;
                      case 6:
                        goto label_22;
                      case 7:
                        goto label_24;
                      case 8:
                        goto label_25;
                      case 9:
                        goto label_27;
                      case 10:
                        goto label_28;
                      default:
                        goto label_29;
                    }
                  }
                  while ((int) num8 << 24 != 0);
                  IntPtr ptr2 = this.\u0030D164F95;
                  object obj3 = _param1;
                  num2 = num8 + 994343856U;
                  int num13 = (int) (byte) Convert.ToSByte(obj3);
                  Marshal.WriteByte(ptr2, (byte) num13);
                  break;
label_12:
                  if ((int) num1 * 34107520 != 0)
                  {
                    uint num9 = num1 ^ 2067597995U;
                    IntPtr ptr3 = this.\u0030D164F95;
                    uint num10 = 1921018140U | num9;
                    int num11 = (int) Convert.ToByte(_param1);
                    num4 = num10 & 816272929U;
                    Marshal.WriteByte(ptr3, (byte) num11);
                    continue;
                  }
                  goto label_5;
label_15:
                  uint num14 = num1 | 1868964674U;
                  IntPtr ptr4 = this.\u0030D164F95;
                  uint num15 = num14 ^ 220746412U;
                  int num16 = (int) Convert.ToChar(_param1);
                  num1 = 123012278U ^ num15;
                  Marshal.WriteInt16(ptr4, (char) num16);
                  if (1360874801 * (int) num1 == 0)
                    goto label_5;
                  else
                    goto label_14;
label_20:
                  if (num1 > 1241005538U)
                    break;
                  goto label_21;
label_28:
                  IntPtr ptr5 = this.\u0030D164F95;
                  uint num17 = 2082417295U << (int) num1;
                  byte[] bytes = BitConverter.GetBytes(Convert.ToDouble(_param1));
                  uint num18 = 1809450131U ^ num17;
                  int startIndex = (int) num18 - 1977222291;
                  long int64 = BitConverter.ToInt64(bytes, startIndex);
                  num5 = num18 % 1544052626U;
                  Marshal.WriteInt64(ptr5, int64);
                  if (1224893374 - (int) num5 == 0)
                    goto label_7;
                  else
                    goto label_26;
                }
                else
                  goto label_0;
              }
              else
                goto label_0;
            }
            else
              goto label_0;
          }
          while ((int) num4 * 1198751548 == 0);
          return;
label_14:
          return;
label_17:
          num3 = num1 & 247146653U;
          continue;
label_25:
          IntPtr ptr = this.\u0030D164F95;
          object obj4 = _param1;
          num4 = 325802776U % num1;
          long uint64 = (long) Convert.ToUInt64(obj4);
          Marshal.WriteInt64(ptr, uint64);
          if (1206608689 << (int) num4 == 0)
            goto label_2;
          else
            goto label_16;
        }
        while (num3 > 105661211U);
        uint num19 = num3 ^ 45092411U;
        IntPtr ptr6 = this.\u0030D164F95;
        int int16 = (int) Convert.ToInt16(_param1);
        num2 = 363090615U >> (int) num19;
        Marshal.WriteInt16(ptr6, (short) int16);
        return;
label_19:
        uint num20 = num1 % 784019269U;
        IntPtr ptr7 = this.\u0030D164F95;
        int uint16 = (int) (short) Convert.ToUInt16(_param1);
        num2 = 1202021000U % num20;
        Marshal.WriteInt16(ptr7, (short) uint16);
        return;
label_21:
        IntPtr ptr8 = this.\u0030D164F95;
        uint num21 = 2119176992U / num1;
        int int32 = Convert.ToInt32(_param1);
        num2 = num21 % 1429675378U;
        Marshal.WriteInt32(ptr8, int32);
        return;
label_22:;
      }
      while (986523248U / num1 != 0U);
      IntPtr ptr9 = this.\u0030D164F95;
      object obj5 = _param1;
      uint num22 = 157449799U / num1;
      int uint32 = (int) Convert.ToUInt32(obj5);
      num2 = num22 + 21383110U;
      Marshal.WriteInt32(ptr9, uint32);
      return;
label_24:
      uint num23 = num1 % 963127871U;
      IntPtr ptr10 = this.\u0030D164F95;
      uint num24 = 263539657U ^ num23;
      object obj6 = _param1;
      num2 = 651193183U - num24;
      long int64_1 = Convert.ToInt64(obj6);
      Marshal.WriteInt64(ptr10, int64_1);
      return;
label_16:
      return;
label_27:
      uint num25 = num1 + 839807377U;
      IntPtr ptr11 = this.\u0030D164F95;
      uint num26 = num25 >> 15;
      byte[] bytes1 = BitConverter.GetBytes(Convert.ToSingle(_param1));
      int startIndex1 = (int) num26 - 58659;
      uint num27 = 1093999920U << (int) num26;
      int int32_1 = BitConverter.ToInt32(bytes1, startIndex1);
      num2 = num27 >> 24;
      Marshal.WriteInt32(ptr11, int32_1);
      return;
label_26:
      return;
label_29:
      throw new ArgumentException();
    }

    public override sbyte \u00309729E51()
    {
      uint num1 = 1953700162;
      int num2 = (int) Marshal.ReadByte(this.\u0030D164F95);
      uint num3 = num1 & 1500584644U;
      return (sbyte) num2;
    }

    public override short E66DE219() => Marshal.ReadInt16(this.\u0030D164F95);

    public override int E2D6F630()
    {
      uint num1 = 1892182207;
      IntPtr ptr = this.\u0030D164F95;
      uint num2 = 1600861114U - num1;
      return Marshal.ReadInt32(ptr);
    }

    public override long D500CE01() => Marshal.ReadInt64(this.\u0030D164F95);

    public override char FCB291BE()
    {
      uint num1 = 1274641311;
      IntPtr ptr = this.\u0030D164F95;
      uint num2 = 1782072916U * num1;
      return (char) Marshal.ReadInt16(ptr);
    }

    public override byte \u00342E17D34() => Marshal.ReadByte(this.\u0030D164F95);

    public override ushort DD7230A3()
    {
      uint num1 = 2068719078U / 1962677895U;
      int num2 = (int) Marshal.ReadInt16(this.\u0030D164F95);
      uint num3 = num1 - 398353272U;
      return (ushort) num2;
    }

    public override uint \u00377124934()
    {
      uint num = (uint) (1561855472 * 832194224);
      return (uint) Marshal.ReadInt32(this.\u0030D164F95);
    }

    public override ulong \u00353FB65C3() => (ulong) Marshal.ReadInt64(this.\u0030D164F95);

    public override float BA2939E9()
    {
      uint num1 = 1285830263;
      IntPtr ptr = this.\u0030D164F95;
      uint num2 = 62871992U / num1;
      int num3 = Marshal.ReadInt32(ptr);
      uint num4 = num2 ^ 2092710102U;
      byte[] bytes = BitConverter.GetBytes(num3);
      int startIndex = (int) num4 - 2092710102;
      uint num5 = num4 | 992427011U;
      return BitConverter.ToSingle(bytes, startIndex);
    }

    public override double \u00383BC968D()
    {
      uint num1 = 818770575;
      IntPtr ptr = this.\u0030D164F95;
      uint num2 = 636307009U & num1;
      byte[] bytes = BitConverter.GetBytes(Marshal.ReadInt64(ptr));
      int startIndex = (int) num2 ^ 550322689;
      uint num3 = 503999506U - num2;
      return BitConverter.ToDouble(bytes, startIndex);
    }

    public override IntPtr B8342F7A()
    {
      int size = IntPtr.Size;
      uint num1 = 1810444097;
      int num2 = (int) num1 - 1810444093;
      uint num3;
      long num4;
      if (size != num2 && num1 / 1737719441U != 0U)
      {
        IntPtr ptr = this.\u0030D164F95;
        num3 = num1 << 1;
        num4 = Marshal.ReadInt64(ptr);
      }
      else
      {
        uint num5 = 1119434832U << (int) num1;
        int num6 = Marshal.ReadInt32(this.\u0030D164F95);
        uint num7 = 946685107U % num5;
        num4 = (long) num6;
        num3 = num7 ^ 4022278705U;
      }
      return new IntPtr(num4);
    }

    public override UIntPtr \u0032452299F()
    {
      int size = IntPtr.Size;
      uint num1 = 1018248175;
      int num2 = (int) num1 ^ 1018248171;
      uint num3 = num1 * 904462465U;
      if (size != num2)
        num3 &= 1576802977U;
      else
        goto label_3;
label_2:
      IntPtr ptr1 = this.\u0030D164F95;
      uint num4 = num3 * 1273107843U;
      long num5 = Marshal.ReadInt64(ptr1);
      goto label_5;
label_3:
      if (1271099166U / num3 == 0U)
      {
        uint num6 = num3 & 437610237U;
        IntPtr ptr2 = this.\u0030D164F95;
        uint num7 = 89593341U - num6;
        int num8 = Marshal.ReadInt32(ptr2);
        uint num9 = 403255619U >> (int) num7;
        long num10 = (long) (uint) num8;
        num4 = num9 + 3525567450U;
        num5 = num10;
      }
      else
        goto label_2;
label_5:
      return new UIntPtr((ulong) num5);
    }
  }

  private sealed class \u0037B071B97
  {
    private byte \u003784375C9;
    private int \u0037BF26F77;
    private int \u0033C59730F;

    public \u0037B071B97(byte _param1, int _param2, int _param3)
    {
      uint num1;
      do
      {
        uint num2;
        do
        {
          // ISSUE: explicit constructor call
          base.\u002Ector();
          this.\u003784375C9 = _param1;
          uint num3 = 737609518U % 267008357U;
          int num4 = _param2;
          num2 = num3 ^ 499785269U;
          this.\u0037BF26F77 = num4;
        }
        while (num2 > 1134973741U);
        uint num5 = num2 * 1443635010U;
        int num6 = _param3;
        num1 = num5 ^ 984564985U;
        this.\u0033C59730F = num6;
      }
      while ((555359287 & (int) num1) == 0);
    }

    public byte \u0036ADB41E8()
    {
      uint num = (uint) (1886680413 << 1707634953);
      return this.\u003784375C9;
    }

    public int \u00327244D76()
    {
      uint num = (uint) (886575667 ^ 1502831572);
      return this.\u0037BF26F77;
    }

    public int \u00358DF7A35() => this.\u0033C59730F;
  }

  private sealed class \u0037BC90C3B
  {
    private int \u003514D35C4;
    private int \u003161B608F;
    private List<\u0031C561093.\u0037B071B97> \u00340BC1BCA;

    public \u0037BC90C3B(int _param1, int _param2)
    {
      uint num1 = 1331310488;
      do
      {
        do
        {
          do
          {
            this.\u00340BC1BCA = new List<\u0031C561093.\u0037B071B97>();
            num1 += 210381636U;
          }
          while (((int) num1 ^ 2011111308) == 0);
          do
          {
            uint num2 = 441808599U % num1;
            // ISSUE: explicit constructor call
            base.\u002Ector();
            num1 = 2087144043U >> (int) num2;
          }
          while (num1 >= 40113863U);
          this.\u003514D35C4 = _param1;
          num1 = 873689954U % num1;
        }
        while (1148806748 + (int) num1 == 0);
        num1 = 47190958U % num1;
        this.\u003161B608F = _param2;
      }
      while (1071348632U < num1);
    }

    public int \u00307744ACD() => this.\u003514D35C4;

    public int \u00371A73A97() => this.\u003161B608F;

    public int \u00336BF4F0D(\u0031C561093.\u0037BC90C3B _param1)
    {
label_0:
      while (_param1 != null)
      {
        int num1;
        uint num2;
        uint num3;
        do
        {
          ref int local = ref this.\u003514D35C4;
          int num4 = _param1.\u00307744ACD();
          uint num5 = 45486399;
          num1 = local.CompareTo(num4);
          uint num6 = 713318069U / num5;
          if (115170508 + (int) num6 != 0)
          {
            int num7 = num1;
            num2 = 535117673U << (int) num6;
            if (num7 == 0)
              num3 = num2 * 891247421U;
            else
              goto label_6;
          }
          else
            goto label_0;
        }
        while (222264259U == num3);
        \u0031C561093.\u0037BC90C3B obj = _param1;
        uint num8 = 1259080562U / num3;
        int num9 = obj.\u00371A73A97();
        uint num10 = 127741246U * num8;
        int num11 = num9;
        ref int local1 = ref num11;
        uint num12 = 856451560U ^ num10;
        int num13 = this.\u003161B608F;
        num1 = local1.CompareTo(num13);
        num2 = num12 + 1822955032U;
label_6:
        if (1482449718U != (1400464387U & num2))
          return num1;
        break;
      }
      return 1;
    }

    public void \u0036AC208F8(byte _param1, int _param2, int _param3)
    {
      uint num1;
      do
      {
        List<\u0031C561093.\u0037B071B97> objList = this.\u00340BC1BCA;
        int num2 = (int) _param1;
        uint num3 = 1420843330;
        int num4 = _param2;
        int num5 = _param3;
        uint num6 = 1665809269U + num3;
        \u0031C561093.\u0037B071B97 obj = new \u0031C561093.\u0037B071B97((byte) num2, num4, num5);
        num1 = num6 & 2103778092U;
        objList.Add(obj);
      }
      while (num1 == 1211261639U);
    }

    public List<\u0031C561093.\u0037B071B97> \u0033CC40EC4() => this.\u00340BC1BCA;
  }

  internal delegate void \u00329503060();
}
