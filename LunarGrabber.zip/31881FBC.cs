﻿// Decompiled with JetBrains decompiler
// Type: 31881FBC
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

public static class \u00331881FBC
{
  private static uint[] \u003552B05A5;

  public static bool \u00350957EE0() => (bool) new \u0031C561093().\u00335B818BE((object[]) null, 25706599);

  public static bool \u00357EA6DBB() => (bool) new \u0031C561093().\u00335B818BE((object[]) null, 25705099);

  public static uint \u003236E4F10() => (uint) new \u0031C561093().\u00335B818BE((object[]) null, 25707129);

  public static uint \u0030F694857() => (uint) new \u0031C561093().\u00335B818BE((object[]) null, 15635977);

  public static uint \u00324935BFA() => (uint) new \u0031C561093().\u00335B818BE((object[]) null, 15638489);

  public static uint \u0036DDF7A91() => (uint) new \u0031C561093().\u00335B818BE((object[]) null, 15631572);

  public static uint \u0030D4C6AD5() => (uint) new \u0031C561093().\u00335B818BE((object[]) null, 25703664);

  public static uint \u003107D2667() => (uint) new \u0031C561093().\u00335B818BE((object[]) null, 15634101);

  static \u00331881FBC() => new \u0031C561093().\u00335B818BE((object[]) null, 25705611);
}
