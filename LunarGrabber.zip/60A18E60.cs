﻿// Decompiled with JetBrains decompiler
// Type: 60A18E60
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class \u00360A18E60
{
  private static ResourceManager HelloSkid;
  private static CultureInfo HelloSkid;

  internal \u00360A18E60()
  {
    // ISSUE: unable to decompile the method.
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static ResourceManager ResourceManager
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static CultureInfo Culture
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
    set
    {
      // ISSUE: unable to decompile the method.
    }
  }

  internal static string Code
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  internal static byte[] GrabberProject
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }

  internal static string RunBindedFile
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
  }
}
