﻿// Decompiled with JetBrains decompiler
// Type: LunarGrabber.RegisterForm
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using MetroFramework.Components;
using MetroFramework.Controls;
using MetroFramework.Forms;
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace LunarGrabber
{
  public class RegisterForm : MetroForm
  {
    private IContainer HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroButton HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroTabControl HelloSkid;
    private MetroTabPage HelloSkid;
    private MetroLabel HelloSkid;
    private MetroStyleManager HelloSkid;

    public RegisterForm()
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, FormClosingEventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    protected virtual void Dispose(bool HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid()
    {
      // ISSUE: unable to decompile the method.
    }
  }
}
