﻿// Decompiled with JetBrains decompiler
// Type: 66A07BC0
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;
using System.Runtime.InteropServices;

public static class \u00366A07BC0
{
  private static readonly byte[] \u0034DC87D2D;
  private static readonly byte[] \u00335501EA2;

  public static int[] \u00368635AA7(int _param0)
  {
    IntPtr num = IntPtr.Zero;
    try
    {
      byte[] source = IntPtr.Size == 4 ? \u00366A07BC0.\u0034DC87D2D : \u00366A07BC0.\u00335501EA2;
      num = \u00300B656A0.\u00325B518E3(IntPtr.Zero, new UIntPtr((uint) source.Length), \u00300B656A0.\u00371F82615.\u003078A7C44 | \u00300B656A0.\u00371F82615.\u0032AD57E14, \u00300B656A0.\u00317F43E2F.\u00300C34D58);
      Marshal.Copy(source, 0, num, source.Length);
      \u00366A07BC0.\u00367921891 forFunctionPointer = (\u00366A07BC0.\u00367921891) Marshal.GetDelegateForFunctionPointer(num, typeof (\u00366A07BC0.\u00367921891));
      GCHandle gcHandle = new GCHandle();
      int[] numArray = new int[4];
      try
      {
        gcHandle = GCHandle.Alloc((object) numArray, GCHandleType.Pinned);
        forFunctionPointer(_param0, numArray);
      }
      finally
      {
        if (gcHandle != new GCHandle())
          gcHandle.Free();
      }
      return numArray;
    }
    finally
    {
      if (num != IntPtr.Zero)
        \u00300B656A0.\u003361A6560(num, 0U, 32768U);
    }
  }

  static \u00366A07BC0()
  {
    // ISSUE: unable to decompile the method.
  }

  [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
  private delegate void \u00367921891(int _param1, int[] _param2);
}
