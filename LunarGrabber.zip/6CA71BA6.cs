﻿// Decompiled with JetBrains decompiler
// Type: 6CA71BA6
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System.Collections.Generic;

public class \u0036CA71BA6
{
  private readonly long \u003308304B2;
  private readonly \u0033F6A510B \u00340600651;
  private readonly Dictionary<uint, string> \u0032480291E;
  private readonly uint \u003303604C5;

  public \u0036CA71BA6(long _param1)
  {
    // ISSUE: unable to decompile the method.
  }
}
