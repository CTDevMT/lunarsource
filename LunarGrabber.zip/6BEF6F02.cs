﻿// Decompiled with JetBrains decompiler
// Type: 6BEF6F02
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

internal abstract class \u0036BEF6F02
{
  public const uint \u0033FEF7B9D = 12;
  public const int \u00317134EDC = 6;
  private const int \u00367F27E93 = 2;
  public const uint \u0036B784F22 = 4;
  public const uint \u0032F0510E6 = 2;
  public const int \u003401B679F = 4;
  public const uint \u00376970A57 = 4;
  public const uint \u003598D2738 = 14;
  public const uint \u0033C463320 = 128;
  public const int \u0035BF16B0D = 4;
  public const uint \u0034BFF3D86 = 16;
  public const int \u0032E4844AE = 3;
  public const int \u0035D677DAE = 3;
  public const int \u00322F3108C = 8;
  public const uint \u003207A53B1 = 8;
  public const uint \u003097250AD = 8;

  public static uint \u00366D53169(uint _param0)
  {
    _param0 -= 2U;
    return _param0 < 4U ? _param0 : 3U;
  }

  public struct \u00320640DDD
  {
    public uint \u00313A6211D;

    public void \u00335D12107() => this.\u00313A6211D = 0U;

    public void \u003599F16DB()
    {
      if (this.\u00313A6211D < 4U)
        this.\u00313A6211D = 0U;
      else if (this.\u00313A6211D < 10U)
        this.\u00313A6211D -= 3U;
      else
        this.\u00313A6211D -= 6U;
    }

    public void \u003690D57F2() => this.\u00313A6211D = this.\u00313A6211D < 7U ? 7U : 10U;

    public void \u00311437001() => this.\u00313A6211D = this.\u00313A6211D < 7U ? 8U : 11U;

    public void \u0031DA23961() => this.\u00313A6211D = this.\u00313A6211D < 7U ? 9U : 11U;

    public bool \u00331B479B8() => this.\u00313A6211D < 7U;
  }
}
