﻿// Decompiled with JetBrains decompiler
// Type: 2FDD6398
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System.IO;

internal class \u0032FDD6398
{
  private uint \u0030C8C628A = 1;
  public const uint \u0035FA1525B = 16777216;
  public uint \u003469E2533;
  public uint \u003354927BA;
  public Stream \u00335B93375;

  public void \u00342B200AF(Stream _param1)
  {
    this.\u00335B93375 = _param1;
    this.\u003354927BA = 0U;
    this.\u003469E2533 = uint.MaxValue;
    for (int index = 0; index < 5; ++index)
      this.\u003354927BA = this.\u003354927BA << 8 | (uint) (byte) this.\u00335B93375.ReadByte();
  }

  public void \u003164C026A() => this.\u00335B93375 = (Stream) null;

  public uint \u003241C0610(int _param1)
  {
    uint num1 = this.\u003469E2533;
    uint num2 = this.\u003354927BA;
    uint num3 = 0;
    for (int index = _param1; index > 0; --index)
    {
      num1 >>= 1;
      uint num4 = num2 - num1 >> 31;
      num2 -= num1 & num4 - 1U;
      num3 = (uint) ((int) num3 << 1 | 1 - (int) num4);
      if (num1 < 16777216U)
      {
        num2 = num2 << 8 | (uint) (byte) this.\u00335B93375.ReadByte();
        num1 <<= 8;
      }
    }
    this.\u003469E2533 = num1;
    this.\u003354927BA = num2;
    return num3;
  }
}
