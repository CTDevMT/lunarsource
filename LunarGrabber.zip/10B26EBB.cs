﻿// Decompiled with JetBrains decompiler
// Type: 10B26EBB
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;
using System.Reflection;

public class \u00310B26EBB
{
  private object \u0036A951858;

  public \u00310B26EBB(long _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  private void \u00328430B71(ref byte[] _param1, uint _param2)
  {
    // ISSUE: unable to decompile the method.
  }

  private Assembly \u00352820BB1(object _param1, ResolveEventArgs _param2)
  {
    // ISSUE: unable to decompile the method.
  }
}
