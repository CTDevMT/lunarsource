﻿// Decompiled with JetBrains decompiler
// Type: CD851A35
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;

public static class CD851A35
{
  [STAThread]
  private static void HelloSkid()
  {
    // ISSUE: unable to decompile the method.
  }

  public static void HelloSkid(string HelloSkid, string HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }

  public static string HelloSkid(string HelloSkid)
  {
    // ISSUE: unable to decompile the method.
  }
}
