﻿// Decompiled with JetBrains decompiler
// Type: 48024A40
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System.Collections.Generic;

public class \u00348024A40
{
  private const int \u0032B0919C0 = 8;
  private const int \u0037DD63894 = 24;
  private const uint \u0032C461A9F = 3;
  private readonly int \u00313BB3A9E;
  private readonly List<uint> \u003333C55BD;

  public \u00348024A40()
  {
    // ISSUE: unable to decompile the method.
  }

  public override string ToString()
  {
    // ISSUE: unable to decompile the method.
  }

  private enum \u0030F0C66A2
  {
    \u00333617D4D,
    \u0031B314F3B,
    \u00347E825AE,
    \u003626761CE,
  }
}
