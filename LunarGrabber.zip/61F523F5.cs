﻿// Decompiled with JetBrains decompiler
// Type: 61F523F5
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System;

public class \u00361F523F5
{
  public \u00355517E44 \u0033CB22470;
  public string \u0032CC214D9;
  public string \u0035A614D90;
  public DateTime \u003311E75D7;
  public DateTime \u00325747971;
  public int \u003006E204C;
  public byte[] \u0032922007E;

  public \u00361F523F5()
  {
    // ISSUE: unable to decompile the method.
  }
}
