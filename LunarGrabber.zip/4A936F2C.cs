﻿// Decompiled with JetBrains decompiler
// Type: 4A936F2C
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

using System.IO;

public class \u0034A936F2C
{
  private byte[] \u003795F7FF8;
  private uint \u00378E35A2E;
  private uint \u0033B9B0B1C;
  private uint \u003762E4964;
  private Stream \u0036EED4B82;
  private uint \u0030E253D46 = 1;
  public uint \u0030A371617;

  public void \u0037C706F28(uint _param1)
  {
    if ((int) this.\u0033B9B0B1C != (int) _param1)
      this.\u003795F7FF8 = new byte[(int) _param1];
    this.\u0033B9B0B1C = _param1;
    this.\u00378E35A2E = 0U;
    this.\u003762E4964 = 0U;
  }

  public void \u0036468059F(Stream _param1, bool _param2)
  {
    this.\u003238677DA();
    this.\u0036EED4B82 = _param1;
    if (_param2)
      return;
    this.\u003762E4964 = 0U;
    this.\u00378E35A2E = 0U;
    this.\u0030A371617 = 0U;
  }

  public void \u003238677DA()
  {
    this.\u00318B324DC();
    this.\u0036EED4B82 = (Stream) null;
  }

  public void \u00318B324DC()
  {
    uint num = this.\u00378E35A2E - this.\u003762E4964;
    if (num == 0U)
      return;
    this.\u0036EED4B82.Write(this.\u003795F7FF8, (int) this.\u003762E4964, (int) num);
    if (this.\u00378E35A2E >= this.\u0033B9B0B1C)
      this.\u00378E35A2E = 0U;
    this.\u003762E4964 = this.\u00378E35A2E;
  }

  public void \u0031BB66ED5(uint _param1, uint _param2)
  {
    uint num = (uint) ((int) this.\u00378E35A2E - (int) _param1 - 1);
    if (num >= this.\u0033B9B0B1C)
      num += this.\u0033B9B0B1C;
    for (; _param2 > 0U; --_param2)
    {
      if (num >= this.\u0033B9B0B1C)
        num = 0U;
      this.\u003795F7FF8[(int) this.\u00378E35A2E++] = this.\u003795F7FF8[(int) num++];
      if (this.\u00378E35A2E >= this.\u0033B9B0B1C)
        this.\u00318B324DC();
    }
  }

  public void \u00371644D23(byte _param1)
  {
    this.\u003795F7FF8[(int) this.\u00378E35A2E++] = _param1;
    if (this.\u00378E35A2E < this.\u0033B9B0B1C)
      return;
    this.\u00318B324DC();
  }

  public byte \u0034A113372(uint _param1)
  {
    uint num = (uint) ((int) this.\u00378E35A2E - (int) _param1 - 1);
    if (num >= this.\u0033B9B0B1C)
      num += this.\u0033B9B0B1C;
    return this.\u003795F7FF8[(int) num];
  }
}
