﻿// Decompiled with JetBrains decompiler
// Type: 5AE137FE
// Assembly: LunarGrabber, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8F156DE2-B4D0-4210-84CA-FF98CDA75F13
// Assembly location: C:\Users\jayde\OneDrive\Desktop\CT-Dev.MT\ZeroStance\Grabbers (Builders)\LunarGrabber_v2\LunarGrabber.exe

public class \u0035AE137FE
{
  public static readonly \u0035AE137FE \u0032FE41D2F;

  public static bool \u003416A1C08()
  {
    // ISSUE: unable to decompile the method.
  }

  public static bool \u0035BF84F7D(bool _param0)
  {
    // ISSUE: unable to decompile the method.
  }

  internal static bool \u00332DE071C(byte[] _param0)
  {
    // ISSUE: unable to decompile the method.
  }

  public static bool \u00326B56CA1()
  {
    // ISSUE: unable to decompile the method.
  }

  public static bool \u0037FA65F6E()
  {
    // ISSUE: unable to decompile the method.
  }

  public static bool \u0037C7C79E3(ref string _param0)
  {
    // ISSUE: unable to decompile the method.
  }

  public \u00348024A40 \u0030B913C4A
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
    private set
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public \u0036CA71BA6 \u0034C922111
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
    private set
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public \u0030C9C028A \u0030D825C92
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
    private set
    {
      // ISSUE: unable to decompile the method.
    }
  }

  public \u00310B26EBB \u0037BA75D49
  {
    get
    {
      // ISSUE: unable to decompile the method.
    }
    private set
    {
      // ISSUE: unable to decompile the method.
    }
  }

  private static string \u0033B572903(uint _param0)
  {
    // ISSUE: unable to decompile the method.
  }

  public static void \u00342277D6F(string _param0)
  {
    // ISSUE: unable to decompile the method.
  }

  private static void \u0036FEE421D()
  {
    // ISSUE: unable to decompile the method.
  }

  public bool \u0034A7600ED(long _param1)
  {
    // ISSUE: unable to decompile the method.
  }

  public \u0035AE137FE()
  {
    // ISSUE: unable to decompile the method.
  }

  static \u0035AE137FE()
  {
    // ISSUE: unable to decompile the method.
  }

  public static string \u003383D21FC()
  {
    // ISSUE: unable to decompile the method.
  }
}
